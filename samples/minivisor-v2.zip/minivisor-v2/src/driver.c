

#include "minivisor.h"
#include <intrin.h>

HV_GLOBAL g_Hv = { 0 };

DRIVER_INITIALIZE DriverEntry;
static DRIVER_UNLOAD DriverUnload;

static ULONG_PTR
VmxStartOnCpu(ULONG_PTR context)
{
    PHV_GLOBAL hv = (PHV_GLOBAL)context;
    ULONG idx = KeGetCurrentProcessorNumberEx(NULL);
    PVCPU vcpu = &hv->Vcpus[idx];

    vcpu->ProcessorIndex = idx;
    vcpu->Global = hv;
    TscBitmapInit(vcpu);

    VmxEnableOnVcpu(vcpu);   
    return 0;
}

static ULONG_PTR
FlushEptIpi(ULONG_PTR context)
{
    /* Runs at IPI_LEVEL in VMX non-root.  A CPUID exit fires; HandleVmExit
     * checks g_Hv.EptFlushPending (VMX root, bypasses EPT) and calls
     * EptInvalidateAll so the updated EPT mappings take effect on this CPU. */
    int r[4];
    UNREFERENCED_PARAMETER(context);
    __cpuid(r, 0);
    return 0;
}

static ULONG_PTR
VmxStopOnCpu(ULONG_PTR context)
{
    PHV_GLOBAL hv = (PHV_GLOBAL)context;
    ULONG idx = KeGetCurrentProcessorNumberEx(NULL);
    PVCPU vcpu = &hv->Vcpus[idx];

    if (vcpu->Virtualized)
    {
        VmxDisableOnVcpu(vcpu);
        vcpu->Virtualized = FALSE;
    }
    return 0;
}

static BOOLEAN
AllVirtualized(VOID)
{
    for (ULONG i = 0; i < g_Hv.VcpuCount; i++)
    {
        if (!g_Hv.Vcpus[i].Virtualized)
        {
            return FALSE;
        }
    }
    return TRUE;
}

static VOID
DriverUnload(PDRIVER_OBJECT driverObject)
{
    UNREFERENCED_PARAMETER(driverObject);

    ControlTeardown();

    if (g_Hv.VmxEnabled)
    {
        KeIpiGenericCall(VmxStopOnCpu, (ULONG_PTR)&g_Hv);
        g_Hv.VmxEnabled = FALSE;
        MV_LOG("devirtualized all CPUs");
    }

    EptFree(&g_Hv.Ept);

    if (g_Hv.Vcpus != NULL)
    {
        MemFreeContiguous(g_Hv.Vcpus);
        g_Hv.Vcpus = NULL;
    }

    MV_LOG("driver unloaded");
}

NTSTATUS
DriverEntry(PDRIVER_OBJECT driverObject, PUNICODE_STRING registryPath)
{
    SIZE_T arraySize;

    UNREFERENCED_PARAMETER(registryPath);

    if (driverObject)
        driverObject->DriverUnload = DriverUnload;

    LogInit();
    KeInitializeSpinLock(&g_Hv.HookTableLock);
    MV_LOG("loading; sizeof(VCPU)=%llu", (UINT64)sizeof(VCPU));

    /* Capture CR3 here, in DriverEntry's System-process context, for use as the
     * VMCS host CR3.  The System process never exits, so the host address space
     * can't be torn down underneath us — unlike a CR3 sampled in the IPI handler,
     * which would belong to whatever arbitrary process that core had interrupted. */
    g_Hv.SystemCr3 = __readcr3();

    if (!VmxIsSupported())
    {
        return STATUS_NOT_SUPPORTED;
    }

    if (!EptIsSupported())
    {
        return STATUS_NOT_SUPPORTED;
    }

    g_Hv.VcpuCount = KeQueryActiveProcessorCountEx(ALL_PROCESSOR_GROUPS);
    arraySize = (SIZE_T)g_Hv.VcpuCount * sizeof(VCPU);

    g_Hv.Vcpus = (PVCPU)MemAllocContiguous(arraySize);
    if (g_Hv.Vcpus == NULL)
    {
        MV_ERR("failed to allocate %lu VCPU blocks (%llu bytes)",
               g_Hv.VcpuCount, (UINT64)arraySize);
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    

    for (ULONG i = 0; i < g_Hv.VcpuCount; i++)
    {
        PVCPU v = &g_Hv.Vcpus[i];
        v->VmxonPhysical     = MemVirtualToPhysical(v->VmxonRegion);
        v->VmcsPhysical      = MemVirtualToPhysical(v->VmcsRegion);
        v->MsrBitmapPhysical = MemVirtualToPhysical(v->MsrBitmap);
        v->IoBitmapAPhysical = MemVirtualToPhysical(v->IoBitmapA);
        v->IoBitmapBPhysical = MemVirtualToPhysical(v->IoBitmapB);
    }

    

    if (!EptBuild(&g_Hv.Ept))
    {
        MV_ERR("EPT build failed");
        MemFreeContiguous(g_Hv.Vcpus);
        g_Hv.Vcpus = NULL;
        return STATUS_UNSUCCESSFUL;
    }

    /* VCPU array and EPT tables are hidden AFTER VMLAUNCH (below).
     * Hiding them before launch would make vcpu->Virtualized read as 0 from
     * the guest (EPT remaps to the zero decoy), causing a double-VMLAUNCH
     * on an already-launched VMCS and a hang at IPI_LEVEL. */



    if (HpetFind(&g_Hv.Hpet))
    {
        if (!HpetHide(&g_Hv.Hpet, &g_Hv.Ept))
        {
            MV_ERR("HPET: hide failed — continuing without HPET spoofing");
            g_Hv.Hpet.Valid = FALSE;
        }
    }
    else
    {
        MV_LOG("HPET: not found or not supported — HPET spoofing disabled");
    }

    

    if (!PmTimerFind(&g_Hv.PmTimer))
    {
        MV_LOG("PMTMR: not found — ACPI PM timer spoofing disabled");
    }

    /* Arm 8254 PIT channel-0 spoofing (always present at 0x40-0x43, fixed rate;
     * no firmware lookup needed).  Non-fatal if disabled at compile time. */
    if (!PitInit(&g_Hv.Pit))
    {
        MV_LOG("PIT: channel-0 spoofing disabled");
    }

    

    {
        NTSTATUS ctrlStatus = ControlInit(driverObject);
        if (!NT_SUCCESS(ctrlStatus))
        {
            MV_ERR("control device creation failed (%08x) — runtime configuration disabled",
                   ctrlStatus);
        }
    }

    

    SyscallHookInit();

    

    if (ApicFind(&g_Hv.Apic))
    {
        if (!ApicHide(&g_Hv.Apic, &g_Hv.Ept))
        {
            MV_ERR("APIC: hide failed — continuing without APIC spoofing");
            g_Hv.Apic.Valid = FALSE;
        }
    }
    else
    {
        MV_LOG("APIC: not found or not supported — APIC timer spoofing disabled");
    }

    

    for (ULONG i = 0; i < g_Hv.VcpuCount; i++)
    {
        KAFFINITY prev = KeSetSystemAffinityThreadEx((KAFFINITY)1 << i);
        TscSetNativeCost(&g_Hv.Vcpus[i], TscMeasureCpuidCost(g_Hv.Vcpus[i].TscSamples));
        KeRevertToUserAffinityThreadEx(prev);
    }

    
    KeIpiGenericCall(VmxStartOnCpu, (ULONG_PTR)&g_Hv);

    if (!AllVirtualized())
    {
        MV_ERR("one or more CPUs failed to virtualize; rolling back");
        KeIpiGenericCall(VmxStopOnCpu, (ULONG_PTR)&g_Hv);
        EptFree(&g_Hv.Ept);     /* was leaked on this path */
        MemFreeContiguous(g_Hv.Vcpus);
        g_Hv.Vcpus = NULL;
        return STATUS_UNSUCCESSFUL;
    }

    g_Hv.VmxEnabled = TRUE;
    MV_LOG("virtualized %lu CPU(s)", g_Hv.VcpuCount);

    /* Now that all CPUs are in VMX non-root, hide the VCPU array and EPT
     * tables so BE's scanner reads the zero decoy.  Must be done AFTER
     * VMLAUNCH: before launch the guest would read vcpu->Virtualized through
     * EPT, see 0 (decoy), and attempt a double-VMLAUNCH → hang.
     *
     * g_Hv.EptFlushPending is in the driver's BSS (not EPT-hidden), so VMX
     * root (HandleVmExit) can read the real value and call EptInvalidateAll
     * on each CPU when FlushEptIpi triggers a CPUID VM exit. */
    {
        UINT64 vcpuPa = MemVirtualToPhysical(g_Hv.Vcpus);
        SIZE_T vcpuSz = (SIZE_T)g_Hv.VcpuCount * sizeof(VCPU);
        if (!EptHideRange(&g_Hv.Ept, vcpuPa, vcpuSz))
            MV_ERR("EPT: failed to hide VCPU array — less stealthy");
        if (!EptHideRange(&g_Hv.Ept, g_Hv.Ept.TablesPhysical, g_Hv.Ept.TablesSize))
            MV_ERR("EPT: failed to hide EPT tables — less stealthy");
        g_Hv.EptFlushPending = TRUE;
        KeIpiGenericCall(FlushEptIpi, 0);
        g_Hv.EptFlushPending = FALSE;
    }

    for (ULONG i = 0; i < g_Hv.VcpuCount; i++)
    {
        KAFFINITY prev = KeSetSystemAffinityThreadEx((KAFFINITY)1 << i);
        TscCalibrate(&g_Hv.Vcpus[i]);
        KeRevertToUserAffinityThreadEx(prev);
    }

    return STATUS_SUCCESS;
}
