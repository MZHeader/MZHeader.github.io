# MiniVisor-v2 — Transparent VT-x Hypervisor (research)

A thin Intel VT-x "blue-pill" hypervisor loaded as a Windows x64 kernel driver.
It virtualizes the already-running OS in place and applies seven transparency
defenses so anti-VM malware running in that OS cannot tell it is virtualized:

| Detection technique it defeats | Mechanism | Code |
|---|---|---|
| CPUID hypervisor-present bit + vendor leaves | CPUID spoofing | `src/stealth.c`, `src/handlers/cpuid.c` |
| CPUID/VM-exit timing via RDTSC | TSC offsetting, per-VCPU calibrated | `src/handlers/tsc.c` |
| RDPMC performance-counter timing | RDPMC interception, cycle-counter correction | `src/handlers/rdpmc.c` |
| Reading CR4.VMXE | CR4 guest/host mask + read shadow | `src/vmcs.c`, `src/handlers/cr.c` |
| Anomalous / synthetic-hypervisor MSRs | MSR interception + #GP injection | `src/stealth.c`, `src/handlers/msr.c` |
| Physical memory scan for hypervisor pages | EPT identity map + decoy-page redirect | `src/ept.c` |
| HPET main counter timing | EPT trap + MTF emulation, TSC-coherent synthesis | `src/hpet.c`, `src/ept.c` |

> Research/educational use only. Build and run it on a **dedicated test machine**,
> never a production host.

## Layout

```
src/driver.c          DriverEntry/Unload, per-CPU virtualize/devirtualize broadcast
src/vmx.c             capability checks, VMXON, RtlCaptureContext launch, VMXOFF
src/vmcs.c            full VMCS host/guest/control population
src/vmexit.c          exit dispatcher + RIP advance + #GP/#UD injection
src/stealth.c         centralized transparency policy (CPUID/MSR/CR4)
src/ept.c             EPT identity map, page hiding, HPET/trap helpers
src/hpet.c            HPET spoofing: find/hide/synthesize/violation/MTF handlers
src/handlers/         cpuid.c, cr.c, msr.c, rdpmc.c, tsc.c
src/arch/asm/vmx.asm  exit trampoline + INVEPT stub + segment/descriptor readers
test/probe/           user-mode transparency probe (checks [1]–[5])
```

## Build

Requires Visual Studio + WDK (or the EWDK), x64.

```
msbuild minivisor.sln /p:Configuration=Release /p:Platform=x64
```

Output: `minivisor.sys`. Build the probe from an x64 Native Tools prompt:

```
cd test\probe
cl /O2 /W4 probe.c
```

## Load (test machine)

VMX-exit bugs bugcheck or hard-hang instantly, so **attach a kernel debugger
first** (WinDbg over net/serial).

```
bcdedit /set testsigning on        :: then reboot
bcdedit /debug on                  :: optional, with /dbgsettings

sc create minivisor type= kernel binPath= C:\path\to\minivisor.sys
sc start  minivisor
:: ... test ...
sc stop   minivisor
sc delete minivisor
```

`MV_LOG`/`MV_ERR` output (prefix `[minivisor]`) appears in the debugger; the
log filter is raised automatically in `LogInit`.

## Verify (incremental — confirm each before the next)

1. **Bring-up:** `sc start` succeeds, the OS keeps running, debugger shows
   `virtualized N CPU(s)` followed by one `tsc calibrate: CPU N native=X guest=Y
   fixedOverhead=Z` line per logical processor, and (if HPET present)
   `HPET: found at 0xFED00000, period=...fs`.
2. **CPUID present-bit:** `probe.exe` check [1] reports *hidden (pass)*.
3. **Vendor leaf:** check [2] reports CPUID.40000000h *matches* the max-basic-leaf
   data (bare-metal behavior).
4. **CPUID timing:** check [3] cycle count stays near a bare-metal reference (<~600).
5. **Cross-core TSC drift:** check [4] median delta stays below 200 cycles.
6. **RDPMC timing:** check [5] requires CR4.PCE=1 for user-mode RDPMC access.
   On standard Windows (PCE=0) it prints `skipped`. To enable: set CR4.PCE from a
   kernel context, then re-run — the spread between RDPMC and RDTSC should be
   <50 cycles.
7. **CR4 / reserved-MSR:** add a small ring-0 probe — guest `__readcr4()` must
   show VMXE=0; a reserved-MSR `__readmsr` must `#GP`.

### Detection suites (`test/detection/`)

Run these in the (now virtualized) OS and track how many checks fire before vs.
after each feature is enabled — the project's headline metric:

- **Pafish** — https://github.com/a0rtega/pafish
- **Al-Khaser** — https://github.com/LordNoteworthy/al-khaser
- **InviZzzible** — https://github.com/CheckPointSW/InviZzzible

## Hardening status

### Timing transparency

- **TSC offsetting** hides VM-exit overhead from `RDTSC` and `RDTSCP`.  The
  native CPUID cost is captured on every logical processor before VMXON and a
  post-launch pass on each core derives its own fixed overhead, so guest CPUID
  timing matches that core's native baseline.  A monotonicity clamp prevents
  the guest TSC from moving backward. (`src/handlers/tsc.c`, `DriverEntry`)

- **WRMSR IA32_TSC re-sync**: when the guest writes MSR 0x10 the CPU atomically
  adjusts `VMCS_TSC_OFFSET`; the handler re-reads it and updates `vcpu->TscOffset`
  so subsequent exits continue compensating from the new base.
  (`src/handlers/msr.c`, `src/stealth.c`)

- **RDPMC interception**: fixed counter 1 (`CPU_CLK_UNHALTED.THREAD`,
  ECX=0x40000001) and fixed counter 2 (`CPU_CLK_UNHALTED.REF`) are the most common
  PMC-based timing probes. Both are intercepted and corrected by the same
  `vcpu->TscOffset` that hides TSC overhead. All other PMC indices pass through
  unchanged. (`src/handlers/rdpmc.c`)

- **HPET main counter spoofing**: the HPET physical page (0xFED00000) is trapped
  in the EPT (PTE=0). On a guest read to the main counter offset (0xF0), the handler
  exposes the real page for one instruction (via MTF single-step), then re-traps it
  and patches the destination register with a synthesized value: `BaseCounter +
  (guest_tsc_delta × RatioScaled20) >> 20`.  This makes the HPET appear to advance
  at exactly the guest-visible TSC rate. (`src/hpet.c`, `src/ept.c`)

### Memory transparency

- **EPT identity map**: all physical memory is mapped 1:1 as RWX in EPT, so the
  guest runs at native performance without any address-translation overhead.

- **Hypervisor page hiding**: the VCPU array (containing VMXON, VMCS, MSR bitmaps,
  host stacks) and the EPT tables themselves are silently redirected to a zeroed decoy
  page in the EPT.  A guest physical-memory scan reads zeros for those pages rather
  than the hypervisor's internal state. (`src/ept.c`, `DriverEntry`)

### Instruction and register transparency

- **CR4.VMXE** is masked from the guest via the CR4 guest/host mask and read shadow,
  so the guest always reads VMXE=0. Writes to CR4 that include VMXE are handled by
  the CR access exit handler. (`src/vmcs.c`, `src/handlers/cr.c`)

- **XSETBV** is fully validated (index, x87/SSE/AVX/AVX-512 dependencies, reserved
  bits vs CPUID.0xD) and injects #GP rather than faulting the host. (`src/vmexit.c`)

- **MSR interception** passes through real RDMSR/WRMSR under SEH (filtered to
  `STATUS_PRIVILEGED_INSTRUCTION` / `EXCEPTION_PRIV_INSTRUCTION` only, so host
  bugs are not silently swallowed), so out-of-range MSRs behave bit-identically to
  bare metal while the synthetic-hypervisor range is reported absent.
  (`src/handlers/msr.c`)

- **CPUID/VMX consistency**: VMX is hidden in CPUID.1 ECX and FEATURE_CONTROL is
  spoofed to match, so the #UD injected on VMX instructions is consistent with a
  machine that has VT-x disabled in firmware.

### Robustness

- **Unhandled VM-exit default**: any exit reason the dispatcher does not recognise
  injects #UD so the guest takes a defined fault rather than re-executing the same
  instruction forever. The reason is logged as `[minivisor][!]` for diagnosis.

## Known limits (still open)

- **APIC local timer (0xFEE00000)** is not yet spoofed. A probe that reads the
  APIC current-count register before and after a CPUID sees real elapsed cycles.
  A similar EPT trap + MTF approach to HPET is feasible for xAPIC mode; x2APIC
  requires MSR interception instead (the timer registers become MSR-accessible).

- **RDPMC check [5]** in `probe.exe` requires `CR4.PCE=1` for user-mode RDPMC
  access. On standard Windows this bit is 0, so the check always prints "skipped".
  Enable PCE from a kernel context (or temporarily from the driver) to exercise it.

- **HPET MTF race**: on multi-VCPU systems another core may briefly see the real HPET
  page between `EptSetGpaPresent` and `EptInvalidateAll` (nanosecond window).  Not
  practically exploitable with commodity probes.

- **RTC (ports 0x70/0x71)** has ~1 Hz resolution — too coarse to detect sub-
  microsecond exit latency. I/O bitmap interception is not a meaningful improvement
  and is left unimplemented.

- **Cross-core TSC drift** under heavy asymmetric exit load is a fundamental
  tradeoff: hiding a core's own exit overhead and keeping all cores bit-identical are
  mutually exclusive. Per-VCPU calibration minimises the *initial* divergence; EPT-
  driven exit-count reduction is the real lever for runtime drift.  Use `probe.exe`
  check [4] to measure the rendezvous delta before/after load.

- Intel VT-x only; no AMD SVM, no UEFI/bare-metal load, single-OS blue-pill.
