;
; probe_x87.asm - optional faithful FYL2XP1 timing reference for probe.c.
;
; FYL2XP1 is a fixed-latency x87 op that does NOT cause a VM-exit, which is why
; anti-VM malware uses it as the baseline against CPUID (which does).  MSVC x64
; cannot emit FYL2XP1 from C, so this provides it.
;
; Build & link with the probe:
;     ml64 /c probe_x87.asm
;     cl /O2 /W4 probe.c probe_x87.obj
; and declare in probe.c:
;     extern unsigned __int64 ProbeFyl2xp1Cycles(unsigned int iterations);
;
; Returns the total TSC cycles for `iterations` FYL2XP1 operations (rcx = count).
; RDTSC here is not serialized; this is a coarse reference, adequate for the
; CPUID-vs-FYL2XP1 ratio that the detection technique relies on.
;
.code
PUBLIC ProbeFyl2xp1Cycles
ProbeFyl2xp1Cycles PROC
    mov     r8d, ecx            ; iteration count
    rdtsc
    shl     rdx, 32
    or      rax, rdx
    mov     r9, rax             ; start TSC

fyl_loop:
    fld1                        ; st0 = 1.0  (y)
    fldz                        ; st0 = 0.0 (x, in valid range), st1 = 1.0 (y)
    fyl2xp1                     ; st1 = y * log2(x+1) = 0; pop -> st0 = result
    fstp    st(0)               ; pop result; x87 stack balanced
    dec     r8d
    jnz     fyl_loop

    rdtsc
    shl     rdx, 32
    or      rax, rdx
    sub     rax, r9             ; total cycles
    ret
ProbeFyl2xp1Cycles ENDP
END
