

#include <windows.h>
#include <intrin.h>
#include <stdio.h>
#include <stdlib.h>

#define TIMING_SAMPLES      20000u
#define RENDEZVOUS_TRIALS   200u
#define RDPMC_SAMPLES       10000u

static int CompareU64(const void* a, const void* b)
{
    unsigned __int64 x = *(const unsigned __int64*)a;
    unsigned __int64 y = *(const unsigned __int64*)b;
    return (x < y) ? -1 : (x > y) ? 1 : 0;
}

static unsigned __int64 MeasureCpuidCycles(void)
{
    static unsigned __int64 samples[TIMING_SAMPLES];
    int regs[4];
    unsigned int aux;

    for (unsigned i = 0; i < TIMING_SAMPLES; i++)
    {
        unsigned __int64 t0 = __rdtscp(&aux);
        __cpuid(regs, 0);
        unsigned __int64 t1 = __rdtscp(&aux);
        samples[i] = t1 - t0;
    }

    qsort(samples, TIMING_SAMPLES, sizeof(samples[0]), CompareU64);
    return samples[TIMING_SAMPLES / 2];
}

static volatile LONG    g_Barrier;
static volatile __int64 g_Tsc[2];

static DWORD WINAPI TscReadThread(LPVOID param)
{
    int cpu = (int)(intptr_t)param;

    SetThreadAffinityMask(GetCurrentThread(), (DWORD_PTR)1 << cpu);

    
    InterlockedIncrement(&g_Barrier);
    while (g_Barrier < 2)
    {
        YieldProcessor();
    }
    g_Tsc[cpu] = (__int64)__rdtsc();
    return 0;
}

static unsigned __int64 AbsDelta(__int64 a, __int64 b)
{
    __int64 d = a - b;
    return (unsigned __int64)(d < 0 ? -d : d);
}

static unsigned __int64 MeasureCrossCoreDelta(void)
{
    static unsigned __int64 deltas[RENDEZVOUS_TRIALS];

    for (unsigned t = 0; t < RENDEZVOUS_TRIALS; t++)
    {
        HANDLE threads[2];

        g_Barrier = 0;
        g_Tsc[0]  = 0;
        g_Tsc[1]  = 0;

        threads[0] = CreateThread(NULL, 0, TscReadThread, (LPVOID)(intptr_t)0, 0, NULL);
        threads[1] = CreateThread(NULL, 0, TscReadThread, (LPVOID)(intptr_t)1, 0, NULL);

        WaitForMultipleObjects(2, threads, TRUE, INFINITE);
        CloseHandle(threads[0]);
        CloseHandle(threads[1]);

        deltas[t] = AbsDelta(g_Tsc[0], g_Tsc[1]);
    }

    qsort(deltas, RENDEZVOUS_TRIALS, sizeof(deltas[0]), CompareU64);
    return deltas[RENDEZVOUS_TRIALS / 2];
}

static BOOL RdpmcAccessible(void)
{
    __try
    {
        unsigned __int64 v = __readpmc(0x40000001);
        (void)v;
        return TRUE;
    }
    __except (GetExceptionCode() == EXCEPTION_PRIV_INSTRUCTION
              ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH)
    {
        return FALSE;
    }
}

static unsigned __int64 MeasureRdpmcCycles(void)
{
    static unsigned __int64 samples[RDPMC_SAMPLES];
    int regs[4];

    for (unsigned i = 0; i < RDPMC_SAMPLES; i++)
    {
        unsigned __int64 t0 = __readpmc(0x40000001);
        __cpuid(regs, 0);
        unsigned __int64 t1 = __readpmc(0x40000001);
        samples[i] = t1 - t0;
    }

    qsort(samples, RDPMC_SAMPLES, sizeof(samples[0]), CompareU64);
    return samples[RDPMC_SAMPLES / 2];
}

int main(void)
{
    int regs[4];
    int leaf0[4];

    
    SetThreadAffinityMask(GetCurrentThread(), 1);
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);

    printf("== MiniVisor-v2 transparency probe ==\n\n");

    
    __cpuid(regs, 1);
    {
        int hvBit = (regs[2] >> 31) & 1;
        printf("[1] CPUID.1 ECX[31] hypervisor-present : %d  -> %s\n",
               hvBit, hvBit ? "DETECTED (fail)" : "hidden (pass)");
    }

    
    __cpuid(leaf0, 0);                 
    {
        int hv[4], maxLeaf[4];
        __cpuid(hv, 0x40000000);
        __cpuidex(maxLeaf, leaf0[0], 0);
        int match = (hv[0] == maxLeaf[0] && hv[1] == maxLeaf[1] &&
                     hv[2] == maxLeaf[2] && hv[3] == maxLeaf[3]);
        printf("[2] CPUID.40000000h = %08X %08X %08X %08X\n",
               hv[0], hv[1], hv[2], hv[3]);
        printf("    bare-metal expected (max-leaf %02Xh data)        -> %s\n",
               leaf0[0], match ? "matches (pass)" : "anomalous (fail)");
    }

    
    unsigned __int64 cpuidCycles = 0;
    {
        cpuidCycles = MeasureCpuidCycles();
        printf("[3] CPUID median cost                  : %llu cycles\n", cpuidCycles);
        printf("    heuristic: <~600 plausibly native, >~2000 likely a VM-exit\n");
    }

    
    {
        SYSTEM_INFO si;
        GetSystemInfo(&si);
        if (si.dwNumberOfProcessors >= 2)
        {
            unsigned __int64 delta = MeasureCrossCoreDelta();
            const char* verdict = (delta < 200)  ? "pass (<200)"  :
                                  (delta < 1000) ? "marginal"     : "DRIFT (fail)";
            printf("[4] Cross-core TSC rendezvous (CPU0 vs CPU1), median delta: %llu cycles\n",
                   delta);
            printf("    heuristic: <200 bare-metal, >1000 likely per-VCPU offset drift -> %s\n",
                   verdict);
        }
        else
        {
            printf("[4] Cross-core TSC rendezvous        : skipped (single-CPU system)\n");
        }
    }

    

    {
        if (!RdpmcAccessible())
        {
            printf("[5] RDPMC timing                       : skipped (CR4.PCE not set)\n");
            printf("    Set PCE in CR4 from kernel or run as system to enable this check.\n");
        }
        else
        {
            unsigned __int64 pmcCyc = MeasureRdpmcCycles();
            unsigned __int64 diff   = (pmcCyc > cpuidCycles)
                                      ? (pmcCyc - cpuidCycles)
                                      : (cpuidCycles - pmcCyc);
            const char* verdict = (diff < 50)   ? "pass (<50 cycle spread)"  :
                                  (diff < 200)  ? "marginal"                 :
                                                  "LEAK (fail — RDPMC shows higher cost than RDTSC)";
            printf("[5] RDPMC(FCR1) median cost            : %llu cycles (RDTSC was %llu)\n",
                   pmcCyc, cpuidCycles);
            printf("    spread: %llu cycles -> %s\n", diff, verdict);
        }
    }

    printf("\nDone.\n");
    return 0;
}
