

#include "minivisor.h"
#include <intrin.h>

static PHPET_STATE
HpetGlobal(VOID)
{
    return &g_Hv.Hpet;
}

static PVOID
MapPhysPage(UINT64 pa)
{
    PHYSICAL_ADDRESS phys;
    phys.QuadPart = (LONGLONG)pa;
    return MmMapIoSpace(phys, PAGE_SIZE, MmNonCached);
}

BOOLEAN
HpetFind(PHPET_STATE hpet)
{
    PUCHAR  va;
    UINT64  gcap;
    UINT64  period;

    

    va = (PUCHAR)MapPhysPage(HPET_CANDIDATE_BASE);
    if (va == NULL)
    {
        MV_LOG("HPET: failed to map 0xFED00000");
        return FALSE;
    }

    
    gcap   = *(volatile UINT64*)(va + HPET_GCAP_ID_OFFSET);
    period = gcap >> HPET_PERIOD_SHIFT;

    if (period < HPET_PERIOD_MIN_FS || period > HPET_PERIOD_MAX_FS)
    {
        MmUnmapIoSpace(va, PAGE_SIZE);
        MV_LOG("HPET: GCAP_ID period %llu fs out of expected range — not an HPET", period);
        return FALSE;
    }

    hpet->PeriodFs = period;

    
    hpet->BaseTsc     = __rdtsc();
    hpet->BaseCounter = *(volatile UINT64*)(va + HPET_MAIN_COUNTER_OFFSET);

    MmUnmapIoSpace(va, PAGE_SIZE);

    hpet->PhysBase = HPET_CANDIDATE_BASE;

    

    {
        LARGE_INTEGER tscFreqLi;
        UINT64 fHpet;
        UINT64 fTsc;

        KeQueryPerformanceCounter(&tscFreqLi);
        fTsc  = (UINT64)tscFreqLi.QuadPart;
        fHpet = 1000000000000000ULL / period;   

        if (fTsc == 0)
        {
            MV_ERR("HPET: TSC frequency 0 — cannot compute synthesis ratio");
            return FALSE;
        }

        hpet->RatioScaled20 = (fHpet << 20) / fTsc;
    }

    hpet->Valid = TRUE;

    MV_LOG("HPET: found at 0x%llx, period=%llufs, F_hpet=%llu Hz, ratio<<20=%llu",
           hpet->PhysBase,
           hpet->PeriodFs,
           1000000000000000ULL / hpet->PeriodFs,
           hpet->RatioScaled20);
    return TRUE;
}

BOOLEAN
HpetHide(PHPET_STATE hpet, PEPT_STATE ept)
{
    if (!hpet->Valid)
    {
        return TRUE;    
    }

    
    if (!EptTrapRange(ept, hpet->PhysBase, PAGE_SIZE))
    {
        MV_ERR("HPET: EptTrapRange failed for 0x%llx", hpet->PhysBase);
        return FALSE;
    }

    MV_LOG("HPET: page 0x%llx trapped in EPT", hpet->PhysBase);
    return TRUE;
}

UINT64
HpetSynthesize(PHPET_STATE hpet, PVCPU vcpu)
{
    UINT64 hwTsc     = __rdtsc();
    INT64  guestTsc  = (INT64)hwTsc + vcpu->TscOffset;
    INT64  deltaTsc  = guestTsc - (INT64)hpet->BaseTsc;
    INT64  hpetDelta = (deltaTsc * (INT64)hpet->RatioScaled20) >> 20;

    
    if (hpetDelta < 0)
    {
        hpetDelta = 0;
    }

    return hpet->BaseCounter + (UINT64)hpetDelta;
}

VOID
HpetHandleViolation(PVCPU vcpu, PVMEXIT_FRAME frame)
{
    PHPET_STATE hpet = HpetGlobal();
    SIZE_T      gpa  = 0;
    SIZE_T      qual = 0;
    UINT64      offset;
    BOOLEAN     isRead;
    SIZE_T      procCtl = 0;

    __vmx_vmread(VMCS_GUEST_PHYSICAL_ADDRESS, &gpa);
    __vmx_vmread(VMCS_EXIT_QUALIFICATION,     &qual);

    offset = (UINT64)gpa - hpet->PhysBase;
    isRead = (qual & 1) != 0;

    if (isRead && offset == HPET_MAIN_COUNTER_OFFSET)
    {
        
        vcpu->HpetMtfPending  = TRUE;
        vcpu->HpetSynthetic   = HpetSynthesize(hpet, vcpu);
        vcpu->HpetGprsBefore  = frame->Regs;
    }
    else
    {
        
        vcpu->HpetMtfPending = FALSE;
    }

    
    vcpu->MtfExposedPage = hpet->PhysBase;

    
    EptSetGpaPresent(&g_Hv.Ept, hpet->PhysBase, TRUE);
    EptInvalidateAll(&g_Hv.Ept);   

    
    __vmx_vmread(VMCS_CTRL_PROC_BASED, &procCtl);
    __vmx_vmwrite(VMCS_CTRL_PROC_BASED, procCtl | PROC_CTL_MONITOR_TRAP_FLAG);

    
}

VOID
HpetHandleMtf(PVCPU vcpu, PVMEXIT_FRAME frame)
{
    PHPET_STATE hpet    = HpetGlobal();
    SIZE_T      procCtl = 0;

    
    EptSetGpaPresent(&g_Hv.Ept, hpet->PhysBase, FALSE);
    EptInvalidateAll(&g_Hv.Ept);

    
    __vmx_vmread(VMCS_CTRL_PROC_BASED, &procCtl);
    __vmx_vmwrite(VMCS_CTRL_PROC_BASED, procCtl & ~(SIZE_T)PROC_CTL_MONITOR_TRAP_FLAG);

    if (vcpu->HpetMtfPending)
    {
        
        UINT64* before = (UINT64*)&vcpu->HpetGprsBefore;
        UINT64* after  = (UINT64*)&frame->Regs;
        ULONG   i;

        for (i = 0; i < (sizeof(GUEST_REGISTERS) / sizeof(UINT64)); i++)
        {
            if (before[i] != after[i])
            {
                after[i] = vcpu->HpetSynthetic;
                break;
            }
        }

        vcpu->HpetMtfPending = FALSE;
    }
}
