/*
 * pit.c - Intel 8254 PIT (i/o ports 0x40-0x43) channel-0 read spoofing.
 *
 * The article lists the PIT among the independent timers a detector can bracket
 * a CPUID loop with.  Like the ACPI PM timer it is read over an I/O port, so we
 * trap channel-0 accesses with the I/O bitmap and synthesize a TSC-coherent
 * value.  Channel 0 is a 1.193182 MHz down-counter; software reads it by writing
 * a latch command to the command port (0x43) then reading the data port (0x40)
 * low byte then high byte (the common lobyte/hibyte access mode).
 *
 * Strategy:
 *   - Track the channel-0 access mode from command-port writes.
 *   - On a channel-0 latch command, snapshot a synthetic counter value.
 *   - On data-port reads, serve that value (or a fresh live one) byte by byte.
 *   - PASS THROUGH all writes to the real PIT so the OS's own programming and
 *     IRQ0 timer keep working — we only forge what the guest *reads*.
 *
 * Counter synthesis (free-running, reload = 65536, mode-2/3 style down-count):
 *   ticks  = (guest_tsc - BaseTsc) * PIT_FREQ_HZ / F_tsc
 *   count  = (UINT16)(0 - ticks)      // 16-bit down-counter
 *   where guest_tsc = hw_tsc + vcpu->TscOffset (TSC-offset-compensated view), so
 *   a PIT-bracketed CPUID sees the same elapsed time as a clean machine.
 *
 * Because a timing detector compares the *delta* of two reads, the absolute
 * reload the OS programmed does not matter — only that the value advances at the
 * guest-visible rate.  Modern Windows does not read the PIT for timekeeping after
 * boot, so forging reads is low-risk; writes still reach the hardware.
 *
 * Set MV_SPOOF_PIT to 0 to disable (no I/O-bitmap bits are set when disabled).
 */
#include "minivisor.h"
#include <intrin.h>

#define MV_SPOOF_PIT  1

BOOLEAN
PitInit(PPIT_STATE pit)
{
    LARGE_INTEGER freqLi;
    UINT64 fTsc;

    RtlZeroMemory(pit, sizeof(*pit));

#if !MV_SPOOF_PIT
    return FALSE;
#else
    KeQueryPerformanceCounter(&freqLi);     /* QPC freq == TSC freq (invariant) */
    fTsc = (UINT64)freqLi.QuadPart;
    if (fTsc == 0)
    {
        MV_ERR("PIT: TSC frequency 0 — cannot compute synthesis ratio");
        return FALSE;
    }

    pit->BaseTsc     = __rdtsc();
    pit->RatioScaled = (PIT_FREQ_HZ << PIT_RATIO_SHIFT) / fTsc;
    pit->AccessMode  = 3;       /* lobyte/hibyte — Windows' channel-0 default */
    pit->Valid       = TRUE;

    MV_LOG("PIT: channel-0 spoofing armed, ratio<<%u=%llu",
           PIT_RATIO_SHIFT, pit->RatioScaled);
    return TRUE;
#endif
}

static UINT16
PitSynthesize(PPIT_STATE pit, PVCPU vcpu)
{
    UINT64 guestTsc = (UINT64)((INT64)__rdtsc() + vcpu->TscOffset);
    UINT64 dt       = guestTsc - pit->BaseTsc;
    UINT64 ticks    = (dt * pit->RatioScaled) >> PIT_RATIO_SHIFT;

    /* 16-bit down-counter from a 65536 reload: count = 65536 - (ticks mod 65536). */
    return (UINT16)(0u - (UINT16)(ticks & 0xFFFFu));
}

BOOLEAN
PitHandleIo(PVCPU vcpu, PGUEST_REGISTERS regs,
            UINT32 port, UINT32 size, BOOLEAN isIn)
{
    PPIT_STATE pit = &g_Hv.Pit;

    UNREFERENCED_PARAMETER(size);

    if (!pit->Valid)
    {
        return FALSE;
    }

    /* ---- command port (0x43): write-only on real hardware ---- */
    if (port == PIT_CMD_PORT)
    {
        if (!isIn)
        {
            UINT8 cmd     = (UINT8)regs->Rax;
            UINT8 channel = (UINT8)(cmd >> 6);
            UINT8 access  = (UINT8)((cmd >> 4) & 3);

            if (channel == 0)
            {
                if (access == 0)
                {
                    /* Counter-latch command: capture the synthetic count now. */
                    vcpu->PitLatch       = PitSynthesize(pit, vcpu);
                    vcpu->PitLatchActive = TRUE;
                    vcpu->PitReadPhase   = 0;
                }
                else
                {
                    /* Mode/access programming: remember the access mode. */
                    pit->AccessMode      = access;
                    vcpu->PitReadPhase   = 0;
                    vcpu->PitLatchActive = FALSE;
                }
            }

            /* Keep the real PIT in sync with the guest's programming. */
            __outbyte(PIT_CMD_PORT, cmd);
        }
        VmExitAdvanceRip();
        return TRUE;
    }

    /* ---- channel-0 data port (0x40) ---- */
    if (port == PIT_CH0_DATA_PORT)
    {
        if (isIn)
        {
            UINT8 mode = pit->AccessMode;
            UINT8 byte;

            if (mode == 3)
            {
                if (vcpu->PitReadPhase == 0)
                {
                    vcpu->PitReadValue = vcpu->PitLatchActive ? vcpu->PitLatch
                                                              : PitSynthesize(pit, vcpu);
                    byte = (UINT8)(vcpu->PitReadValue & 0xFF);
                    vcpu->PitReadPhase = 1;
                }
                else
                {
                    byte = (UINT8)(vcpu->PitReadValue >> 8);
                    vcpu->PitReadPhase = 0;
                    vcpu->PitLatchActive = FALSE;    /* latch consumed */
                }
            }
            else
            {
                UINT16 v = vcpu->PitLatchActive ? vcpu->PitLatch : PitSynthesize(pit, vcpu);
                byte = (mode == 2) ? (UINT8)(v >> 8) : (UINT8)(v & 0xFF);
                vcpu->PitLatchActive = FALSE;
            }

            regs->Rax = (regs->Rax & ~(UINT64)0xFF) | (UINT64)byte;
        }
        else
        {
            /* Reload programming: pass the byte through to the real PIT. */
            __outbyte(PIT_CH0_DATA_PORT, (UCHAR)regs->Rax);
        }
        VmExitAdvanceRip();
        return TRUE;
    }

    return FALSE;
}
