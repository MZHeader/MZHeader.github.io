

#include "minivisor.h"
#include <intrin.h>
#include <ntstrsafe.h>

static VOID
ArmMtf(PVCPU vcpu)
{
    SIZE_T procCtl = 0;
    UNREFERENCED_PARAMETER(vcpu);
    __vmx_vmread(VMCS_CTRL_PROC_BASED, &procCtl);
    __vmx_vmwrite(VMCS_CTRL_PROC_BASED, procCtl | PROC_CTL_MONITOR_TRAP_FLAG);
}

static VOID
DisarmMtf(PVCPU vcpu)
{
    SIZE_T procCtl = 0;
    __vmx_vmread(VMCS_CTRL_PROC_BASED, &procCtl);
    __vmx_vmwrite(VMCS_CTRL_PROC_BASED, procCtl & ~(SIZE_T)PROC_CTL_MONITOR_TRAP_FLAG);
    UNREFERENCED_PARAMETER(vcpu);
}

static VOID
SwapToShadow(PSHADOW_HOOK hook)
{
    EptShadowSetFull(&g_Hv.Ept, hook->Gpa4Kb, hook->ShadowPa);
    EptInvalidateAll(&g_Hv.Ept);
}

static VOID
SwapToExec(PSHADOW_HOOK hook)
{
    EptShadowSetExec(&g_Hv.Ept, hook->Gpa4Kb, hook->ExecPa);
    EptInvalidateAll(&g_Hv.Ept);
}

BOOLEAN
ShadowHookInstall(UINT64 targetVa, PCSTR tag)
{
    SHADOW_HOOK*     hook;
    PHYSICAL_ADDRESS pa;
    UINT64           gpa4kb;
    UINT32           hookOffset;
    PUCHAR           srcPage;
    ULONG            i;
    KIRQL            oldIrql;
    PVOID            preExecVa   = NULL;
    PVOID            preShadowVa = NULL;
    UINT64           preExecPa   = 0;
    UINT64           preShadowPa = 0;
    BOOLEAN          usedPreAlloc = FALSE;

    /* MmAllocateContiguousMemory requires IRQL <= APC_LEVEL — must run before
     * KeAcquireSpinLock raises to DISPATCH_LEVEL. */
    preExecVa   = MemAllocContiguous(PAGE_SIZE);
    preShadowVa = MemAllocContiguous(PAGE_SIZE);
    if (!preExecVa || !preShadowVa)
    {
        if (preExecVa)   MemFreeContiguous(preExecVa);
        if (preShadowVa) MemFreeContiguous(preShadowVa);
        MV_ERR("HOOK: pre-alloc failed for '%s'", tag);
        return FALSE;
    }
    preExecPa   = MemVirtualToPhysical(preExecVa);
    preShadowPa = MemVirtualToPhysical(preShadowVa);

    pa         = MmGetPhysicalAddress((PVOID)targetVa);
    gpa4kb     = (UINT64)pa.QuadPart & ~(UINT64)(PAGE_SIZE - 1);
    hookOffset = (UINT32)((UINT64)pa.QuadPart & (UINT64)(PAGE_SIZE - 1));
    srcPage    = (PUCHAR)(targetVa & ~(UINT64)(PAGE_SIZE - 1));

    /* Copy source page before the spinlock — source is non-paged ntoskrnl code. */
    RtlCopyMemory(preExecVa,   srcPage, PAGE_SIZE);
    RtlCopyMemory(preShadowVa, srcPage, PAGE_SIZE);

    KeAcquireSpinLock(&g_Hv.HookTableLock, &oldIrql);

    if (g_Hv.ShadowHookCount >= MV_SHADOW_HOOK_MAX)
    {
        MV_ERR("HOOK: shadow hook table full (%u)", MV_SHADOW_HOOK_MAX);
        KeReleaseSpinLock(&g_Hv.HookTableLock, oldIrql);
        MemFreeContiguous(preExecVa);
        MemFreeContiguous(preShadowVa);
        return FALSE;
    }

    {
        PSHADOW_HOOK existing = NULL;
        for (i = 0; i < g_Hv.ShadowHookCount; i++)
        {
            if (g_Hv.ShadowHooks[i].Gpa4Kb == gpa4kb)
            {
                existing = &g_Hv.ShadowHooks[i];
                break;
            }
        }

        hook = &g_Hv.ShadowHooks[g_Hv.ShadowHookCount];

        if (existing != NULL)
        {
            hook->ExecVa     = existing->ExecVa;
            hook->ShadowVa   = existing->ShadowVa;
            hook->ExecPa     = existing->ExecPa;
            hook->ShadowPa   = existing->ShadowPa;
            hook->SharedPage = TRUE;
        }
        else
        {
            hook->ExecVa     = preExecVa;
            hook->ShadowVa   = preShadowVa;
            hook->ExecPa     = preExecPa;
            hook->ShadowPa   = preShadowPa;
            hook->SharedPage = FALSE;
            usedPreAlloc     = TRUE;
        }
    }

    hook->OriginalByte             = ((PUCHAR)hook->ShadowVa)[hookOffset];
    ((PUCHAR)hook->ExecVa)[hookOffset] = 0xCC;

    hook->TargetVa   = targetVa;
    hook->Gpa4Kb     = gpa4kb;
    hook->HookOffset = hookOffset;
    hook->OnBp       = NULL;
    hook->Active     = TRUE;

    RtlStringCbCopyA(hook->Tag, MV_HOOK_TAG_SIZE, tag);

    if (!hook->SharedPage)
    {
        EptShadowSetExec(&g_Hv.Ept, gpa4kb, hook->ExecPa);
    }

    MemoryBarrier();
    g_Hv.ShadowHookCount++;

    KeReleaseSpinLock(&g_Hv.HookTableLock, oldIrql);

    /* Free the pre-allocated pages if they weren't consumed (shared-page path). */
    if (!usedPreAlloc)
    {
        MemFreeContiguous(preExecVa);
        MemFreeContiguous(preShadowVa);
    }

    MV_LOG("HOOK: installed '%s' at VA=%llx GPA=%llx+%03x (exec=%llx shadow=%llx)",
           hook->Tag, hook->TargetVa, hook->Gpa4Kb, hook->HookOffset,
           hook->ExecPa, hook->ShadowPa);
    return TRUE;
}

BOOLEAN
ShadowHookInstallEx(UINT64 targetVa, PCSTR tag, PSHADOW_HOOK_CALLBACK onBp)
{
    PSHADOW_HOOK hook;
    if (!ShadowHookInstall(targetVa, tag))
    {
        return FALSE;
    }
    hook = ShadowHookFindByInt3(targetVa);
    if (hook != NULL)
    {
        hook->OnBp = onBp;
    }
    return TRUE;
}

static ULONG_PTR
ForceInveptIpi(ULONG_PTR context)
{
    int regs[4];
    UNREFERENCED_PARAMETER(context);
    
    __cpuid(regs, 0);
    return 0;
}

static VOID
BroadcastInvept(VOID)
{
    ULONG i;
    for (i = 0; i < g_Hv.VcpuCount; i++)
    {
        g_Hv.Vcpus[i].EptInveptPending = TRUE;
    }
    KeIpiGenericCall(ForceInveptIpi, 0);
    
}

BOOLEAN
ShadowHookInstallRuntime(UINT64 targetVa, PCSTR tag)
{
    if (!g_Hv.VmxEnabled)
    {
        return ShadowHookInstall(targetVa, tag);
    }
    if (!ShadowHookInstall(targetVa, tag))
    {
        return FALSE;
    }
    BroadcastInvept();
    return TRUE;
}

BOOLEAN
ShadowHookInstallExRuntime(UINT64 targetVa, PCSTR tag, PSHADOW_HOOK_CALLBACK onBp)
{
    if (!g_Hv.VmxEnabled)
    {
        return ShadowHookInstallEx(targetVa, tag, onBp);
    }
    if (!ShadowHookInstallEx(targetVa, tag, onBp))
    {
        return FALSE;
    }
    BroadcastInvept();
    return TRUE;
}

PSHADOW_HOOK
ShadowHookFindByPage(UINT64 gpa4kb)
{
    ULONG i;
    for (i = 0; i < g_Hv.ShadowHookCount; i++)
    {
        if (g_Hv.ShadowHooks[i].Active && g_Hv.ShadowHooks[i].Gpa4Kb == gpa4kb)
        {
            return &g_Hv.ShadowHooks[i];
        }
    }
    return NULL;
}

PSHADOW_HOOK
ShadowHookFindByInt3(UINT64 int3Va)
{
    ULONG i;
    for (i = 0; i < g_Hv.ShadowHookCount; i++)
    {
        if (g_Hv.ShadowHooks[i].Active && g_Hv.ShadowHooks[i].TargetVa == int3Va)
        {
            return &g_Hv.ShadowHooks[i];
        }
    }
    return NULL;
}

VOID
ShadowHookHandleViolation(PVCPU vcpu, PVMEXIT_FRAME frame, UINT64 gpa, SIZE_T qual)
{
    UINT64 gpa4kb = gpa & ~(UINT64)(PAGE_SIZE - 1);
    PSHADOW_HOOK hook = ShadowHookFindByPage(gpa4kb);
    SIZE_T gla = 0, rip = 0;

    UNREFERENCED_PARAMETER(frame);

    if (hook == NULL)
    {
        
        MV_ERR("HOOK: violation at GPA %llx but no hook found", gpa);
        VmExitInjectUd();
        return;
    }

    __vmx_vmread(VMCS_GUEST_LINEAR_ADDRESS, &gla);
    __vmx_vmread(VMCS_GUEST_RIP,            &rip);

    MV_LOG("[HOOK] '%s' scan: %s GPA=%llx GLA=%llx RIP=%llx",
           hook->Tag,
           (qual & 2) ? "WRITE" : (qual & 4) ? "EXEC" : "READ",
           gpa, (UINT64)gla, (UINT64)rip);

    SwapToShadow(hook);
    ArmMtf(vcpu);
    vcpu->MtfShadowHook = hook;
}

VOID
ShadowHookHandleBp(PVCPU vcpu, PVMEXIT_FRAME frame, PSHADOW_HOOK hook)
{
    if (hook->OnBp != NULL)
    {
        
        hook->OnBp(vcpu, frame, hook);
    }
    else
    {
        SIZE_T guestRsp = 0;
        __vmx_vmread(VMCS_GUEST_RSP, &guestRsp);
        MV_LOG("[HOOK] '%s': RIP=%llx RSP=%llx RCX=%llx RDX=%llx R8=%llx R9=%llx",
               hook->Tag, hook->TargetVa, (UINT64)guestRsp,
               frame->Regs.Rcx, frame->Regs.Rdx, frame->Regs.R8, frame->Regs.R9);
    }

    
    __vmx_vmwrite(VMCS_GUEST_RIP, hook->TargetVa);
    SwapToShadow(hook);
    ArmMtf(vcpu);
    vcpu->MtfShadowHook = hook;
}

VOID
ShadowHookHandleMtf(PVCPU vcpu)
{
    PSHADOW_HOOK hook = vcpu->MtfShadowHook;

    DisarmMtf(vcpu);

    if (hook == NULL)
    {
        MV_ERR("HOOK: ShadowHookHandleMtf called with NULL hook on CPU %lu",
               vcpu->ProcessorIndex);
        return;
    }

    SwapToExec(hook);
    vcpu->MtfShadowHook = NULL;
}
