

#include "minivisor.h"
#include <intrin.h>
#include <ntstrsafe.h>

#define SYSCALL_NUM_MAX     4096u
#define SYSCALL_BM_BYTES    (SYSCALL_NUM_MAX / 8)

static UINT8   g_FilterBitmap[SYSCALL_BM_BYTES];
static BOOLEAN g_FilterAll = TRUE;

static ULONG g_NameCount;

ULONG
SyscallHookNameCount(VOID)
{
    return g_NameCount;
}

BOOLEAN
SyscallHookFilterAll(VOID)
{
    return g_FilterAll;
}

static BOOLEAN
SyscallIsLogged(UINT32 num)
{
    if (g_FilterAll)
    {
        return TRUE;
    }
    if (num >= SYSCALL_NUM_MAX)
    {
        return FALSE;
    }
    return (g_FilterBitmap[num >> 3] & (UINT8)(1u << (num & 7))) != 0;
}

VOID
SyscallHookAddFilter(UINT32 syscallNum)
{
    if (syscallNum >= SYSCALL_NUM_MAX)
    {
        MV_ERR("SYSCALL: filter number %u out of range", syscallNum);
        return;
    }
    g_FilterAll = FALSE;
    g_FilterBitmap[syscallNum >> 3] |= (UINT8)(1u << (syscallNum & 7));
    MV_LOG("SYSCALL: filter added #%04x", syscallNum);
}

VOID
SyscallHookClearFilter(VOID)
{
    RtlZeroMemory(g_FilterBitmap, sizeof(g_FilterBitmap));
    g_FilterAll = TRUE;
    MV_LOG("SYSCALL: filter cleared — logging all syscalls");
}

#define SYSCALL_NAME_MAX    512
#define SYSCALL_NAME_LEN    40

typedef struct _SYSCALL_NAME
{
    UINT32 Num;
    CHAR   Name[SYSCALL_NAME_LEN];
} SYSCALL_NAME;

static SYSCALL_NAME g_Names[SYSCALL_NAME_MAX];

#define MAX_VCPU_COUNT  64

typedef struct _PENDING_SYSCALL
{
    BOOLEAN Active;
    UINT32  Num;
    PCSTR   Name;   
    UINT64  Arg1;
    UINT64  Arg2;
    UINT64  Arg3;
    UINT64  Arg4;
} PENDING_SYSCALL;

static PENDING_SYSCALL g_Pending[MAX_VCPU_COUNT];

VOID
SyscallHookAddName(UINT32 syscallNum, PCSTR name)
{
    if (g_NameCount >= SYSCALL_NAME_MAX)
    {
        MV_ERR("SYSCALL: name table full");
        return;
    }
    g_Names[g_NameCount].Num = syscallNum;
    RtlStringCbCopyA(g_Names[g_NameCount].Name, SYSCALL_NAME_LEN, name);
    g_NameCount++;
}

static PCSTR
SyscallLookupName(UINT32 num)
{
    ULONG i;
    for (i = 0; i < g_NameCount; i++)
    {
        if (g_Names[i].Num == num)
        {
            return g_Names[i].Name;
        }
    }
    return NULL;
}

#pragma warning(suppress: 4201)
typedef struct _KSERVICE_DESCRIPTOR_TABLE
{
    PULONG  Table;
    PULONG  Count;
    ULONG   Limit;
    PUCHAR  Number;
} KSERVICE_DESCRIPTOR_TABLE, *PKSERVICE_DESCRIPTOR_TABLE;

static PKSERVICE_DESCRIPTOR_TABLE
ResolveSsdt(UINT64 lstar)
{
    PUCHAR p = (PUCHAR)lstar;
    ULONG  i;

    for (i = 0; i < 4096; i++)
    {
        BOOLEAN match = FALSE;
        __try
        {
            /* lea r10, [rip+disp32] — REX.WR opcode 4C 8D 15 */
            if (p[i] == 0x4C && p[i + 1] == 0x8D && p[i + 2] == 0x15)
                match = TRUE;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { break; }

        if (match)
        {
            LONG                       disp;
            PKSERVICE_DESCRIPTOR_TABLE table;

            __try { disp = *(LONG *)(p + i + 3); }
            __except (EXCEPTION_EXECUTE_HANDLER) { continue; }

            /* instruction is 7 bytes: 4C 8D 15 <disp32> */
            table = (PKSERVICE_DESCRIPTOR_TABLE)((ULONG_PTR)(p + i + 7) + (LONG_PTR)disp);

            if (!MmIsAddressValid(table))             continue;
            if (!MmIsAddressValid(table->Table))      continue;
            if (table->Limit == 0 || table->Limit > 4096) continue;

            return table;
        }
    }

    return NULL;
}

static PVOID
FindPeBase(PVOID addr)
{
    PUCHAR p = (PUCHAR)((ULONG_PTR)addr & ~(UINT64)(PAGE_SIZE - 1));
    ULONG  i;
    for (i = 0; i < (64 * 1024 * 1024 / PAGE_SIZE); i++, p -= PAGE_SIZE)
    {
        BOOLEAN found = FALSE;
        __try
        {
            if (p[0] == 'M' && p[1] == 'Z')
                found = TRUE;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        if (found) return p;
    }
    return NULL;
}

static PCSTR
PeExportNameByRva(PUCHAR base, ULONG targetRva)
{
    PIMAGE_DOS_HEADER    dos  = (PIMAGE_DOS_HEADER)base;
    PIMAGE_NT_HEADERS64  nt;
    PIMAGE_EXPORT_DIRECTORY exp;
    PULONG  funcs, names;
    PUSHORT ords;
    ULONG   i;

    if (dos->e_magic != IMAGE_DOS_SIGNATURE)
    {
        return NULL;
    }

    nt = (PIMAGE_NT_HEADERS64)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE)
    {
        return NULL;
    }

    if (nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].Size == 0)
    {
        return NULL;
    }

    exp   = (PIMAGE_EXPORT_DIRECTORY)(base +
            nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress);
    funcs = (PULONG)(base + exp->AddressOfFunctions);
    names = (PULONG)(base + exp->AddressOfNames);
    ords  = (PUSHORT)(base + exp->AddressOfNameOrdinals);

    for (i = 0; i < exp->NumberOfNames; i++)
    {
        if (funcs[ords[i]] == targetRva)
        {
            ULONG nameRva = names[i];
            if (nameRva == 0 || nameRva >= nt->OptionalHeader.SizeOfImage)
                return NULL;
            return (PCSTR)(base + nameRva);
        }
    }
    return NULL;
}

static VOID
SyscallPopulateNamesFromSsdt(UINT64 lstar)
{
    PKSERVICE_DESCRIPTOR_TABLE ssdt;
    PUCHAR ntBase;
    ULONG  i;

    ssdt = ResolveSsdt(lstar);
    if (ssdt == NULL)
    {
        MV_LOG("SYSCALL: could not resolve SSDT from KiSystemCall64");
        return;
    }

    ntBase = (PUCHAR)FindPeBase((PVOID)ssdt->Table);
    if (ntBase == NULL)
    {
        MV_LOG("SYSCALL: could not find ntoskrnl base for name discovery");
        return;
    }

    for (i = 0; i < ssdt->Limit; i++)
    {
        LONG      encoded = (LONG)ssdt->Table[i];
        ULONG_PTR funcVa  = (ULONG_PTR)ssdt->Table + (ULONG_PTR)(encoded >> 4);
        ULONG     funcRva = (ULONG)(funcVa - (ULONG_PTR)ntBase);
        PCSTR     name    = PeExportNameByRva(ntBase, funcRva);

        if (name != NULL && g_NameCount < SYSCALL_NAME_MAX)
        {
            SyscallHookAddName(i, name);
        }
    }

    MV_LOG("SYSCALL: populated %lu names from SSDT+export table", g_NameCount);
}

static VOID
SyscallOnBp(PVCPU vcpu, PVMEXIT_FRAME frame, PSHADOW_HOOK hook)
{
    UINT32 num  = (UINT32)frame->Regs.Rax;
    PCSTR  name = SyscallLookupName(num);
    ULONG  cpu  = vcpu->ProcessorIndex;

    UNREFERENCED_PARAMETER(hook);

    
    if (cpu < MAX_VCPU_COUNT)
    {
        g_Pending[cpu].Active = TRUE;
        g_Pending[cpu].Num    = num;
        g_Pending[cpu].Name   = name;
        g_Pending[cpu].Arg1   = frame->Regs.R10;
        g_Pending[cpu].Arg2   = frame->Regs.Rdx;
        g_Pending[cpu].Arg3   = frame->Regs.R8;
        g_Pending[cpu].Arg4   = frame->Regs.R9;
    }

    if (!SyscallIsLogged(num))
    {
        return;
    }

    if (name != NULL)
    {
        MV_LOG("[SYSCALL>>] CPU%lu #%04x %-40s retaddr=%llx arg1=%llx arg2=%llx arg3=%llx arg4=%llx",
               cpu, num, name,
               frame->Regs.Rcx,
               frame->Regs.R10, frame->Regs.Rdx,
               frame->Regs.R8,  frame->Regs.R9);
    }
    else
    {
        MV_LOG("[SYSCALL>>] CPU%lu #%04x retaddr=%llx arg1=%llx arg2=%llx arg3=%llx arg4=%llx",
               cpu, num,
               frame->Regs.Rcx,
               frame->Regs.R10, frame->Regs.Rdx,
               frame->Regs.R8,  frame->Regs.R9);
    }
}

static VOID
SyscallReturnOnBp(PVCPU vcpu, PVMEXIT_FRAME frame, PSHADOW_HOOK hook)
{
    ULONG  cpu    = vcpu->ProcessorIndex;
    UINT32 status = (UINT32)frame->Regs.Rax;

    UNREFERENCED_PARAMETER(hook);

    if (cpu >= MAX_VCPU_COUNT || !g_Pending[cpu].Active)
    {
        return;
    }

    if (SyscallIsLogged(g_Pending[cpu].Num))
    {
        if (g_Pending[cpu].Name != NULL)
        {
            MV_LOG("[SYSCALL<<] CPU%lu #%04x %-40s status=%08x",
                   cpu, g_Pending[cpu].Num, g_Pending[cpu].Name, status);
        }
        else
        {
            MV_LOG("[SYSCALL<<] CPU%lu #%04x status=%08x",
                   cpu, g_Pending[cpu].Num, status);
        }
    }

    g_Pending[cpu].Active = FALSE;
}

static UINT64
ScanForSysret(UINT64 startVa)
{
    PUCHAR p    = (PUCHAR)startVa;
    ULONG  i;
    UINT64 last = 0;

    for (i = 0; i < 8192 - 2; i++)
    {
        BOOLEAN match = FALSE;
        __try
        {
            if (p[i] == 0x48 && p[i + 1] == 0x0F && p[i + 2] == 0x07)
                match = TRUE;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { break; }
        if (match)
            last = startVa + i;
    }

    if (last == 0)
    {
        MV_ERR("SYSCALL: SYSRETQ not found within 8192 bytes of %llx", startVa);
    }

    return last;
}

VOID
SyscallHookInit(VOID)
{
    UINT64 lstar    = __readmsr(IA32_LSTAR);
    UINT64 sysretVa;

    MV_LOG("SYSCALL: KiSystemCall64 at %llx", lstar);

    
    SyscallPopulateNamesFromSsdt(lstar);

    if (!ShadowHookInstallEx(lstar, "KiSystemCall64", SyscallOnBp))
    {
        MV_ERR("SYSCALL: entry hook install failed — syscall logging disabled");
        return;
    }

    

    sysretVa = ScanForSysret(lstar);
    if (sysretVa != 0)
    {
        if (!ShadowHookInstallEx(sysretVa, "KiSystemCall64.ret", SyscallReturnOnBp))
        {
            MV_ERR("SYSCALL: return hook install failed — NTSTATUS not captured");
        }
        else
        {
            MV_LOG("SYSCALL: return hook at %llx (+0x%llx from entry)",
                   sysretVa, sysretVa - lstar);
        }
    }

    MV_LOG("SYSCALL: active (filter=%s, names=%lu)",
           g_FilterAll ? "ALL" : "selective", g_NameCount);
}
