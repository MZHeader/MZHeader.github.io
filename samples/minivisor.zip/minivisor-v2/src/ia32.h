

#pragma once

#include <ntddk.h>

#define IA32_TSC                        0x00000010
#define IA32_APIC_BASE                  0x0000001B
#define IA32_FEATURE_CONTROL            0x0000003A

#define IA32_MPERF                      0x000000E7
#define IA32_APERF                      0x000000E8
#define IA32_PPERF                      0x0000064E
#define IA32_BIOS_SIGN_ID               0x0000008B
#define IA32_SYSENTER_CS                0x00000174
#define IA32_SYSENTER_ESP               0x00000175
#define IA32_SYSENTER_EIP               0x00000176
#define IA32_DEBUGCTL                   0x000001D9
#define IA32_PAT                        0x00000277
#define IA32_EFER                       0xC0000080
#define IA32_FS_BASE                    0xC0000100
#define IA32_GS_BASE                    0xC0000101
#define IA32_KERNEL_GS_BASE             0xC0000102
#define IA32_TSC_AUX                    0xC0000103
#define IA32_STAR                       0xC0000081
#define IA32_LSTAR                      0xC0000082
#define IA32_FMASK                      0xC0000084

#define APIC_BASE_X2APIC_ENABLE         (1ULL << 10)
#define APIC_BASE_GLOBAL_ENABLE         (1ULL << 11)
#define APIC_BASE_ADDR_MASK             0x000FFFFFFFFFF000ULL

#define APIC_OFFSET_EOI                 0x0B0ULL    
#define APIC_OFFSET_LVT_TIMER           0x320ULL
#define APIC_OFFSET_INITIAL_COUNT       0x380ULL
#define APIC_OFFSET_CURRENT_COUNT       0x390ULL    
#define APIC_OFFSET_DIVIDE_CONFIG       0x3E0ULL

#define DEBUGCTL_LBR                    (1ULL << 0)  
#define DEBUGCTL_BTF                    (1ULL << 1)  
#define DEBUGCTL_TR                     (1ULL << 6)  
#define DEBUGCTL_BTS                    (1ULL << 7)  
#define DEBUGCTL_BTINT                  (1ULL << 8)  

#define DEBUGCTL_HYPERVISOR_MASK        (DEBUGCTL_LBR | DEBUGCTL_BTF | \
                                         DEBUGCTL_TR  | DEBUGCTL_BTS | DEBUGCTL_BTINT)

#define EPT_CAP_EXEC_ONLY           (1ULL << 0)  
#define EPT_CAP_4LEVEL              (1ULL << 6)  
#define EPT_CAP_WB                  (1ULL << 8)  
#define EPT_CAP_2MB                 (1ULL << 16) 

#define IA32_VMX_BASIC                  0x00000480
#define IA32_VMX_PINBASED_CTLS          0x00000481
#define IA32_VMX_PROCBASED_CTLS         0x00000482
#define IA32_VMX_EXIT_CTLS              0x00000483
#define IA32_VMX_ENTRY_CTLS             0x00000484
#define IA32_VMX_MISC                   0x00000485
#define IA32_VMX_CR0_FIXED0             0x00000486
#define IA32_VMX_CR0_FIXED1             0x00000487
#define IA32_VMX_CR4_FIXED0             0x00000488
#define IA32_VMX_CR4_FIXED1             0x00000489
#define IA32_VMX_PROCBASED_CTLS2        0x0000048B
#define IA32_VMX_EPT_VPID_CAP           0x0000048C
#define IA32_VMX_TRUE_PINBASED_CTLS     0x0000048D
#define IA32_VMX_TRUE_PROCBASED_CTLS    0x0000048E
#define IA32_VMX_TRUE_EXIT_CTLS         0x0000048F
#define IA32_VMX_TRUE_ENTRY_CTLS        0x00000490

#define HV_SYNTHETIC_MSR_LOW            0x40000000
#define HV_SYNTHETIC_MSR_HIGH           0x400000FF

#define FEATURE_CONTROL_LOCK            (1ULL << 0)
#define FEATURE_CONTROL_VMXON_SMX       (1ULL << 1)
#define FEATURE_CONTROL_VMXON_NO_SMX    (1ULL << 2)

#define EFER_LMA                        (1ULL << 10)
#define EFER_LME                        (1ULL << 8)

#define CR0_PE                          (1ULL << 0)
#define CR0_PG                          (1ULL << 31)

#define CR4_VMXE                        (1ULL << 13)    
#define CR4_PAE                         (1ULL << 5)
#define CR4_PCIDE                       (1ULL << 17)
#define CR4_PCE                         (1ULL << 8)     

#define RFLAGS_CF                       (1ULL << 0)
#define RFLAGS_ZF                       (1ULL << 6)

#define CPUID_LEAF_FEATURES             0x00000001      
#define CPUID_FEATURES_ECX_HYPERVISOR   (1U << 31)
#define CPUID_FEATURES_ECX_VMX          (1U << 5)        
#define CPUID_LEAF_HV_VENDOR            0x40000000      
#define CPUID_LEAF_HV_MAX               0x400000FF
#define CPUID_LEAF_XSTATE               0x0000000D      
#define CPUID_LEAF_PERFMON              0x0000000A      

#define XCR0_X87                        (1ULL << 0)
#define XCR0_SSE                        (1ULL << 1)
#define XCR0_AVX                        (1ULL << 2)
#define XCR0_BNDREG                     (1ULL << 3)
#define XCR0_BNDCSR                     (1ULL << 4)
#define XCR0_OPMASK                     (1ULL << 5)
#define XCR0_ZMM_HI256                  (1ULL << 6)
#define XCR0_HI16_ZMM                   (1ULL << 7)

#pragma pack(push, 1)
typedef struct _GDTR
{
    UINT16 Limit;
    UINT64 Base;
} GDTR, *PGDTR;

typedef struct _SEGMENT_DESCRIPTOR
{
    UINT16 LimitLow;
    UINT16 BaseLow;
    UINT8  BaseMiddle;
    UINT8  Attributes;          
    UINT8  LimitHighFlags;      
    UINT8  BaseHigh;
} SEGMENT_DESCRIPTOR, *PSEGMENT_DESCRIPTOR;
#pragma pack(pop)

typedef union _VMX_SEGMENT_ACCESS_RIGHTS
{
    UINT32 AsUInt32;
    struct
    {
        UINT32 Type : 4;
        UINT32 DescriptorType : 1;  
        UINT32 Dpl : 2;
        UINT32 Present : 1;
        UINT32 Reserved0 : 4;
        UINT32 Available : 1;       
        UINT32 LongMode : 1;        
        UINT32 DefaultBig : 1;      
        UINT32 Granularity : 1;     
        UINT32 Unusable : 1;        
        UINT32 Reserved1 : 15;
    };
} VMX_SEGMENT_ACCESS_RIGHTS;
