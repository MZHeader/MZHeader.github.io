

#include "minivisor.h"
#include <intrin.h>

/* Exported by ntoskrnl but not always prototyped in the kernel headers; declare
 * it explicitly (MSVC 18 treats an implicit declaration as a hard error). */
NTSYSAPI VOID NTAPI RtlCaptureContext(_Out_ PCONTEXT ContextRecord);

UINT32
VmxAdjustControls(UINT32 desired, UINT32 capabilityMsr)
{
    UINT64 cap = __readmsr(capabilityMsr);
    desired &= (UINT32)(cap >> 32);
    desired |= (UINT32)(cap & 0xFFFFFFFF);
    return desired;
}

BOOLEAN
VmxIsSupported(VOID)
{
    int regs[4];
    UINT64 featureControl;

    
    __cpuid(regs, 1);
    if (((UINT32)regs[2] & (1U << 5)) == 0)
    {
        MV_ERR("VT-x not reported by CPUID");
        return FALSE;
    }

    

    featureControl = __readmsr(IA32_FEATURE_CONTROL);
    if ((featureControl & FEATURE_CONTROL_LOCK) == 0)
    {
        MV_ERR("IA32_FEATURE_CONTROL unlocked; firmware did not enable VMX");
        return FALSE;
    }
    if ((featureControl & FEATURE_CONTROL_VMXON_NO_SMX) == 0)
    {
        MV_ERR("VMXON-outside-SMX disabled in IA32_FEATURE_CONTROL");
        return FALSE;
    }

    return TRUE;
}

static VOID
VmxAdjustControlRegisters(VOID)
{
    UINT64 cr0 = __readcr0();
    UINT64 cr4 = __readcr4();

    cr0 |= __readmsr(IA32_VMX_CR0_FIXED0);
    cr0 &= __readmsr(IA32_VMX_CR0_FIXED1);
    __writecr0(cr0);

    cr4 |= __readmsr(IA32_VMX_CR4_FIXED0);
    cr4 &= __readmsr(IA32_VMX_CR4_FIXED1);
    cr4 |= CR4_VMXE;
    __writecr4(cr4);
}

BOOLEAN
VmxEnableOnVcpu(PVCPU vcpu)
{
    IA32_VMX_BASIC_MSR basic;
    DECLSPEC_ALIGN(16) CONTEXT guestContext;

    basic.AsUInt64 = __readmsr(IA32_VMX_BASIC);

    
    *(UINT32*)vcpu->VmxonRegion = (UINT32)basic.RevisionId;
    *(UINT32*)vcpu->VmcsRegion  = (UINT32)basic.RevisionId;

    

    /* Use the System-process CR3 captured in DriverEntry, NOT __readcr3() here:
     * this runs at IPI_LEVEL in an arbitrary interrupted process context, whose
     * CR3 could be freed later and fault the host on a subsequent VM-exit. */
    vcpu->HostCr3 = g_Hv.SystemCr3;

    VmxAdjustControlRegisters();

    if (__vmx_on(&vcpu->VmxonPhysical) != 0)
    {
        MV_ERR("VMXON failed on CPU %lu", vcpu->ProcessorIndex);
        __writecr4(__readcr4() & ~CR4_VMXE);
        return FALSE;
    }

    if (__vmx_vmclear(&vcpu->VmcsPhysical) != 0 ||
        __vmx_vmptrld(&vcpu->VmcsPhysical) != 0)
    {
        MV_ERR("VMCLEAR/VMPTRLD failed on CPU %lu", vcpu->ProcessorIndex);
        __vmx_off();
        __writecr4(__readcr4() & ~CR4_VMXE);
        return FALSE;
    }

    

    RtlCaptureContext(&guestContext);

    if (!vcpu->Virtualized)
    {
        vcpu->Virtualized = TRUE;       
        _ReadWriteBarrier();

        if (!VmcsSetup(vcpu, &guestContext))
        {
            MV_ERR("VMCS setup failed on CPU %lu", vcpu->ProcessorIndex);
            vcpu->Virtualized = FALSE;
            __vmx_off();
            __writecr4(__readcr4() & ~CR4_VMXE);
            return FALSE;
        }

        __vmx_vmlaunch();

        
        vcpu->Virtualized = FALSE;
        vcpu->LaunchFailed = TRUE;
        {
            SIZE_T err = 0;
            __vmx_vmread(VMCS_VM_INSTRUCTION_ERROR, &err);
            MV_ERR("VMLAUNCH failed on CPU %lu, error=%llu",
                   vcpu->ProcessorIndex, (UINT64)err);
        }
        __vmx_off();
        __writecr4(__readcr4() & ~CR4_VMXE);
        return FALSE;
    }

    
    MV_LOG("CPU %lu virtualized", vcpu->ProcessorIndex);
    return TRUE;
}

VOID
VmxDisableOnVcpu(PVCPU vcpu)
{
    int regs[4];

    UNREFERENCED_PARAMETER(vcpu);

    __cpuidex(regs, (int)MV_CPUID_UNLOAD_MAGIC, 0);
    __writecr4(__readcr4() & ~CR4_VMXE);
}
