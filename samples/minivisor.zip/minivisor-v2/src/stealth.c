

#include "minivisor.h"
#include <intrin.h>

VOID
StealthFilterCpuid(UINT32 leaf, UINT32 subleaf, INT32 reg[4])
{
    if (leaf == CPUID_LEAF_FEATURES)
    {
        

        reg[2] &= ~(INT32)CPUID_FEATURES_ECX_HYPERVISOR;

        

        reg[2] &= ~(INT32)CPUID_FEATURES_ECX_VMX;
        return;
    }

    

    if (leaf >= CPUID_LEAF_HV_VENDOR && leaf <= CPUID_LEAF_HV_MAX)
    {
        int maxBasic[4];
        __cpuid(maxBasic, 0);                       
        __cpuidex(reg, maxBasic[0], (int)subleaf);
        return;
    }

    
}

static BOOLEAN
IsSyntheticHvMsr(UINT32 msr)
{
    return (msr >= HV_SYNTHETIC_MSR_LOW && msr <= HV_SYNTHETIC_MSR_HIGH);
}

BOOLEAN
StealthMsrShouldExit(UINT32 msr)
{
    

    return (msr == IA32_FEATURE_CONTROL);
}

MSR_ACTION
StealthMsrReadAction(UINT32 msr, UINT64* spoofValue)
{
    if (IsSyntheticHvMsr(msr))
    {
        return MSR_INJECT_GP;       
    }

    

    if (msr >= IA32_VMX_BASIC && msr <= IA32_VMX_TRUE_ENTRY_CTLS)
    {
        return MSR_INJECT_GP;
    }

    if (msr == IA32_FEATURE_CONTROL)
    {
        

        UINT64 v = __readmsr(IA32_FEATURE_CONTROL);
        v &= ~(FEATURE_CONTROL_VMXON_SMX | FEATURE_CONTROL_VMXON_NO_SMX);
        *spoofValue = v;
        return MSR_VALUE;
    }

    return MSR_PASSTHROUGH;
}

MSR_ACTION
StealthMsrWriteAction(UINT32 msr, UINT64 value)
{
    UNREFERENCED_PARAMETER(value);

    if (IsSyntheticHvMsr(msr))
    {
        return MSR_INJECT_GP;
    }

    if (msr == IA32_FEATURE_CONTROL)
    {
        
        return MSR_INJECT_GP;
    }

    return MSR_PASSTHROUGH;
}

UINT64
StealthCr4ReadShadow(UINT64 realCr4)
{
    
    return realCr4 & ~CR4_VMXE;
}

VOID
StealthSetupMsrBitmap(PVCPU vcpu)
{
    UINT32 msr;

    

    MsrBitmapSet(vcpu->MsrBitmap, IA32_FEATURE_CONTROL, TRUE,  FALSE);

    
    MsrBitmapSet(vcpu->MsrBitmap, IA32_TSC,             FALSE, TRUE);

    

    for (msr = IA32_VMX_BASIC; msr <= IA32_VMX_TRUE_ENTRY_CTLS; msr++)
    {
        MsrBitmapSet(vcpu->MsrBitmap, msr, TRUE, FALSE);
    }

    

    MsrBitmapSet(vcpu->MsrBitmap, IA32_DEBUGCTL, TRUE, TRUE);
    vcpu->ShadowDebugCtl = 0;

    

    MsrBitmapSet(vcpu->MsrBitmap, IA32_MPERF, TRUE, FALSE);
    MsrBitmapSet(vcpu->MsrBitmap, IA32_APERF, TRUE, FALSE);
    MsrBitmapSet(vcpu->MsrBitmap, IA32_PPERF, TRUE, FALSE);
}
