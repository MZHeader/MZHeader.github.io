

#include "minivisor.h"
#include <intrin.h>

static PUCHAR
MapApicPage(UINT64 pa)
{
    PHYSICAL_ADDRESS phys;
    phys.QuadPart = (LONGLONG)pa;
    return (PUCHAR)MmMapIoSpace(phys, PAGE_SIZE, MmNonCached);
}

static UINT32
ApicDecodeDivider(UINT32 reg)
{
    UINT32 val = ((reg & 8U) >> 1) | (reg & 3U);
    return (val == 7U) ? 1U : (2U << val);
}

BOOLEAN
ApicFind(PAPIC_STATE apic)
{
    UINT64        apicBase;
    PUCHAR        va;
    UINT32        divide;
    UINT64        crystalHz;
    UINT64        tscHz;
    UINT64        apicRateHz;
    int           leaf15[4];
    LARGE_INTEGER tscFreqLi;

    apicBase = __readmsr(IA32_APIC_BASE);

    
    if (apicBase & APIC_BASE_X2APIC_ENABLE)
    {
        MV_LOG("APIC: x2APIC mode — timer MSR interception not implemented, skipping");
        return FALSE;
    }

    if (!(apicBase & APIC_BASE_GLOBAL_ENABLE))
    {
        MV_LOG("APIC: APIC globally disabled");
        return FALSE;
    }

    apic->PhysBase = apicBase & APIC_BASE_ADDR_MASK;

    va = MapApicPage(apic->PhysBase);
    if (va == NULL)
    {
        MV_LOG("APIC: failed to map physical base 0x%llx", apic->PhysBase);
        return FALSE;
    }

    divide = ApicDecodeDivider(*(volatile UINT32*)(va + APIC_OFFSET_DIVIDE_CONFIG));

    
    apic->InitialCount = *(volatile UINT32*)(va + APIC_OFFSET_INITIAL_COUNT);
    apic->BaseTsc      = __rdtsc();

    MmUnmapIoSpace(va, PAGE_SIZE);

    if (apic->InitialCount == 0)
    {
        MV_LOG("APIC: timer initial count is 0 (timer not running) — skipping");
        return FALSE;
    }

    

    __cpuid(leaf15, 0x15);
    crystalHz = (UINT64)(UINT32)leaf15[2];

    KeQueryPerformanceCounter(&tscFreqLi);
    tscHz = (UINT64)tscFreqLi.QuadPart;

    if (crystalHz == 0)
    {
        MV_LOG("APIC: CPUID.15H.ECX not populated — using TSC freq as crystal approximation");
        crystalHz = tscHz;
    }

    if (tscHz == 0)
    {
        MV_ERR("APIC: TSC frequency is 0 — cannot compute synthesis ratio");
        return FALSE;
    }

    apicRateHz            = crystalHz / (UINT64)divide;
    apic->RatioScaled20   = (apicRateHz << 20) / tscHz;

    apic->Valid = TRUE;

    MV_LOG("APIC: base=0x%llx initCount=%u div=%u crystal=%llu Hz rate=%llu Hz ratio<<20=%llu",
           apic->PhysBase, (UINT32)apic->InitialCount,
           divide, crystalHz, apicRateHz, apic->RatioScaled20);
    return TRUE;
}

BOOLEAN
ApicHide(PAPIC_STATE apic, PEPT_STATE ept)
{
    if (!apic->Valid)
    {
        return TRUE;
    }

    if (!EptTrapRange(ept, apic->PhysBase, PAGE_SIZE))
    {
        MV_ERR("APIC: EptTrapRange failed for 0x%llx", apic->PhysBase);
        return FALSE;
    }

    MV_LOG("APIC: page 0x%llx trapped in EPT", apic->PhysBase);
    return TRUE;
}

UINT64
ApicSynthesize(PAPIC_STATE apic, PVCPU vcpu)
{
    UINT64 hwTsc     = __rdtsc();
    INT64  guestTsc  = (INT64)hwTsc + vcpu->TscOffset;
    INT64  deltaTsc  = guestTsc - (INT64)apic->BaseTsc;
    INT64  apicDelta;
    INT64  result;

    if (deltaTsc < 0)
    {
        deltaTsc = 0;
    }

    apicDelta = (deltaTsc * (INT64)apic->RatioScaled20) >> 20;
    result    = (INT64)apic->InitialCount - apicDelta;

    
    return (result < 0) ? 0 : (UINT64)result;
}

VOID
ApicHandleViolation(PVCPU vcpu, PVMEXIT_FRAME frame)
{
    PAPIC_STATE apic    = &g_Hv.Apic;
    SIZE_T      gpa     = 0;
    SIZE_T      qual    = 0;
    UINT64      offset;
    BOOLEAN     isRead;
    SIZE_T      procCtl = 0;

    __vmx_vmread(VMCS_GUEST_PHYSICAL_ADDRESS, &gpa);
    __vmx_vmread(VMCS_EXIT_QUALIFICATION,     &qual);

    offset = (UINT64)gpa - apic->PhysBase;
    isRead = (qual & 1) != 0;

    if (isRead && offset == APIC_OFFSET_CURRENT_COUNT)
    {
        
        vcpu->ApicMtfPending = TRUE;
        vcpu->ApicSynthetic  = ApicSynthesize(apic, vcpu);
        vcpu->ApicGprsBefore = frame->Regs;
    }
    else
    {
        
        vcpu->ApicMtfPending = FALSE;
    }

    
    vcpu->MtfExposedPage = apic->PhysBase;

    EptSetGpaPresent(&g_Hv.Ept, apic->PhysBase, TRUE);
    EptInvalidateAll(&g_Hv.Ept);

    __vmx_vmread(VMCS_CTRL_PROC_BASED, &procCtl);
    __vmx_vmwrite(VMCS_CTRL_PROC_BASED, procCtl | PROC_CTL_MONITOR_TRAP_FLAG);
}

VOID
ApicHandleMtf(PVCPU vcpu, PVMEXIT_FRAME frame)
{
    PAPIC_STATE apic    = &g_Hv.Apic;
    SIZE_T      procCtl = 0;

    
    EptSetGpaPresent(&g_Hv.Ept, apic->PhysBase, FALSE);
    EptInvalidateAll(&g_Hv.Ept);

    
    __vmx_vmread(VMCS_CTRL_PROC_BASED, &procCtl);
    __vmx_vmwrite(VMCS_CTRL_PROC_BASED, procCtl & ~(SIZE_T)PROC_CTL_MONITOR_TRAP_FLAG);

    if (vcpu->ApicMtfPending)
    {
        
        UINT64* before = (UINT64*)&vcpu->ApicGprsBefore;
        UINT64* after  = (UINT64*)&frame->Regs;
        ULONG   i;

        for (i = 0; i < (sizeof(GUEST_REGISTERS) / sizeof(UINT64)); i++)
        {
            if (before[i] != after[i])
            {
                after[i] = vcpu->ApicSynthetic;
                break;
            }
        }

        vcpu->ApicMtfPending = FALSE;
    }
}
