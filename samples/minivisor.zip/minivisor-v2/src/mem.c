

#include "minivisor.h"

PVOID
MemAllocContiguous(SIZE_T size)
{
    PHYSICAL_ADDRESS maxAddr;
    PVOID va;

    maxAddr.QuadPart = MAXULONG64;

    

    va = MmAllocateContiguousMemory(size, maxAddr);
    if (va != NULL)
    {
        RtlZeroMemory(va, size);
    }
    return va;
}

VOID
MemFreeContiguous(PVOID va)
{
    if (va != NULL)
    {
        MmFreeContiguousMemory(va);
    }
}

UINT64
MemVirtualToPhysical(PVOID va)
{
    return (UINT64)MmGetPhysicalAddress(va).QuadPart;
}
