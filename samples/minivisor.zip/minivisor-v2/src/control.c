
#include "minivisor.h"
#include "mv_ioctls.h"

extern POBJECT_TYPE* IoDriverObjectType;

extern NTKERNELAPI NTSTATUS NTAPI ObReferenceObjectByName(
    PUNICODE_STRING ObjectName,
    ULONG           Attributes,
    PACCESS_STATE   AccessState,
    ACCESS_MASK     DesiredAccess,
    POBJECT_TYPE    ObjectType,
    KPROCESSOR_MODE AccessMode,
    PVOID           ParseContext,
    PVOID*          Object);

static PDRIVER_DISPATCH g_origDevCtrl = NULL;
static PDRIVER_OBJECT   g_borrowedDrv = NULL;
static PUCHAR           g_cavePtr     = NULL;

typedef struct _CTRL_LDR_ENTRY {
    LIST_ENTRY InLoadOrderLinks;
    LIST_ENTRY InMemoryOrderLinks;
    LIST_ENTRY InInitializationOrderLinks;
    PVOID      DllBase;
} CTRL_LDR_ENTRY, *PCTRL_LDR_ENTRY;

static NTSTATUS DispatchIoControl(PDEVICE_OBJECT deviceObject, PIRP irp);

static PUCHAR
FindCodeCave(PVOID base, SIZE_T need)
{
    PIMAGE_DOS_HEADER dos;
    PIMAGE_NT_HEADERS nt;
    PIMAGE_SECTION_HEADER sec;
    USHORT i;

    if (!base) return NULL;
    dos = (PIMAGE_DOS_HEADER)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return NULL;
    nt  = (PIMAGE_NT_HEADERS)((PUCHAR)base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return NULL;
    sec = IMAGE_FIRST_SECTION(nt);

    for (i = 0; i < nt->FileHeader.NumberOfSections; i++, sec++)
    {
        PUCHAR p;
        SIZE_T sz, run, j;

        if (!(sec->Characteristics & IMAGE_SCN_CNT_CODE)) continue;
        p   = (PUCHAR)base + sec->VirtualAddress;
        sz  = sec->Misc.VirtualSize;
        run = 0;

        for (j = 0; j < sz; j++)
        {
            if (!MmIsAddressValid(p + j)) { run = 0; continue; }
            if (p[j] == 0x00 || p[j] == 0xCC)
            {
                if (++run >= need) return p + j - run + 1;
            }
            else
            {
                run = 0;
            }
        }
    }
    return NULL;
}

static PUCHAR
WriteStubToCave(PUCHAR cave, PVOID target, UCHAR fill)
{
    PMDL     mdl;
    PUCHAR   mapped;
    NTSTATUS st = STATUS_UNSUCCESSFUL;

    mdl = IoAllocateMdl(cave, 16, FALSE, FALSE, NULL);
    if (!mdl) return NULL;

    __try { MmProbeAndLockPages(mdl, KernelMode, IoReadAccess); st = STATUS_SUCCESS; }
    __except (EXCEPTION_EXECUTE_HANDLER) {}

    if (!NT_SUCCESS(st)) { IoFreeMdl(mdl); return NULL; }

    mapped = (PUCHAR)MmMapLockedPagesSpecifyCache(
        mdl, KernelMode, MmNonCached, NULL, FALSE, NormalPagePriority);

    if (mapped)
    {
        if (NT_SUCCESS(MmProtectMdlSystemAddress(mdl, PAGE_EXECUTE_READWRITE)))
        {
            if (target)
            {
                UCHAR stub[12] = { 0x48, 0xB8, 0,0,0,0,0,0,0,0, 0xFF, 0xE0 };
                *(PVOID*)(stub + 2) = target;
                RtlCopyMemory(mapped, stub, 12);
            }
            else
            {
                RtlFillMemory(mapped, 12, fill);
            }
            st = STATUS_SUCCESS;
        }
        else
        {
            st = STATUS_UNSUCCESSFUL;
        }
        MmUnmapLockedPages(mapped, mdl);
    }
    else
    {
        st = STATUS_INSUFFICIENT_RESOURCES;
    }

    MmUnlockPages(mdl);
    IoFreeMdl(mdl);
    return NT_SUCCESS(st) ? cave : NULL;
}

static PDRIVER_DISPATCH
InstallCaveTrampoline(PDRIVER_OBJECT pDevOwner)
{
    PCTRL_LDR_ENTRY ldr0, e;
    PLIST_ENTRY head, cur;
    ULONG guard;

    if (!pDevOwner || !pDevOwner->DriverSection) return NULL;

    ldr0  = (PCTRL_LDR_ENTRY)pDevOwner->DriverSection;
    head  = &ldr0->InLoadOrderLinks;
    guard = 0;

    for (cur = head->Flink;
         cur && cur != head && ++guard < 256;
         cur = cur->Flink)
    {
        PUCHAR cave, result;
        e = CONTAINING_RECORD(cur, CTRL_LDR_ENTRY, InLoadOrderLinks);
        if (!e->DllBase) continue;
        if (e->DllBase == ldr0->DllBase) continue;

        cave = FindCodeCave(e->DllBase, 16);
        if (!cave) continue;

        result = WriteStubToCave(cave, (PVOID)DispatchIoControl, 0xCC);
        if (result)
        {
            g_cavePtr = result;
            MV_LOG("CTRL: cave trampoline at %p", result);
            return (PDRIVER_DISPATCH)result;
        }
    }

    MV_LOG("CTRL: no cave found — using direct pointer");
    return NULL;
}

static VOID
ZeroCave(VOID)
{
    if (!g_cavePtr) return;
    WriteStubToCave(g_cavePtr, NULL, 0xCC);
    g_cavePtr = NULL;
}

static NTSTATUS
DispatchCreateClose(PDEVICE_OBJECT deviceObject, PIRP irp)
{
    UNREFERENCED_PARAMETER(deviceObject);
    irp->IoStatus.Status      = STATUS_SUCCESS;
    irp->IoStatus.Information = 0;
    IoCompleteRequest(irp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}

static NTSTATUS
DispatchIoControl(PDEVICE_OBJECT deviceObject, PIRP irp)
{
    PIO_STACK_LOCATION stack;
    ULONG              code;
    PVOID              buf;
    ULONG              inLen, outLen;
    NTSTATUS           status = STATUS_INVALID_DEVICE_REQUEST;
    ULONG_PTR          info   = 0;

    if (deviceObject != g_Hv.ControlDevice)
    {
        if (g_origDevCtrl)
            return g_origDevCtrl(deviceObject, irp);
        irp->IoStatus.Status      = STATUS_NOT_SUPPORTED;
        irp->IoStatus.Information = 0;
        IoCompleteRequest(irp, IO_NO_INCREMENT);
        return STATUS_NOT_SUPPORTED;
    }

    stack  = IoGetCurrentIrpStackLocation(irp);
    code   = stack->Parameters.DeviceIoControl.IoControlCode;
    buf    = irp->AssociatedIrp.SystemBuffer;
    inLen  = stack->Parameters.DeviceIoControl.InputBufferLength;
    outLen = stack->Parameters.DeviceIoControl.OutputBufferLength;

    switch (code)
    {
    case MV_IOCTL_SET_TARGET:
    {
        PMV_SET_TARGET_IN in = (PMV_SET_TARGET_IN)buf;
        if (inLen < sizeof(MV_SET_TARGET_IN))
        {
            status = STATUS_BUFFER_TOO_SMALL;
            break;
        }
        g_Hv.TargetBase = in->Base;
        g_Hv.TargetSize = (SIZE_T)in->Size;
        MV_LOG("CTRL: target set Base=%llx Size=%llx", in->Base, in->Size);
        status = STATUS_SUCCESS;
        break;
    }

    case MV_IOCTL_ADD_SYSCALL_FILTER:
    {
        PMV_ADD_SYSCALL_FILTER_IN in = (PMV_ADD_SYSCALL_FILTER_IN)buf;
        if (inLen < sizeof(MV_ADD_SYSCALL_FILTER_IN))
        {
            status = STATUS_BUFFER_TOO_SMALL;
            break;
        }
        SyscallHookAddFilter(in->SyscallNum);
        status = STATUS_SUCCESS;
        break;
    }

    case MV_IOCTL_CLEAR_SYSCALL_FILTER:
        SyscallHookClearFilter();
        status = STATUS_SUCCESS;
        break;

    case MV_IOCTL_INSTALL_HOOK:
    {
        PMV_INSTALL_HOOK_IN in = (PMV_INSTALL_HOOK_IN)buf;
        CHAR tag[33];

        if (inLen < sizeof(MV_INSTALL_HOOK_IN))
        {
            status = STATUS_BUFFER_TOO_SMALL;
            break;
        }
        if (in->TargetVa == 0)
        {
            MV_ERR("CTRL: INSTALL_HOOK: TargetVa is zero");
            status = STATUS_INVALID_PARAMETER;
            break;
        }
        if (!g_Hv.VmxEnabled)
        {
            MV_ERR("CTRL: INSTALL_HOOK: hypervisor not running");
            status = STATUS_DEVICE_NOT_READY;
            break;
        }

        RtlCopyMemory(tag, in->Tag, 32);
        tag[32] = '\0';

        status = ShadowHookInstallRuntime(in->TargetVa, tag)
                     ? STATUS_SUCCESS
                     : STATUS_UNSUCCESSFUL;
        break;
    }

    case MV_IOCTL_QUERY_STATUS:
    {
        PMV_QUERY_STATUS_OUT out = (PMV_QUERY_STATUS_OUT)buf;
        if (outLen < sizeof(MV_QUERY_STATUS_OUT))
        {
            status = STATUS_BUFFER_TOO_SMALL;
            break;
        }
        RtlZeroMemory(out, sizeof(*out));
        out->VmxEnabled       = g_Hv.VmxEnabled;
        out->VcpuCount        = g_Hv.VcpuCount;
        out->ShadowHookCount  = g_Hv.ShadowHookCount;
        out->SyscallNameCount = SyscallHookNameCount();
        out->SyscallFilterAll = SyscallHookFilterAll();
        out->TargetBase       = g_Hv.TargetBase;
        out->TargetSize       = (UINT64)g_Hv.TargetSize;
        info   = sizeof(MV_QUERY_STATUS_OUT);
        status = STATUS_SUCCESS;
        break;
    }

    default:
        status = STATUS_INVALID_DEVICE_REQUEST;
        break;
    }

    irp->IoStatus.Status      = status;
    irp->IoStatus.Information = info;
    IoCompleteRequest(irp, IO_NO_INCREMENT);
    return status;
}

NTSTATUS
ControlInit(PDRIVER_OBJECT driverObject)
{
    UNICODE_STRING   devName, symName;
    PDEVICE_OBJECT   devObj    = NULL;
    PDRIVER_OBJECT   pDevOwner = driverObject;
    PDRIVER_DISPATCH dispFn;
    NTSTATUS         status;

    if (!pDevOwner)
    {
        UNICODE_STRING nullDrvName = RTL_CONSTANT_STRING(L"\\Driver\\Null");
        status = ObReferenceObjectByName(
            &nullDrvName, OBJ_CASE_INSENSITIVE, NULL, 0,
            *IoDriverObjectType, KernelMode, NULL, (PVOID*)&pDevOwner);
        if (!NT_SUCCESS(status) || !pDevOwner)
        {
            MV_ERR("CTRL: failed to borrow \\Driver\\Null (0x%08X) — comm unavailable",
                   status);
            return STATUS_SUCCESS;
        }
        g_borrowedDrv = pDevOwner;
        MV_LOG("CTRL: KDMapper path — borrowed \\Driver\\Null");
    }

    g_origDevCtrl = pDevOwner->MajorFunction[IRP_MJ_DEVICE_CONTROL];

    dispFn = InstallCaveTrampoline(pDevOwner);
    if (!dispFn) dispFn = DispatchIoControl;
    pDevOwner->MajorFunction[IRP_MJ_DEVICE_CONTROL] = dispFn;

    RtlInitUnicodeString(&devName, MV_DEVICE_NAME);
    RtlInitUnicodeString(&symName, MV_DEVICE_SYMLINK);

    status = IoCreateDevice(pDevOwner,
                            0,
                            &devName,
                            FILE_DEVICE_UNKNOWN,
                            FILE_DEVICE_SECURE_OPEN,
                            FALSE,
                            &devObj);
    if (!NT_SUCCESS(status))
    {
        MV_ERR("CTRL: IoCreateDevice failed: %08x", status);
        pDevOwner->MajorFunction[IRP_MJ_DEVICE_CONTROL] = g_origDevCtrl;
        ZeroCave();
        if (g_borrowedDrv) { ObDereferenceObject(g_borrowedDrv); g_borrowedDrv = NULL; }
        return status;
    }

    status = IoCreateSymbolicLink(&symName, &devName);
    if (!NT_SUCCESS(status))
    {
        MV_ERR("CTRL: IoCreateSymbolicLink failed: %08x", status);
        IoDeleteDevice(devObj);
        pDevOwner->MajorFunction[IRP_MJ_DEVICE_CONTROL] = g_origDevCtrl;
        ZeroCave();
        if (g_borrowedDrv) { ObDereferenceObject(g_borrowedDrv); g_borrowedDrv = NULL; }
        return status;
    }

    devObj->Flags &= ~DO_DEVICE_INITIALIZING;
    devObj->Flags |=  DO_BUFFERED_IO;

    g_Hv.ControlDevice = devObj;

    MV_LOG("CTRL: device ready — \\\\.\\Minivisor");
    return STATUS_SUCCESS;
}

VOID
ControlTeardown(VOID)
{
    UNICODE_STRING symName;

    if (g_Hv.ControlDevice != NULL)
    {
        RtlInitUnicodeString(&symName, MV_DEVICE_SYMLINK);
        IoDeleteSymbolicLink(&symName);
        IoDeleteDevice(g_Hv.ControlDevice);
        g_Hv.ControlDevice = NULL;
    }

    if (g_borrowedDrv)
    {
        g_borrowedDrv->MajorFunction[IRP_MJ_DEVICE_CONTROL] = g_origDevCtrl;
        ZeroCave();
        ObDereferenceObject(g_borrowedDrv);
        g_borrowedDrv = NULL;
    }

    MV_LOG("CTRL: device removed");
}
