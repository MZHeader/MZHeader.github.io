;
; vmx.asm - VMX assembly stubs (ml64 / MASM x64).
;
; Contains the VM-exit trampoline (VMCS_HOST_RIP target) plus small helpers to
; read segment selectors and descriptor-table registers that have no reliable
; MSVC intrinsic.
;
; Stack contract (must match GUEST_REGISTERS / VMEXIT_FRAME in C):
;
;   The host RSP loaded on VM-exit (VMCS_HOST_RSP) points 0x20 below the top of
;   the per-VCPU HostStack.  The top four 8-byte slots are, from high to low:
;
;       [B-0x08] = VCPU self-pointer      (written once at VMCS setup)
;       [B-0x10] = OffRip   scratch       (written by the C turn-off handler)
;       [B-0x18] = OffRsp   scratch
;       [B-0x20] = OffRflags scratch  <-- VMCS_HOST_RSP points here
;
;   where B = &HostStack[HOST_STACK_SIZE].  On exit the trampoline pushes the
;   15 GPRs (0x78 bytes) so that, relative to the resulting frame base:
;
;       frame+0x00 .. +0x70 = Rax..R15        (GUEST_REGISTERS)
;       frame+0x78          = OffRflags
;       frame+0x80          = OffRsp
;       frame+0x88          = OffRip
;       frame+0x90          = VCPU self-pointer
;
.code

EXTERN HandleVmExit:PROC

; Export every routine the C code links against (explicit so we never depend on
; the assembler's default symbol visibility).
PUBLIC AsmVmExitHandler
PUBLIC AsmReadCs
PUBLIC AsmReadSs
PUBLIC AsmReadDs
PUBLIC AsmReadEs
PUBLIC AsmReadFs
PUBLIC AsmReadGs
PUBLIC AsmReadTr
PUBLIC AsmReadLdtr
PUBLIC AsmReadGdtr
PUBLIC AsmReadIdtr
PUBLIC AsmReadSegmentLimit
PUBLIC AsmReadSegmentAccessRights
PUBLIC AsmInvept

; -------------------------------------------------------------------
; AsmVmExitHandler - VMCS_HOST_RIP target.
; -------------------------------------------------------------------
AsmVmExitHandler PROC
    ; Build GUEST_REGISTERS: push so RAX lands at [rsp+0].
    push    r15
    push    r14
    push    r13
    push    r12
    push    r11
    push    r10
    push    r9
    push    r8
    push    rdi
    push    rsi
    push    rbp
    push    rbx
    push    rdx
    push    rcx
    push    rax

    mov     rcx, rsp                ; arg1 = &VMEXIT_FRAME
    mov     rbx, rsp                ; rbx = frame base (guest rbx already saved)

    ; Preserve volatile XMM0-5 (the C handler may clobber them; the guest's
    ; live XMM state shares the same physical registers across a VM-exit).
    sub     rsp, 60h
    and     rsp, 0FFFFFFFFFFFFFFF0h  ; 16-byte align for movaps
    movaps  xmmword ptr [rsp+00h], xmm0
    movaps  xmmword ptr [rsp+10h], xmm1
    movaps  xmmword ptr [rsp+20h], xmm2
    movaps  xmmword ptr [rsp+30h], xmm3
    movaps  xmmword ptr [rsp+40h], xmm4
    movaps  xmmword ptr [rsp+50h], xmm5

    sub     rsp, 20h                ; Win64 shadow space (stays 16-aligned)
    call    HandleVmExit            ; BOOLEAN HandleVmExit(VMEXIT_FRAME* rcx)
    add     rsp, 20h

    movaps  xmm0, xmmword ptr [rsp+00h]
    movaps  xmm1, xmmword ptr [rsp+10h]
    movaps  xmm2, xmmword ptr [rsp+20h]
    movaps  xmm3, xmmword ptr [rsp+30h]
    movaps  xmm4, xmmword ptr [rsp+40h]
    movaps  xmm5, xmmword ptr [rsp+50h]

    mov     rsp, rbx                ; rsp = frame base
    test    al, al
    jz      VmxOffPath

    ; ---- resume the guest ----
    pop     rax
    pop     rcx
    pop     rdx
    pop     rbx
    pop     rbp
    pop     rsi
    pop     rdi
    pop     r8
    pop     r9
    pop     r10
    pop     r11
    pop     r12
    pop     r13
    pop     r14
    pop     r15
    vmresume
    ; VMRESUME only returns on failure: break to the attached kernel debugger.
    int     3

VmxOffPath:
    ; ---- devirtualize this CPU and return to the guest at the trigger site ----
    ; rsp = frame base.  Scratch words are above the GPR frame.
    mov     rax, qword ptr [rsp+78h]    ; OffRflags
    mov     rcx, qword ptr [rsp+80h]    ; OffRsp (guest stack)
    mov     rdx, qword ptr [rsp+88h]    ; OffRip (resume target)

    ; Stage rflags/rip just below the guest stack pointer so popfq+ret lands
    ; the guest back on its exact RSP.
    sub     rcx, 10h
    mov     qword ptr [rcx+00h], rax    ; rflags  @ gsp-16
    mov     qword ptr [rcx+08h], rdx    ; rip     @ gsp-8

    vmxoff

    ; Restore guest GPRs from the host frame.  We must keep the staged guest
    ; stack pointer (rcx) alive, so restore rcx last via the staged stack.
    mov     rax, qword ptr [rsp+00h]
    ; rcx skipped (holds staged gsp)
    mov     rdx, qword ptr [rsp+10h]
    mov     rbx, qword ptr [rsp+18h]
    mov     rbp, qword ptr [rsp+20h]
    mov     rsi, qword ptr [rsp+28h]
    mov     rdi, qword ptr [rsp+30h]
    mov     r8,  qword ptr [rsp+38h]
    mov     r9,  qword ptr [rsp+40h]
    mov     r10, qword ptr [rsp+48h]
    mov     r11, qword ptr [rsp+50h]
    mov     r12, qword ptr [rsp+58h]
    mov     r13, qword ptr [rsp+60h]
    mov     r14, qword ptr [rsp+68h]
    mov     r15, qword ptr [rsp+70h]

    mov     rsp, rcx                    ; switch to staged guest stack (gsp-16)
    popfq                               ; restore guest RFLAGS  -> rsp = gsp-8
    ret                                 ; jump to guest RIP     -> rsp = gsp
AsmVmExitHandler ENDP

; -------------------------------------------------------------------
; Segment selector readers (UINT16 return in AX).
; -------------------------------------------------------------------
AsmReadCs PROC
    mov     ax, cs
    ret
AsmReadCs ENDP

AsmReadSs PROC
    mov     ax, ss
    ret
AsmReadSs ENDP

AsmReadDs PROC
    mov     ax, ds
    ret
AsmReadDs ENDP

AsmReadEs PROC
    mov     ax, es
    ret
AsmReadEs ENDP

AsmReadFs PROC
    mov     ax, fs
    ret
AsmReadFs ENDP

AsmReadGs PROC
    mov     ax, gs
    ret
AsmReadGs ENDP

AsmReadTr PROC
    str     ax
    ret
AsmReadTr ENDP

AsmReadLdtr PROC
    sldt    ax
    ret
AsmReadLdtr ENDP

; -------------------------------------------------------------------
; Descriptor-table register readers.  Arg1 (rcx) = PGDTR (UINT16 limit +
; UINT64 base, packed); sgdt/sidt write a 10-byte pseudo-descriptor.
; -------------------------------------------------------------------
AsmReadGdtr PROC
    sgdt    fword ptr [rcx]
    ret
AsmReadGdtr ENDP

AsmReadIdtr PROC
    sidt    fword ptr [rcx]
    ret
AsmReadIdtr ENDP

; -------------------------------------------------------------------
; AsmReadSegmentLimit - LSL (load segment limit). Arg1 (cx) = selector.
; -------------------------------------------------------------------
AsmReadSegmentLimit PROC
    lsl     eax, ecx
    ret
AsmReadSegmentLimit ENDP

; -------------------------------------------------------------------
; AsmReadSegmentAccessRights - LAR (load access rights). Arg1 (cx) = selector.
; Returns the access-rights dword (bits as in a descriptor), or 0 if invalid.
; -------------------------------------------------------------------
AsmReadSegmentAccessRights PROC
    lar     eax, ecx
    jz      arOk            ; ZF=1 => valid
    xor     eax, eax
arOk:
    ret
AsmReadSegmentAccessRights ENDP

; -------------------------------------------------------------------
; AsmInvept - execute the INVEPT instruction.
;   Arg1 (RCX) = invalidation type (1 = single-context, 2 = all-context)
;   Arg2 (RDX) = pointer to a 16-byte INVEPT_DESCRIPTOR { EPTP, Reserved }
; -------------------------------------------------------------------
AsmInvept PROC
    invept  rcx, oword ptr [rdx]
    ret
AsmInvept ENDP

END
