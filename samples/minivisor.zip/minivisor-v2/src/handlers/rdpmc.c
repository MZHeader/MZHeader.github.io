

#include "../minivisor.h"
#include <intrin.h>

#define RDPMC_FIXED_FLAG    0x40000000u   
#define RDPMC_FAST_FLAG     0x80000000u   

static BOOLEAN
SafeReadPmc(UINT32 idx, UINT64* out)
{
    __try
    {
        *out = __readpmc(idx);
        return TRUE;
    }
    __except (GetExceptionCode() == STATUS_PRIVILEGED_INSTRUCTION
              ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH)
    {
        return FALSE;
    }
}

static UINT32
GuestCpl(VOID)
{
    SIZE_T ss = 0;
    __vmx_vmread(VMCS_GUEST_SS_SELECTOR, &ss);
    return (UINT32)(ss & 3);
}

static UINT64
GuestCr4(VOID)
{
    SIZE_T cr4 = 0;
    __vmx_vmread(VMCS_GUEST_CR4, &cr4);
    return (UINT64)cr4;
}

static BOOLEAN
RdpmcIndexValid(UINT32 idx)
{
    int regs[4];
    UINT32 numGp, numFixed, counter;

    __cpuid(regs, CPUID_LEAF_PERFMON);
    numGp    = ((UINT32)regs[0] >> 8) & 0xFF;   
    numFixed = (UINT32)regs[3] & 0x1F;          

    if (idx & RDPMC_FIXED_FLAG)
    {
        counter = idx & ~(RDPMC_FIXED_FLAG | RDPMC_FAST_FLAG);
        return counter < numFixed;
    }

    counter = idx & ~RDPMC_FAST_FLAG;
    return counter < numGp;
}

VOID
HandleRdpmc(PVCPU vcpu, PGUEST_REGISTERS regs)
{
    UINT32 idx = (UINT32)regs->Rcx;
    UINT64 value = 0;

    

    if (GuestCpl() != 0 && (GuestCr4() & CR4_PCE) == 0)
    {
        VmExitInjectGp(0);
        return;
    }

    

    if (!RdpmcIndexValid(idx) || !SafeReadPmc(idx, &value))
    {
        VmExitInjectGp(0);
        return;
    }

    

    if (idx == 0x40000001 || idx == 0x40000002)
    {
        INT64 adjusted = (INT64)value + vcpu->TscOffset;
        value = (adjusted < 0) ? 0 : (UINT64)adjusted;
    }

    

    regs->Rax = (UINT32)value;
    regs->Rdx = (UINT32)(value >> 32);
    VmExitAdvanceRip();
}
