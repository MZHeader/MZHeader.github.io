

#include "../minivisor.h"
#include <intrin.h>

#define MV_HIDE_APERF  1

/* APERF cost per exit is derived as TSC-cost × cached frequency ratio rather than
 * by reading APERF on every exit.  The ratio (APERF cycles per MPERF cycle) is
 * refreshed every MV_APERF_RATIO_INTERVAL exits with a single APERF+MPERF sample. */
#define MV_APERF_RATIO_SHIFT        16
#define MV_APERF_RATIO_INTERVAL     256u

#define MV_TSC_SYNC                 1
#define MV_TSC_MAX_SLEW_PER_EXIT    64ULL

#if MV_TSC_SYNC
static VOID
AtomicMin64(volatile INT64* dst, INT64 val)
{
    INT64 cur = *dst;
    while (val < cur)
    {
        INT64 prev = _InterlockedCompareExchange64(dst, val, cur);
        if (prev == cur) break;
        cur = prev;
    }
}

static VOID
AtomicMax64(volatile INT64* dst, INT64 val)
{
    INT64 cur = *dst;
    while (val > cur)
    {
        INT64 prev = _InterlockedCompareExchange64(dst, val, cur);
        if (prev == cur) break;
        cur = prev;
    }
}
#endif

VOID
TscBitmapInit(PVCPU vcpu)
{
    vcpu->TscOffset = 0;
    vcpu->LastExitTsc = __rdtsc();
    vcpu->TscNativeCost = 0;
    vcpu->TscFixedOverhead = 0;

    vcpu->AperfOffset = 0;
    vcpu->AperfRatioScaled = 1u << MV_APERF_RATIO_SHIFT;   /* 1:1 until first sample */
    vcpu->AperfRatioCountdown = 0;                          /* force a sample on first exit */
    vcpu->AperfRatioBaseA = 0;
    vcpu->AperfRatioBaseM = 0;
#if MV_HIDE_APERF
    {
        /* APERF/MPERF are optional (CPUID.06H:ECX[0]).  Reading them when absent
         * raises #GP — fatal in VMX root — so probe support once here and skip all
         * APERF accesses on CPUs/VMs that lack it. */
        int feat[4];
        __cpuid(feat, 6);
        vcpu->AperfMperfOk = ((UINT32)feat[2] & 1u) != 0;
    }
#else
    vcpu->AperfMperfOk = FALSE;
#endif

#if MV_TSC_SYNC
    

    AtomicMin64(&g_Hv.MinTscOffset, vcpu->TscOffset);
#endif
    
}

VOID
TscOnExitEntry(PVCPU vcpu)
{
    /* Only the TSC is sampled on entry now; APERF cost is derived from the TSC
     * span × cached ratio in TscOnExitExit, so no per-exit RDMSR is needed. */
    vcpu->ExitEntryTsc = __rdtsc();
}

VOID
TscOnExitExit(PVCPU vcpu)
{
    UINT64 now = __rdtsc();
    UINT64 realDelta = now - vcpu->LastExitTsc;     
    UINT64 tscSpan = now - vcpu->ExitEntryTsc;      
    UINT64 steal = tscSpan + vcpu->TscFixedOverhead;

    

    if (steal > realDelta)
    {
        steal = realDelta;
    }

    vcpu->TscOffset -= (INT64)steal;

    

    UINT64 extra = 0;

#if MV_TSC_SYNC
    {
        INT64 lead = vcpu->TscOffset - g_Hv.MinTscOffset;   

        
        AtomicMax64(&g_Hv.MaxOffsetSpread, lead);

        if (lead > 0)
        {
            UINT64 headroom = realDelta - steal;    
            extra = (UINT64)lead;
            if (extra > headroom)                 extra = headroom;
            if (extra > MV_TSC_MAX_SLEW_PER_EXIT) extra = MV_TSC_MAX_SLEW_PER_EXIT;
            vcpu->TscOffset -= (INT64)extra;
        }

        
        AtomicMin64(&g_Hv.MinTscOffset, vcpu->TscOffset);
    }
#endif

    vcpu->LastExitTsc = now;
    __vmx_vmwrite(VMCS_CTRL_TSC_OFFSET, (UINT64)vcpu->TscOffset);

#if MV_HIDE_APERF
    if (vcpu->AperfMperfOk)
    {
        /* Refresh the APERF/MPERF frequency ratio occasionally instead of reading
         * APERF on every exit.  Both counters stop in idle, so their delta ratio
         * is the clean C0 frequency ratio (APERF cycles per MPERF==TSC cycle). */
        if (vcpu->AperfRatioCountdown == 0)
        {
            UINT64 a = __readmsr(IA32_APERF);
            UINT64 m = __readmsr(IA32_MPERF);
            UINT64 da = a - vcpu->AperfRatioBaseA;
            UINT64 dm = m - vcpu->AperfRatioBaseM;

            if (vcpu->AperfRatioBaseM != 0 && dm != 0)
            {
                vcpu->AperfRatioScaled = (da << MV_APERF_RATIO_SHIFT) / dm;
                if (vcpu->AperfRatioScaled == 0)
                {
                    vcpu->AperfRatioScaled = 1u << MV_APERF_RATIO_SHIFT;
                }
            }
            vcpu->AperfRatioBaseA = a;
            vcpu->AperfRatioBaseM = m;
            vcpu->AperfRatioCountdown = MV_APERF_RATIO_INTERVAL;
        }
        else
        {
            vcpu->AperfRatioCountdown--;
        }

        /* APERF cycles stolen this exit = TSC cycles stolen (handler span + fixed
         * overhead + sync slew, all already removed from TscOffset) × freq ratio.
         * tscSpan is measured exactly, so only the slowly-varying ratio is
         * approximate — far cheaper than two RDMSRs per exit and accurate enough
         * to keep a guest APERF read consistent with its TSC read. */
        UINT64 aperfSteal = (((UINT64)steal + extra) * vcpu->AperfRatioScaled)
                            >> MV_APERF_RATIO_SHIFT;
        vcpu->AperfOffset -= (INT64)aperfSteal;
    }
#else
    UNREFERENCED_PARAMETER(extra);
#endif
}

UINT64
TscMeasureCpuidCost(UINT64* samples)
{
    int regs[4];
    UINT64 i, j, min;

    for (i = 0; i < CPUID_TIMING_SAMPLES; i++)
    {
        UINT64 t0 = __rdtsc();
        __cpuid(regs, 0);
        samples[i] = __rdtsc() - t0;
    }

    
    for (i = 0; i <= CPUID_TIMING_SAMPLES / 2; i++)
    {
        UINT64 sel = i;
        for (j = i + 1; j < CPUID_TIMING_SAMPLES; j++)
        {
            if (samples[j] < samples[sel])
            {
                sel = j;
            }
        }
        min = samples[i];
        samples[i] = samples[sel];
        samples[sel] = min;
    }
    return samples[CPUID_TIMING_SAMPLES / 2];
}

VOID
TscSetNativeCost(PVCPU vcpu, UINT64 nativeCost)
{
    vcpu->TscNativeCost = nativeCost;
}

VOID
TscCalibrate(PVCPU vcpu)
{
    UINT64 guestCost;

    

    guestCost = TscMeasureCpuidCost(vcpu->TscSamples);

    if (guestCost > vcpu->TscNativeCost)
    {
        vcpu->TscFixedOverhead = guestCost - vcpu->TscNativeCost;
    }
    else
    {
        vcpu->TscFixedOverhead = 0;
    }

    MV_LOG("tsc calibrate: CPU %lu native=%llu guest=%llu fixedOverhead=%llu",
           vcpu->ProcessorIndex, vcpu->TscNativeCost, guestCost, vcpu->TscFixedOverhead);
}
