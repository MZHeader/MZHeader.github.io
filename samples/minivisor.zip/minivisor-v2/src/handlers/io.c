

#include "../minivisor.h"
#include <intrin.h>

VOID
IoBitmapSet(PVCPU vcpu, UINT16 port)
{
    if (port < 0x8000)
    {
        vcpu->IoBitmapA[port >> 3] |= (UCHAR)(1U << (port & 7));
    }
    else
    {
        UINT32 idx = (UINT32)port - 0x8000;
        vcpu->IoBitmapB[idx >> 3] |= (UCHAR)(1U << (idx & 7));
    }
}

VOID
HandleIoInstruction(PVCPU vcpu, PGUEST_REGISTERS regs)
{
    SIZE_T qual = 0, rip = 0;
    UINT32 port, sizeBits, size;
    BOOLEAN isIn, isString;

    __vmx_vmread(VMCS_EXIT_QUALIFICATION, &qual);
    __vmx_vmread(VMCS_GUEST_RIP,          &rip);

    sizeBits = (UINT32)qual & 7;
    size     = (sizeBits == 0) ? 1u : (sizeBits == 1) ? 2u : 4u;
    isIn     = (qual & 8)  != 0;
    isString = (qual & 16) != 0;
    port     = (UINT32)(qual >> 16) & 0xFFFF;

    

    if (!isString &&
        PmTimerHandleIo(vcpu, regs, port, size, isIn))
    {
        return;
    }

    /* 8254 PIT channel-0: synthesize a TSC-coherent count (non-string only). */
    if (!isString &&
        PitHandleIo(vcpu, regs, port, size, isIn))
    {
        return;
    }

    MV_LOG("IO: %s%s port=%04x size=%u RIP=%llx",
           isString ? "STRING-" : "",
           isIn ? "IN" : "OUT",
           port, size, (UINT64)rip);

    if (isString)
    {
        

        MV_ERR("IO: string instruction on port %04x not emulated — advancing RIP", port);
        VmExitAdvanceRip();
        return;
    }

    if (isIn)
    {
        

        switch (size)
        {
        case 1:
            regs->Rax = (regs->Rax & ~(UINT64)0xFF)   | (UINT64)__inbyte((USHORT)port);
            break;
        case 2:
            regs->Rax = (regs->Rax & ~(UINT64)0xFFFF) | (UINT64)__inword((USHORT)port);
            break;
        default:
            regs->Rax = (UINT64)__indword((USHORT)port);    
            break;
        }
    }
    else
    {
        UINT32 val = (UINT32)regs->Rax;
        switch (size)
        {
        case 1:  __outbyte((USHORT)port,  (UCHAR)val);  break;
        case 2:  __outword((USHORT)port,  (USHORT)val); break;
        default: __outdword((USHORT)port, val);          break;
        }
    }

    VmExitAdvanceRip();
}
