

#include "../minivisor.h"
#include <intrin.h>

VOID
HandleCpuid(PVCPU vcpu, PGUEST_REGISTERS regs)
{
    int out[4];
    UINT32 leaf    = (UINT32)regs->Rax;
    UINT32 subleaf = (UINT32)regs->Rcx;

    UNREFERENCED_PARAMETER(vcpu);

    __cpuidex(out, (int)leaf, (int)subleaf);
    StealthFilterCpuid(leaf, subleaf, out);

    regs->Rax = (UINT32)out[0];
    regs->Rbx = (UINT32)out[1];
    regs->Rcx = (UINT32)out[2];
    regs->Rdx = (UINT32)out[3];

    /* Optional target-image logging.  CPUID is the article's hottest detection
     * instruction, so the GUEST_RIP VMREAD (≈tens of cycles) is done only when a
     * target filter is actually configured — and VmExitAdvanceRip reads RIP again
     * anyway, so this avoids a redundant VMREAD on every CPUID in the common case. */
    if (g_Hv.TargetBase != 0)
    {
        SIZE_T guestRip = 0;
        __vmx_vmread(VMCS_GUEST_RIP, &guestRip);
        if ((UINT64)guestRip >= g_Hv.TargetBase &&
            (UINT64)guestRip <  g_Hv.TargetBase + (UINT64)g_Hv.TargetSize)
        {
            MV_LOG("[TARGET] CPUID: RIP=%llx leaf=%08x sub=%08x -> eax=%08x ebx=%08x ecx=%08x edx=%08x",
                   (UINT64)guestRip, leaf, subleaf,
                   (UINT32)regs->Rax, (UINT32)regs->Rbx,
                   (UINT32)regs->Rcx, (UINT32)regs->Rdx);
        }
    }
}
