

#include "../minivisor.h"
#include <intrin.h>

static UINT64
ReadGpr(PGUEST_REGISTERS regs, UINT32 index)
{
    switch (index)
    {
    case 0:  return regs->Rax;
    case 1:  return regs->Rcx;
    case 2:  return regs->Rdx;
    case 3:  return regs->Rbx;
    case 4:  {   
        SIZE_T rsp = 0;
        __vmx_vmread(VMCS_GUEST_RSP, &rsp);
        return rsp;
    }
    case 5:  return regs->Rbp;
    case 6:  return regs->Rsi;
    case 7:  return regs->Rdi;
    case 8:  return regs->R8;
    case 9:  return regs->R9;
    case 10: return regs->R10;
    case 11: return regs->R11;
    case 12: return regs->R12;
    case 13: return regs->R13;
    case 14: return regs->R14;
    default: return regs->R15;
    }
}

VOID
HandleCrAccess(PVCPU vcpu, PGUEST_REGISTERS regs)
{
    SIZE_T qual = 0;
    CR_ACCESS_QUALIFICATION q;

    UNREFERENCED_PARAMETER(vcpu);

    __vmx_vmread(VMCS_EXIT_QUALIFICATION, &qual);
    q.AsUInt64 = qual;

    

    if (q.AccessType == CR_ACCESS_TYPE_MOV_TO_CR && q.CrNumber == 4)
    {
        UINT64 value = ReadGpr(regs, (UINT32)q.GpRegister);
        if (value & CR4_VMXE)
        {
            VmExitInjectGp(0);      
            return;
        }
        
        __vmx_vmwrite(VMCS_GUEST_CR4, value | CR4_VMXE);
        __vmx_vmwrite(VMCS_CTRL_CR4_READ_SHADOW, StealthCr4ReadShadow(value));
    }

    VmExitAdvanceRip();
}
