
#include "../minivisor.h"
#include <intrin.h>

VOID
MsrBitmapSet(PVOID bitmap, UINT32 msr, BOOLEAN read, BOOLEAN write)
{
    PUCHAR bm = (PUCHAR)bitmap;

    if (msr <= 0x00001FFF)
    {
        if (read)  bm[0x000 + (msr >> 3)] |= (UCHAR)(1U << (msr & 7));
        if (write) bm[0x800 + (msr >> 3)] |= (UCHAR)(1U << (msr & 7));
    }
    else if (msr >= 0xC0000000 && msr <= 0xC0001FFF)
    {
        UINT32 idx = msr - 0xC0000000;
        if (read)  bm[0x400 + (idx >> 3)] |= (UCHAR)(1U << (idx & 7));
        if (write) bm[0xC00 + (idx >> 3)] |= (UCHAR)(1U << (idx & 7));
    }

}

static BOOLEAN
SafeReadMsr(UINT32 msr, UINT64* out)
{
    __try
    {
        *out = __readmsr(msr);
        return TRUE;
    }
    __except (GetExceptionCode() == STATUS_PRIVILEGED_INSTRUCTION
              ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH)
    {
        return FALSE;
    }
}

static BOOLEAN
SafeWriteMsr(UINT32 msr, UINT64 value)
{
    __try
    {
        __writemsr(msr, value);
        return TRUE;
    }
    __except (GetExceptionCode() == STATUS_PRIVILEGED_INSTRUCTION
              ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH)
    {
        return FALSE;
    }
}

static VOID
MsrTraceIfTarget(PCSTR op, UINT64 rip, UINT32 msr, UINT64 value)
{
    if (g_Hv.TargetBase != 0 &&
        rip >= g_Hv.TargetBase &&
        rip <  g_Hv.TargetBase + (UINT64)g_Hv.TargetSize)
    {
        MV_LOG("[TARGET] %s: RIP=%llx MSR=%08x val=%016llx", op, rip, msr, value);
    }
}

VOID
HandleMsrRead(PVCPU vcpu, PGUEST_REGISTERS regs)
{
    UINT32 msr = (UINT32)regs->Rcx;
    UINT64 value = 0;
    SIZE_T guestRip = 0;

    __vmx_vmread(VMCS_GUEST_RIP, &guestRip);

    

    if (msr == IA32_DEBUGCTL)
    {
        value = vcpu->ShadowDebugCtl;
        MsrTraceIfTarget("RDMSR", (UINT64)guestRip, msr, value);
        regs->Rax = (UINT32)value;
        regs->Rdx = (UINT32)(value >> 32);
        VmExitAdvanceRip();
        return;
    }

    

    if (msr == IA32_MPERF || msr == IA32_APERF || msr == IA32_PPERF)
    {
        UINT64 raw = 0;
        INT64  off;
        INT64  adjusted;

        if (!SafeReadMsr(msr, &raw))
        {
            VmExitInjectGp(0);
            return;
        }

        off = (msr == IA32_MPERF) ? vcpu->TscOffset : vcpu->AperfOffset;
        adjusted = (INT64)raw + off;
        value = (adjusted < 0) ? 0 : (UINT64)adjusted;

        MsrTraceIfTarget("RDMSR", (UINT64)guestRip, msr, value);
        regs->Rax = (UINT32)value;
        regs->Rdx = (UINT32)(value >> 32);
        VmExitAdvanceRip();
        return;
    }

    MsrTraceIfTarget("RDMSR", (UINT64)guestRip, msr, 0);

    switch (StealthMsrReadAction(msr, &value))
    {
    case MSR_INJECT_GP:
        VmExitInjectGp(0);         
        return;

    case MSR_PASSTHROUGH:
        if (!SafeReadMsr(msr, &value))
        {
            VmExitInjectGp(0);     
            return;
        }
        break;

    case MSR_VALUE:
    default:
        break;                    
    }

    regs->Rax = (UINT32)value;
    regs->Rdx = (UINT32)(value >> 32);
    VmExitAdvanceRip();
}

VOID
HandleMsrWrite(PVCPU vcpu, PGUEST_REGISTERS regs)
{
    UINT32 msr = (UINT32)regs->Rcx;
    UINT64 value = ((UINT64)(UINT32)regs->Rdx << 32) | (UINT32)regs->Rax;
    SIZE_T guestRip = 0;

    __vmx_vmread(VMCS_GUEST_RIP, &guestRip);
    MsrTraceIfTarget("WRMSR", (UINT64)guestRip, msr, value);

    switch (StealthMsrWriteAction(msr, value))
    {
    case MSR_INJECT_GP:
        VmExitInjectGp(0);
        return;

    case MSR_PASSTHROUGH:
    default:

        if (msr == IA32_TSC)
        {
            /* Emulate a guest TSC write via the VMCS TSC offset ONLY.  Executing
             * WRMSR IA32_TSC here would write the *physical* TSC (offsetting does
             * not apply in VMX root), desyncing this core from the others and
             * tripping the CLOCK_WATCHDOG_TIMEOUT bugcheck.  Set the offset so the
             * guest's next RDTSC reads `value`. */
            INT64 newOffset = (INT64)value - (INT64)__rdtsc();
            vcpu->TscOffset = newOffset;
            __vmx_vmwrite(VMCS_CTRL_TSC_OFFSET, (UINT64)newOffset);
            break;          /* RIP advanced below; never touch the real MSR */
        }

        if (msr == IA32_DEBUGCTL)
        {
            vcpu->ShadowDebugCtl = value;
            value &= ~DEBUGCTL_HYPERVISOR_MASK;
        }

        if (!SafeWriteMsr(msr, value))
        {
            VmExitInjectGp(0);
            return;
        }
        break;
    }

    VmExitAdvanceRip();
}
