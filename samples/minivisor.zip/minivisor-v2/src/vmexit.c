

#include "minivisor.h"
#include <intrin.h>

VOID
VmExitAdvanceRip(VOID)
{
    SIZE_T rip = 0, len = 0;
    __vmx_vmread(VMCS_GUEST_RIP, &rip);
    __vmx_vmread(VMCS_EXIT_INSTRUCTION_LEN, &len);
    __vmx_vmwrite(VMCS_GUEST_RIP, rip + len);
}

static VOID
InjectException(UINT32 vector, BOOLEAN deliverErrorCode, UINT32 errorCode)
{
    VMENTRY_INTERRUPT_INFO info;

    info.AsUInt32 = 0;
    info.Vector = vector;
    info.InterruptionType = INTERRUPT_TYPE_HARDWARE_EXCEPTION;
    info.DeliverErrorCode = deliverErrorCode ? 1 : 0;
    info.Valid = 1;

    if (deliverErrorCode)
    {
        __vmx_vmwrite(VMCS_CTRL_ENTRY_EXCEPTION_CODE, errorCode);
    }
    __vmx_vmwrite(VMCS_CTRL_ENTRY_INTR_INFO, info.AsUInt32);
    
}

VOID
VmExitInjectGp(UINT32 errorCode)
{
    InjectException(EXCEPTION_VECTOR_GP, TRUE, errorCode);
}

VOID
VmExitInjectUd(VOID)
{
    InjectException(EXCEPTION_VECTOR_UD, FALSE, 0);
}

VOID
VmExitInjectBp(VOID)
{
    

    VMENTRY_INTERRUPT_INFO info;
    info.AsUInt32 = 0;
    info.Vector            = EXCEPTION_VECTOR_BP;
    info.InterruptionType  = INTERRUPT_TYPE_SOFTWARE_EXCEPTION;
    info.DeliverErrorCode  = 0;
    info.Valid             = 1;
    __vmx_vmwrite(VMCS_CTRL_ENTRY_INTR_INFO, info.AsUInt32);
    __vmx_vmwrite(VMCS_CTRL_ENTRY_INSTR_LEN, 1);  
}

static BOOLEAN
XsetbvXcr0Valid(UINT32 index, UINT64 value)
{
    int regs[4];
    UINT64 supported;
    const UINT64 avx512 = XCR0_OPMASK | XCR0_ZMM_HI256 | XCR0_HI16_ZMM;

    if (index != 0)
    {
        return FALSE;       
    }

    
    __cpuidex(regs, CPUID_LEAF_XSTATE, 0);
    supported = (UINT64)(UINT32)regs[0] | ((UINT64)(UINT32)regs[3] << 32);

    if ((value & ~supported) != 0)      return FALSE;   
    if ((value & XCR0_X87) == 0)        return FALSE;    
    if ((value & XCR0_AVX) && !(value & XCR0_SSE)) return FALSE;
    if (((value & XCR0_BNDREG) != 0) != ((value & XCR0_BNDCSR) != 0)) return FALSE;
    if (value & avx512)
    {
        if ((value & avx512) != avx512) return FALSE;    
        if (!(value & XCR0_AVX))        return FALSE;     
    }
    return TRUE;
}

static VOID
HandleXsetbv(PGUEST_REGISTERS regs)
{
    UINT32 index = (UINT32)regs->Rcx;
    UINT64 value = ((UINT64)(UINT32)regs->Rdx << 32) | (UINT32)regs->Rax;

    if (!XsetbvXcr0Valid(index, value))
    {
        VmExitInjectGp(0);      
        return;
    }
    _xsetbv(index, value);
    VmExitAdvanceRip();
}

static VOID
PrepareDevirtualize(PVMEXIT_FRAME frame)
{
    SIZE_T rip = 0, len = 0, rsp = 0, rflags = 0;

    __vmx_vmread(VMCS_GUEST_RIP, &rip);
    __vmx_vmread(VMCS_EXIT_INSTRUCTION_LEN, &len);
    __vmx_vmread(VMCS_GUEST_RSP, &rsp);
    __vmx_vmread(VMCS_GUEST_RFLAGS, &rflags);

    frame->OffRip = rip + len;       
    frame->OffRsp = rsp;
    frame->OffRflags = rflags;
}

BOOLEAN
HandleVmExit(PVMEXIT_FRAME frame)
{
    PVCPU vcpu = frame->Vcpu;
    PGUEST_REGISTERS regs = &frame->Regs;
    SIZE_T reasonField = 0;
    UINT32 reason;

    TscOnExitEntry(vcpu);

    

    if (vcpu->EptInveptPending || g_Hv.EptFlushPending)
    {
        EptInvalidateAll(&g_Hv.Ept);
        vcpu->EptInveptPending = FALSE;
        /* EptFlushPending is cleared by the caller after the IPI completes. */
    }

    __vmx_vmread(VMCS_EXIT_REASON, &reasonField);
    reason = (UINT32)reasonField & 0xFFFF;

    switch (reason)
    {


    case EXIT_REASON_EXCEPTION_NMI:
    {
        SIZE_T intrInfo = 0;
        UINT32 vector;

        __vmx_vmread(VMCS_EXIT_INTR_INFO, &intrInfo);
        vector = (UINT32)intrInfo & 0xFF;

        if (vector == EXCEPTION_VECTOR_BP)
        {
            SIZE_T guestRip = 0;
            PSHADOW_HOOK hook;

            __vmx_vmread(VMCS_GUEST_RIP, &guestRip);
            
            hook = ShadowHookFindByInt3((UINT64)guestRip - 1);
            if (hook != NULL)
            {
                ShadowHookHandleBp(vcpu, frame, hook);
            }
            else
            {
                VmExitInjectBp();
            }
        }
        else
        {
            
            __vmx_vmwrite(VMCS_CTRL_ENTRY_INTR_INFO, intrInfo | (SIZE_T)(1UL << 31));
            if (intrInfo & (1UL << 11))   
            {
                SIZE_T errCode = 0;
                __vmx_vmread(VMCS_EXIT_INTR_ERROR_CODE, &errCode);
                __vmx_vmwrite(VMCS_CTRL_ENTRY_EXCEPTION_CODE, (UINT32)errCode);
            }
        }
        break;
    }

    case EXIT_REASON_EXTERNAL_INTERRUPT:
        break;

    case EXIT_REASON_TRIPLE_FAULT:
    {
        SIZE_T rip = 0, rsp = 0, rflags = 0;
        __vmx_vmread(VMCS_GUEST_RIP, &rip);
        __vmx_vmread(VMCS_GUEST_RSP, &rsp);
        __vmx_vmread(VMCS_GUEST_RFLAGS, &rflags);
        frame->OffRip = rip;
        frame->OffRsp = rsp;
        frame->OffRflags = rflags;
        MV_ERR("Triple fault on CPU %lu — devirtualizing (RIP=%llx)",
               vcpu->ProcessorIndex, (UINT64)rip);
        return FALSE;
    }

    case EXIT_REASON_CPUID:
        if ((UINT32)regs->Rax == MV_CPUID_UNLOAD_MAGIC)
        {
            PrepareDevirtualize(frame);
            return FALSE;       
        }
        HandleCpuid(vcpu, regs);
        VmExitAdvanceRip();
        break;

    case EXIT_REASON_MSR_READ:
        HandleMsrRead(vcpu, regs);
        break;      

    case EXIT_REASON_MSR_WRITE:
        HandleMsrWrite(vcpu, regs);
        break;

    case EXIT_REASON_RDPMC:
        HandleRdpmc(vcpu, regs);
        break;

    case EXIT_REASON_IO_INSTRUCTION:
        HandleIoInstruction(vcpu, regs);
        break;

    case EXIT_REASON_CR_ACCESS:
        HandleCrAccess(vcpu, regs);     
        break;

    case EXIT_REASON_XSETBV:
        HandleXsetbv(regs);
        break;

    case EXIT_REASON_INVD:
        __wbinvd();             
        VmExitAdvanceRip();
        break;

    

    case EXIT_REASON_EPT_VIOLATION:
    {
        SIZE_T gpa = 0;
        __vmx_vmread(VMCS_GUEST_PHYSICAL_ADDRESS, &gpa);

        if (g_Hv.Hpet.Valid &&
            (UINT64)gpa >= g_Hv.Hpet.PhysBase &&
            (UINT64)gpa <  g_Hv.Hpet.PhysBase + PAGE_SIZE)
        {
            HpetHandleViolation(vcpu, frame);
        }
        else if (g_Hv.Apic.Valid &&
                 (UINT64)gpa >= g_Hv.Apic.PhysBase &&
                 (UINT64)gpa <  g_Hv.Apic.PhysBase + PAGE_SIZE)
        {
            ApicHandleViolation(vcpu, frame);
        }
        else if (ShadowHookFindByPage((UINT64)gpa & ~(UINT64)(PAGE_SIZE - 1)) != NULL)
        {
            SIZE_T qual = 0;
            __vmx_vmread(VMCS_EXIT_QUALIFICATION, &qual);
            ShadowHookHandleViolation(vcpu, frame, (UINT64)gpa, qual);
        }
        else if (EptIsHookedPage(&g_Hv.Ept, (UINT64)gpa))
        {
            

            SIZE_T qual = 0, gla = 0, rip = 0;
            __vmx_vmread(VMCS_EXIT_QUALIFICATION,    &qual);
            __vmx_vmread(VMCS_GUEST_LINEAR_ADDRESS,  &gla);
            __vmx_vmread(VMCS_GUEST_RIP,             &rip);

            MV_LOG("[HOOK] %s GPA=%llx GLA=%llx RIP=%llx CPU %lu",
                   (qual & 2) ? "WRITE" : "READ",
                   (UINT64)gpa, (UINT64)gla, (UINT64)rip,
                   vcpu->ProcessorIndex);

            EptSetGpaPresent(&g_Hv.Ept, (UINT64)gpa, TRUE);
            EptInvalidateAll(&g_Hv.Ept);

            vcpu->MtfExposedPage  = (UINT64)gpa;
            vcpu->MtfHookExposed  = TRUE;

            {
                SIZE_T procCtl = 0;
                __vmx_vmread(VMCS_CTRL_PROC_BASED, &procCtl);
                __vmx_vmwrite(VMCS_CTRL_PROC_BASED, procCtl | PROC_CTL_MONITOR_TRAP_FLAG);
            }
        }
        else
        {
            

            MV_ERR("EPT violation: unexpected GPA=%llx on CPU %lu — EPT setup bug",
                   (UINT64)gpa, vcpu->ProcessorIndex);
            VmExitInjectUd();
        }
        break;
    }

    

    case EXIT_REASON_MONITOR_TRAP_FLAG:
        if (vcpu->MtfShadowHook != NULL)
        {
            ShadowHookHandleMtf(vcpu);
        }
        else if (vcpu->MtfHookExposed)
        {
            
            SIZE_T procCtl = 0;
            EptRestoreExecuteOnly(&g_Hv.Ept, vcpu->MtfExposedPage);
            EptInvalidateAll(&g_Hv.Ept);
            __vmx_vmread(VMCS_CTRL_PROC_BASED, &procCtl);
            __vmx_vmwrite(VMCS_CTRL_PROC_BASED, procCtl & ~(SIZE_T)PROC_CTL_MONITOR_TRAP_FLAG);
            vcpu->MtfHookExposed = FALSE;
        }
        else if (vcpu->MtfExposedPage == g_Hv.Hpet.PhysBase)
        {
            HpetHandleMtf(vcpu, frame);
        }
        else if (g_Hv.Apic.Valid && vcpu->MtfExposedPage == g_Hv.Apic.PhysBase)
        {
            ApicHandleMtf(vcpu, frame);
        }
        else
        {
            /* No handler claimed this MTF.  We MUST still clear the monitor-trap
             * flag — otherwise it stays armed, the next VMRESUME single-steps
             * straight back here, and the guest livelocks (a hard hang on bare
             * metal).  Log once and disarm. */
            SIZE_T procCtl = 0;
            __vmx_vmread(VMCS_CTRL_PROC_BASED, &procCtl);
            __vmx_vmwrite(VMCS_CTRL_PROC_BASED,
                          procCtl & ~(SIZE_T)PROC_CTL_MONITOR_TRAP_FLAG);
            MV_ERR("MTF: unknown exposed page %llx on CPU %lu — disarmed",
                   vcpu->MtfExposedPage, vcpu->ProcessorIndex);
        }

        break;

    

    case EXIT_REASON_EPT_MISCONFIG:
    {
        SIZE_T gpa = 0;
        __vmx_vmread(VMCS_GUEST_PHYSICAL_ADDRESS, &gpa);
        MV_ERR("EPT misconfiguration: GPA=%llx on CPU %lu — hypervisor bug",
               (UINT64)gpa, vcpu->ProcessorIndex);
        
        VmExitInjectUd();
        break;
    }

    

    case EXIT_REASON_VMCALL:
    case EXIT_REASON_VMCLEAR:
    case EXIT_REASON_VMLAUNCH:
    case EXIT_REASON_VMPTRLD:
    case EXIT_REASON_VMPTRST:
    case EXIT_REASON_VMREAD:
    case EXIT_REASON_VMRESUME:
    case EXIT_REASON_VMWRITE:
    case EXIT_REASON_VMXOFF:
    case EXIT_REASON_VMXON:
        VmExitInjectUd();
        break;

    case EXIT_REASON_INVPCID:
        VmExitInjectUd();
        break;

    default:
        MV_ERR("Unhandled VM-exit reason %lu on CPU %lu", reason, vcpu->ProcessorIndex);
        

        VmExitInjectUd();
        break;
    }

    TscOnExitExit(vcpu);
    return TRUE;
}
