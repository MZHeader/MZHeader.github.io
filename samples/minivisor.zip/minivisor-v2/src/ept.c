

#include "minivisor.h"
#include <intrin.h>

#define EPT_READ        (1ULL << 0)
#define EPT_WRITE       (1ULL << 1)
#define EPT_EXEC        (1ULL << 2)
#define EPT_RWX         (EPT_READ | EPT_WRITE | EPT_EXEC)

#define EPT_LARGE_PAGE  (1ULL << 7)     
#define EPT_IGNORE_PAT  (1ULL << 6)     

#define EPT_MT_WB       6ULL            
#define EPT_MT_SHIFT    3               

#define EPT_FRAME(entry)    ((entry) & 0x000FFFFFFFFFF000ULL)

#define EPT_DIR(pa)     ((pa) | EPT_RWX)

/*
 * Leaf entries set EPT memory type WB but do NOT set IPAT (EPT_IGNORE_PAT): with
 * IPAT clear the effective type is the SDM combination of the EPT type and the
 * guest's own type (PAT/MTRR).  That yields WB for RAM (guest WB + EPT WB) but
 * correctly preserves UC for MMIO the guest mapped uncached (UC always wins the
 * combine).  Forcing IPAT=1 would cache device MMIO as WB and can hang/corrupt
 * I/O — see EptBuild.  (Fully correct typing would read the MTRRs per range;
 * deferring to the guest type is the safe minimal behavior for a blue-pill.)
 */
#define EPT_LEAF_2MB(gpa)   \
    ((gpa) | EPT_RWX | EPT_LARGE_PAGE | (EPT_MT_WB << EPT_MT_SHIFT))

#define EPT_LEAF_4KB(pa)    \
    ((pa)  | EPT_RWX | (EPT_MT_WB << EPT_MT_SHIFT))

#define EPT_EPTP(pml4pa)    ((pml4pa) | 6ULL | (3ULL << 3))

#define EPT_PML4_IDX(gpa)   (((gpa) >> 39) & 0x1FFULL)
#define EPT_PDPT_IDX(gpa)   (((gpa) >> 30) & 0x1FFULL)
#define EPT_PD_IDX(gpa)     (((gpa) >> 21) & 0x1FFULL)
#define EPT_PT_IDX(gpa)     (((gpa) >> 12) & 0x1FFULL)
#define EPT_2MB_BASE(gpa)   ((gpa) & ~((2ULL << 20) - 1))  

static UINT64*
EptPml4(PEPT_STATE ept)
{
    return (UINT64*)ept->TablesVa;
}

static UINT64*
EptPdpt(PEPT_STATE ept)
{
    return (UINT64*)((PUCHAR)ept->TablesVa + PAGE_SIZE);
}

static UINT64*
EptPd(PEPT_STATE ept, ULONG pdIndex)
{
    return (UINT64*)((PUCHAR)ept->TablesVa + (SIZE_T)(2 + pdIndex) * PAGE_SIZE);
}

static UINT64
EptPdPhysical(PEPT_STATE ept, ULONG pdIndex)
{
    return ept->TablesPhysical + (UINT64)(2 + pdIndex) * PAGE_SIZE;
}

BOOLEAN
EptIsSupported(VOID)
{
    UINT64 cap = __readmsr(IA32_VMX_EPT_VPID_CAP);
    if (!(cap & EPT_CAP_4LEVEL))
    {
        MV_ERR("EPT: 4-level page walk not supported");
        return FALSE;
    }
    if (!(cap & EPT_CAP_WB))
    {
        MV_ERR("EPT: WB memory type for paging structures not supported");
        return FALSE;
    }
    if (!(cap & EPT_CAP_2MB))
    {
        MV_ERR("EPT: 2 MB large pages not supported");
        return FALSE;
    }
    return TRUE;
}

BOOLEAN
EptBuild(PEPT_STATE ept)
{
    UINT64 maxPhysical;
    ULONG  pdCount, i, j;
    SIZE_T tablesSize;
    UINT64* pml4;
    UINT64* pdpt;
    UINT64* pd;

    

    /*
     * Size the identity map to the CPU's full physical address width, NOT just
     * RAM top.  MMIO — especially a discrete GPU's large 64-bit Resizable-BAR
     * aperture (e.g. an RTX 4090's 24 GB VRAM window) — is mapped *above* the top
     * of RAM.  If we only covered RAM, the first GPU-driver access to that BAR
     * would hit an unmapped GPA → unexpected EPT violation → injected #UD →
     * bugcheck.  Mapping the whole addressable range identity-maps those BAR
     * pages too; with IPAT cleared (see leaf macros) their memory type defers to
     * the guest's UC/WC mapping, so caching stays correct.
     *
     * MAXPHYADDR = CPUID.80000008H:EAX[7:0].  Each PD covers 1 GB and the single
     * PDPT holds 512 entries, so coverage caps at 512 GB — fine for consumer
     * platforms (39-bit phys), where every BAR is below that ceiling.
     */
    {
        int cpb[4];
        ULONG physBits;

        __cpuid(cpb, 0x80000008);
        physBits = (ULONG)(cpb[0] & 0xFF);          /* EAX[7:0] = MAXPHYADDR */

        if (physBits <= 30)
        {
            pdCount = 1;
        }
        else if ((physBits - 30) >= 9)
        {
            pdCount = 512;                           /* >= 512 GB addressable */
        }
        else
        {
            pdCount = 1u << (physBits - 30);
        }
    }

    maxPhysical = (UINT64)pdCount << 30;
    if (pdCount < 4)
    {
        pdCount = 4;                                 /* always cover legacy MMIO */
    }

    
    tablesSize = (SIZE_T)(2 + pdCount) * PAGE_SIZE;
    ept->TablesVa = MemAllocContiguous(tablesSize);
    if (ept->TablesVa == NULL)
    {
        MV_ERR("EPT: failed to allocate %llu bytes for page tables", (UINT64)tablesSize);
        return FALSE;
    }
    ept->TablesPhysical = MemVirtualToPhysical(ept->TablesVa);
    ept->TablesSize     = tablesSize;
    ept->PdCount        = pdCount;

    
    ept->DecoyVa = MemAllocContiguous(PAGE_SIZE);
    if (ept->DecoyVa == NULL)
    {
        MV_ERR("EPT: failed to allocate decoy page");
        MemFreeContiguous(ept->TablesVa);
        ept->TablesVa = NULL;
        return FALSE;
    }
    ept->DecoyPhysical = MemVirtualToPhysical(ept->DecoyVa);

    
    RtlZeroMemory(ept->TablesVa, tablesSize);
    RtlZeroMemory(ept->DecoyVa, PAGE_SIZE);

    pml4 = EptPml4(ept);
    pdpt = EptPdpt(ept);

    
    pml4[0] = EPT_DIR(ept->TablesPhysical + PAGE_SIZE);

    
    for (i = 0; i < pdCount; i++)
    {
        pdpt[i] = EPT_DIR(EptPdPhysical(ept, i));

        
        pd = EptPd(ept, i);
        for (j = 0; j < 512; j++)
        {
            UINT64 gpa2mb = ((UINT64)i << 30) | ((UINT64)j << 21);
            pd[j] = EPT_LEAF_2MB(gpa2mb);
        }
    }

    ept->Eptp = EPT_EPTP(ept->TablesPhysical);

    MV_LOG("EPT: identity map built — %lu PDs, maxPhys=%llx, EPTP=%llx",
           pdCount, maxPhysical, ept->Eptp);
    return TRUE;
}

static UINT64*
EptSplit2Mb(PEPT_STATE ept, ULONG pdptIdx, ULONG pdIdx)
{
    UINT64   gpa2mb = ((UINT64)pdptIdx << 30) | ((UINT64)pdIdx << 21);
    UINT64*  pd;
    UINT64*  ptVa;
    UINT64   ptPa;
    ULONG    k;

    
    for (k = 0; k < ept->SplitCount; k++)
    {
        if (ept->Splits[k].Gpa2Mb == gpa2mb)
        {
            return ept->Splits[k].PtVirtual;
        }
    }

    if (ept->SplitCount >= EPT_MAX_SPLITS)
    {
        MV_ERR("EPT: split table limit reached (%u)", EPT_MAX_SPLITS);
        return NULL;
    }

    
    ptVa = (UINT64*)MemAllocContiguous(PAGE_SIZE);
    if (ptVa == NULL)
    {
        MV_ERR("EPT: failed to allocate split PT");
        return NULL;
    }
    ptPa = MemVirtualToPhysical(ptVa);

    
    for (k = 0; k < 512; k++)
    {
        ptVa[k] = EPT_LEAF_4KB(gpa2mb + (UINT64)k * PAGE_SIZE);
    }

    
    pd = EptPd(ept, pdptIdx);
    pd[pdIdx] = EPT_DIR(ptPa);

    
    ept->Splits[ept->SplitCount].Gpa2Mb    = gpa2mb;
    ept->Splits[ept->SplitCount].PtPhysical = ptPa;
    ept->Splits[ept->SplitCount].PtVirtual  = ptVa;
    ept->SplitCount++;

    return ptVa;
}

BOOLEAN
EptHideRange(PEPT_STATE ept, UINT64 physBase, SIZE_T size)
{
    UINT64 pa;
    UINT64 end = physBase + size;

    for (pa = physBase & ~(UINT64)(PAGE_SIZE - 1); pa < end; pa += PAGE_SIZE)
    {
        ULONG pdptIdx = (ULONG)EPT_PDPT_IDX(pa);
        ULONG pdIdx   = (ULONG)EPT_PD_IDX(pa);
        ULONG ptIdx   = (ULONG)EPT_PT_IDX(pa);
        UINT64* pt;

        

        if (EPT_PML4_IDX(pa) != 0 || pdptIdx >= ept->PdCount)
        {
            continue;
        }

        
        pt = EptSplit2Mb(ept, pdptIdx, pdIdx);
        if (pt == NULL)
        {
            return FALSE;
        }

        
        pt[ptIdx] = EPT_LEAF_4KB(ept->DecoyPhysical);
    }

    return TRUE;
}

BOOLEAN
EptTrapRange(PEPT_STATE ept, UINT64 physBase, SIZE_T size)
{
    UINT64 pa;
    UINT64 end = physBase + size;

    for (pa = physBase & ~(UINT64)(PAGE_SIZE - 1); pa < end; pa += PAGE_SIZE)
    {
        ULONG pdptIdx = (ULONG)EPT_PDPT_IDX(pa);
        ULONG pdIdx   = (ULONG)EPT_PD_IDX(pa);
        ULONG ptIdx   = (ULONG)EPT_PT_IDX(pa);
        UINT64* pt;

        if (EPT_PML4_IDX(pa) != 0 || pdptIdx >= ept->PdCount)
        {
            continue;
        }

        pt = EptSplit2Mb(ept, pdptIdx, pdIdx);
        if (pt == NULL)
        {
            return FALSE;
        }

        pt[ptIdx] = 0;  
    }

    return TRUE;
}

VOID
EptSetGpaPresent(PEPT_STATE ept, UINT64 gpa, BOOLEAN present)
{
    ULONG pdptIdx = (ULONG)EPT_PDPT_IDX(gpa);
    ULONG ptIdx   = (ULONG)EPT_PT_IDX(gpa);
    UINT64 gpa2mb = EPT_2MB_BASE(gpa);
    ULONG k;

    for (k = 0; k < ept->SplitCount; k++)
    {
        if (ept->Splits[k].Gpa2Mb == gpa2mb)
        {
            UINT64* pt = ept->Splits[k].PtVirtual;
            if (present)
            {
                
                pt[ptIdx] = EPT_LEAF_4KB(gpa & ~(UINT64)(PAGE_SIZE - 1));
            }
            else
            {
                
                pt[ptIdx] = 0;
            }
            return;
        }
    }

    MV_ERR("EptSetGpaPresent: GPA %llx not in split table — was EptTrapRange called?", gpa);
}

#define EPT_LEAF_4KB_XO(pa)  \
    ((pa) | EPT_EXEC | (EPT_MT_WB << EPT_MT_SHIFT))

BOOLEAN
EptSetExecuteOnly(PEPT_STATE ept, UINT64 physBase, SIZE_T size)
{
    UINT64 cap;
    UINT64 pa;
    UINT64 end = physBase + (UINT64)size;

    cap = __readmsr(IA32_VMX_EPT_VPID_CAP);
    if (!(cap & EPT_CAP_EXEC_ONLY))
    {
        MV_ERR("EPT: execute-only pages not supported by this CPU");
        return FALSE;
    }

    for (pa = physBase & ~(UINT64)(PAGE_SIZE - 1); pa < end; pa += PAGE_SIZE)
    {
        ULONG   pdptIdx = (ULONG)EPT_PDPT_IDX(pa);
        ULONG   pdIdx   = (ULONG)EPT_PD_IDX(pa);
        ULONG   ptIdx   = (ULONG)EPT_PT_IDX(pa);
        UINT64* pt;

        if (EPT_PML4_IDX(pa) != 0 || pdptIdx >= ept->PdCount)
        {
            continue;
        }

        if (ept->HookCount >= EPT_MAX_HOOKS)
        {
            MV_ERR("EPT: hook table limit reached (%u)", EPT_MAX_HOOKS);
            return FALSE;
        }

        pt = EptSplit2Mb(ept, pdptIdx, pdIdx);
        if (pt == NULL)
        {
            return FALSE;
        }

        pt[ptIdx] = EPT_LEAF_4KB_XO(pa);

        ept->Hooks[ept->HookCount].Gpa4Kb = pa;
        ept->HookCount++;

        MV_LOG("EPT hook: execute-only on GPA %llx", pa);
    }

    return TRUE;
}

BOOLEAN
EptIsHookedPage(PEPT_STATE ept, UINT64 gpa)
{
    UINT64 gpa4k = gpa & ~(UINT64)(PAGE_SIZE - 1);
    ULONG  k;

    for (k = 0; k < ept->HookCount; k++)
    {
        if (ept->Hooks[k].Gpa4Kb == gpa4k)
        {
            return TRUE;
        }
    }
    return FALSE;
}

VOID
EptRestoreExecuteOnly(PEPT_STATE ept, UINT64 gpa)
{
    UINT64 gpa2mb = EPT_2MB_BASE(gpa);
    ULONG  ptIdx  = (ULONG)EPT_PT_IDX(gpa);
    UINT64 pa4k   = gpa & ~(UINT64)(PAGE_SIZE - 1);
    ULONG  k;

    for (k = 0; k < ept->SplitCount; k++)
    {
        if (ept->Splits[k].Gpa2Mb == gpa2mb)
        {
            ept->Splits[k].PtVirtual[ptIdx] = EPT_LEAF_4KB_XO(pa4k);
            return;
        }
    }

    MV_ERR("EptRestoreExecuteOnly: GPA %llx not in split table", gpa);
}

VOID
EptShadowSetExec(PEPT_STATE ept, UINT64 gpa4kb, UINT64 execPa)
{
    ULONG   pdptIdx = (ULONG)EPT_PDPT_IDX(gpa4kb);
    ULONG   pdIdx   = (ULONG)EPT_PD_IDX(gpa4kb);
    ULONG   ptIdx   = (ULONG)EPT_PT_IDX(gpa4kb);
    UINT64* pt      = EptSplit2Mb(ept, pdptIdx, pdIdx);

    if (pt == NULL)
    {
        MV_ERR("EptShadowSetExec: split failed for GPA %llx", gpa4kb);
        return;
    }
    pt[ptIdx] = EPT_EXEC | (EPT_MT_WB << EPT_MT_SHIFT) | execPa;
}

VOID
EptShadowSetFull(PEPT_STATE ept, UINT64 gpa4kb, UINT64 shadowPa)
{
    ULONG   pdptIdx = (ULONG)EPT_PDPT_IDX(gpa4kb);
    ULONG   pdIdx   = (ULONG)EPT_PD_IDX(gpa4kb);
    ULONG   ptIdx   = (ULONG)EPT_PT_IDX(gpa4kb);
    UINT64* pt      = EptSplit2Mb(ept, pdptIdx, pdIdx);

    if (pt == NULL)
    {
        MV_ERR("EptShadowSetFull: split failed for GPA %llx", gpa4kb);
        return;
    }
    pt[ptIdx] = EPT_RWX | (EPT_MT_WB << EPT_MT_SHIFT) | shadowPa;
}

VOID
EptFree(PEPT_STATE ept)
{
    ULONG i;

    for (i = 0; i < ept->SplitCount; i++)
    {
        if (ept->Splits[i].PtVirtual != NULL)
        {
            MemFreeContiguous(ept->Splits[i].PtVirtual);
            ept->Splits[i].PtVirtual = NULL;
        }
    }
    ept->SplitCount = 0;

    if (ept->DecoyVa != NULL)
    {
        MemFreeContiguous(ept->DecoyVa);
        ept->DecoyVa = NULL;
    }

    if (ept->TablesVa != NULL)
    {
        MemFreeContiguous(ept->TablesVa);
        ept->TablesVa = NULL;
    }
}

VOID
EptInvalidateAll(PEPT_STATE ept)
{
    INVEPT_DESCRIPTOR desc;
    desc.Eptp     = ept->Eptp;
    desc.Reserved = 0;
    AsmInvept(INVEPT_SINGLE_CONTEXT, &desc);
}
