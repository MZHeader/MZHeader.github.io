

#pragma once

#include <ntddk.h>

#define VMCS_GUEST_ES_SELECTOR          0x00000800
#define VMCS_GUEST_CS_SELECTOR          0x00000802
#define VMCS_GUEST_SS_SELECTOR          0x00000804
#define VMCS_GUEST_DS_SELECTOR          0x00000806
#define VMCS_GUEST_FS_SELECTOR          0x00000808
#define VMCS_GUEST_GS_SELECTOR          0x0000080A
#define VMCS_GUEST_LDTR_SELECTOR        0x0000080C
#define VMCS_GUEST_TR_SELECTOR          0x0000080E
#define VMCS_CTRL_VPID                  0x00000000
#define VMCS_HOST_ES_SELECTOR           0x00000C00
#define VMCS_HOST_CS_SELECTOR           0x00000C02
#define VMCS_HOST_SS_SELECTOR           0x00000C04
#define VMCS_HOST_DS_SELECTOR           0x00000C06
#define VMCS_HOST_FS_SELECTOR           0x00000C08
#define VMCS_HOST_GS_SELECTOR           0x00000C0A
#define VMCS_HOST_TR_SELECTOR           0x00000C0C

#define VMCS_CTRL_IO_BITMAP_A           0x00002000
#define VMCS_CTRL_IO_BITMAP_B           0x00002002
#define VMCS_CTRL_MSR_BITMAP            0x00002004
#define VMCS_CTRL_TSC_OFFSET            0x00002010
#define VMCS_CTRL_EPT_POINTER           0x0000201A
#define VMCS_CTRL_TSC_MULTIPLIER        0x00002032

#define VMCS_GUEST_PHYSICAL_ADDRESS     0x00002400

#define VMCS_GUEST_VMCS_LINK_POINTER    0x00002800
#define VMCS_GUEST_DEBUGCTL             0x00002802
#define VMCS_GUEST_PAT                  0x00002804
#define VMCS_GUEST_EFER                 0x00002806

#define VMCS_HOST_PAT                   0x00002C00
#define VMCS_HOST_EFER                  0x00002C02

#define VMCS_CTRL_PIN_BASED             0x00004000
#define VMCS_CTRL_PROC_BASED            0x00004002
#define VMCS_CTRL_EXCEPTION_BITMAP      0x00004004
#define VMCS_CTRL_PF_ERROR_MASK         0x00004006
#define VMCS_CTRL_PF_ERROR_MATCH        0x00004008
#define VMCS_CTRL_CR3_TARGET_COUNT      0x0000400A
#define VMCS_CTRL_EXIT_CONTROLS         0x0000400C
#define VMCS_CTRL_EXIT_MSR_STORE_COUNT  0x0000400E
#define VMCS_CTRL_EXIT_MSR_LOAD_COUNT   0x00004010
#define VMCS_CTRL_ENTRY_CONTROLS        0x00004012
#define VMCS_CTRL_ENTRY_MSR_LOAD_COUNT  0x00004014
#define VMCS_CTRL_ENTRY_INTR_INFO       0x00004016
#define VMCS_CTRL_ENTRY_EXCEPTION_CODE  0x00004018
#define VMCS_CTRL_ENTRY_INSTR_LEN       0x0000401A
#define VMCS_CTRL_PROC_BASED2           0x0000401E

#define VMCS_VM_INSTRUCTION_ERROR       0x00004400
#define VMCS_EXIT_REASON                0x00004402
#define VMCS_EXIT_INTR_INFO             0x00004404
#define VMCS_EXIT_INTR_ERROR_CODE       0x00004406
#define VMCS_IDT_VECTORING_INFO         0x00004408
#define VMCS_IDT_VECTORING_ERROR_CODE   0x0000440A
#define VMCS_EXIT_INSTRUCTION_LEN       0x0000440C
#define VMCS_EXIT_INSTRUCTION_INFO      0x0000440E

#define VMCS_GUEST_ES_LIMIT             0x00004800
#define VMCS_GUEST_CS_LIMIT             0x00004802
#define VMCS_GUEST_SS_LIMIT             0x00004804
#define VMCS_GUEST_DS_LIMIT             0x00004806
#define VMCS_GUEST_FS_LIMIT             0x00004808
#define VMCS_GUEST_GS_LIMIT             0x0000480A
#define VMCS_GUEST_LDTR_LIMIT           0x0000480C
#define VMCS_GUEST_TR_LIMIT             0x0000480E
#define VMCS_GUEST_GDTR_LIMIT           0x00004810
#define VMCS_GUEST_IDTR_LIMIT           0x00004812
#define VMCS_GUEST_ES_ACCESS_RIGHTS     0x00004814
#define VMCS_GUEST_CS_ACCESS_RIGHTS     0x00004816
#define VMCS_GUEST_SS_ACCESS_RIGHTS     0x00004818
#define VMCS_GUEST_DS_ACCESS_RIGHTS     0x0000481A
#define VMCS_GUEST_FS_ACCESS_RIGHTS     0x0000481C
#define VMCS_GUEST_GS_ACCESS_RIGHTS     0x0000481E
#define VMCS_GUEST_LDTR_ACCESS_RIGHTS   0x00004820
#define VMCS_GUEST_TR_ACCESS_RIGHTS     0x00004822
#define VMCS_GUEST_INTERRUPTIBILITY     0x00004824
#define VMCS_GUEST_ACTIVITY_STATE       0x00004826
#define VMCS_GUEST_SYSENTER_CS          0x0000482A

#define VMCS_HOST_SYSENTER_CS           0x00004C00

#define VMCS_CTRL_CR0_GUEST_HOST_MASK   0x00006000
#define VMCS_CTRL_CR4_GUEST_HOST_MASK   0x00006002
#define VMCS_CTRL_CR0_READ_SHADOW       0x00006004
#define VMCS_CTRL_CR4_READ_SHADOW       0x00006006

#define VMCS_EXIT_QUALIFICATION         0x00006400
#define VMCS_GUEST_LINEAR_ADDRESS       0x0000640A

#define VMCS_GUEST_CR0                  0x00006800
#define VMCS_GUEST_CR3                  0x00006802
#define VMCS_GUEST_CR4                  0x00006804
#define VMCS_GUEST_ES_BASE              0x00006806
#define VMCS_GUEST_CS_BASE              0x00006808
#define VMCS_GUEST_SS_BASE              0x0000680A
#define VMCS_GUEST_DS_BASE              0x0000680C
#define VMCS_GUEST_FS_BASE              0x0000680E
#define VMCS_GUEST_GS_BASE              0x00006810
#define VMCS_GUEST_LDTR_BASE            0x00006812
#define VMCS_GUEST_TR_BASE              0x00006814
#define VMCS_GUEST_GDTR_BASE            0x00006816
#define VMCS_GUEST_IDTR_BASE            0x00006818
#define VMCS_GUEST_DR7                  0x0000681A
#define VMCS_GUEST_RSP                  0x0000681C
#define VMCS_GUEST_RIP                  0x0000681E
#define VMCS_GUEST_RFLAGS               0x00006820
#define VMCS_GUEST_PENDING_DBG_EXCEPT   0x00006822
#define VMCS_GUEST_SYSENTER_ESP         0x00006824
#define VMCS_GUEST_SYSENTER_EIP         0x00006826

#define VMCS_HOST_CR0                   0x00006C00
#define VMCS_HOST_CR3                   0x00006C02
#define VMCS_HOST_CR4                   0x00006C04
#define VMCS_HOST_FS_BASE               0x00006C06
#define VMCS_HOST_GS_BASE               0x00006C08
#define VMCS_HOST_TR_BASE               0x00006C0A
#define VMCS_HOST_GDTR_BASE             0x00006C0C
#define VMCS_HOST_IDTR_BASE             0x00006C0E
#define VMCS_HOST_SYSENTER_ESP          0x00006C10
#define VMCS_HOST_SYSENTER_EIP          0x00006C12
#define VMCS_HOST_RSP                   0x00006C14
#define VMCS_HOST_RIP                   0x00006C16

#define PROC_CTL_USE_TSC_OFFSETTING     (1U << 3)
#define PROC_CTL_HLT_EXITING            (1U << 7)
#define PROC_CTL_RDTSC_EXITING          (1U << 12)
#define PROC_CTL_RDPMC_EXITING          (1U << 11)  /* SDM bit 11; NOT 15 (=CR3-load exiting) */
#define PROC_CTL_USE_IO_BITMAPS         (1U << 25)  
#define PROC_CTL_MONITOR_TRAP_FLAG      (1U << 27)  
#define PROC_CTL_USE_MSR_BITMAPS        (1U << 28)
#define PROC_CTL_ACTIVATE_SECONDARY     (1U << 31)

#define PROC_CTL2_ENABLE_EPT            (1U << 1)
#define PROC_CTL2_ENABLE_RDTSCP         (1U << 3)
#define PROC_CTL2_ENABLE_VPID           (1U << 5)
#define PROC_CTL2_ENABLE_INVPCID        (1U << 12)
#define PROC_CTL2_ENABLE_XSAVES         (1U << 20)
#define PROC_CTL2_USE_TSC_SCALING       (1U << 25)

#define EXIT_CTL_SAVE_DEBUG_CONTROLS    (1U << 2)
#define EXIT_CTL_HOST_ADDR_SPACE_SIZE   (1U << 9)   
#define EXIT_CTL_ACK_INTR_ON_EXIT       (1U << 15)
#define EXIT_CTL_SAVE_IA32_PAT          (1U << 18)
#define EXIT_CTL_LOAD_IA32_PAT          (1U << 19)
#define EXIT_CTL_SAVE_IA32_EFER         (1U << 20)
#define EXIT_CTL_LOAD_IA32_EFER         (1U << 21)

#define ENTRY_CTL_LOAD_DEBUG_CONTROLS   (1U << 2)
#define ENTRY_CTL_IA32E_MODE_GUEST      (1U << 9)   
#define ENTRY_CTL_LOAD_IA32_PAT         (1U << 14)
#define ENTRY_CTL_LOAD_IA32_EFER        (1U << 15)

#define EXIT_REASON_EXCEPTION_NMI       0
#define EXIT_REASON_EXTERNAL_INTERRUPT  1
#define EXIT_REASON_TRIPLE_FAULT        2
#define EXIT_REASON_CPUID               10
#define EXIT_REASON_HLT                 12
#define EXIT_REASON_INVD                13
#define EXIT_REASON_RDPMC               15
#define EXIT_REASON_RDTSC               16
#define EXIT_REASON_VMCALL              18
#define EXIT_REASON_VMCLEAR             19
#define EXIT_REASON_VMLAUNCH            20
#define EXIT_REASON_VMPTRLD             21
#define EXIT_REASON_VMPTRST             22
#define EXIT_REASON_VMREAD              23
#define EXIT_REASON_VMRESUME            24
#define EXIT_REASON_VMWRITE             25
#define EXIT_REASON_VMXOFF              26
#define EXIT_REASON_VMXON               27
#define EXIT_REASON_CR_ACCESS           28
#define EXIT_REASON_MOV_DR              29
#define EXIT_REASON_IO_INSTRUCTION      30
#define EXIT_REASON_MSR_READ            31
#define EXIT_REASON_MSR_WRITE           32
#define EXIT_REASON_MWAIT               36
#define EXIT_REASON_MONITOR_TRAP_FLAG   37
#define EXIT_REASON_MONITOR             39
#define EXIT_REASON_EPT_VIOLATION       48
#define EXIT_REASON_EPT_MISCONFIG       49
#define EXIT_REASON_RDTSCP              51
#define EXIT_REASON_XSETBV              55
#define EXIT_REASON_INVPCID            58

#define EXIT_REASON_ENTRY_FAILURE       (1U << 31)

typedef union _CR_ACCESS_QUALIFICATION
{
    UINT64 AsUInt64;
    struct
    {
        UINT64 CrNumber : 4;        
        UINT64 AccessType : 2;      
        UINT64 LmswOperandType : 1;
        UINT64 Reserved0 : 1;
        UINT64 GpRegister : 4;      
        UINT64 Reserved1 : 4;
        UINT64 LmswSource : 16;
        UINT64 Reserved2 : 32;
    };
} CR_ACCESS_QUALIFICATION;

#define CR_ACCESS_TYPE_MOV_TO_CR        0
#define CR_ACCESS_TYPE_MOV_FROM_CR      1
#define CR_ACCESS_TYPE_CLTS             2
#define CR_ACCESS_TYPE_LMSW             3

typedef union _VMENTRY_INTERRUPT_INFO
{
    UINT32 AsUInt32;
    struct
    {
        UINT32 Vector : 8;
        UINT32 InterruptionType : 3;    
        UINT32 DeliverErrorCode : 1;
        UINT32 Reserved : 19;
        UINT32 Valid : 1;               
    };
} VMENTRY_INTERRUPT_INFO;

#define INTERRUPT_TYPE_HARDWARE_EXCEPTION   3
#define INTERRUPT_TYPE_SOFTWARE_EXCEPTION   6   
#define EXCEPTION_VECTOR_BP                 3   
#define EXCEPTION_VECTOR_UD                 6   
#define EXCEPTION_VECTOR_GP                 13  

#define VMX_SEGMENT_AR_UNUSABLE             (1U << 16)

typedef union _IA32_VMX_BASIC_MSR
{
    UINT64 AsUInt64;
    struct
    {
        UINT64 RevisionId : 31;
        UINT64 Reserved0 : 1;
        UINT64 VmxRegionSize : 13;
        UINT64 Reserved1 : 3;
        UINT64 PhysicalWidth : 1;
        UINT64 DualMonitor : 1;
        UINT64 MemoryType : 4;
        UINT64 InsOutsReporting : 1;
        UINT64 TrueControls : 1;        
        UINT64 Reserved2 : 8;
    };
} IA32_VMX_BASIC_MSR;
