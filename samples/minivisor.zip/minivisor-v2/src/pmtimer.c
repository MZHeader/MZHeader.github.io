

#include "minivisor.h"
#include <intrin.h>

#ifndef SystemFirmwareTableInformation
#define SystemFirmwareTableInformation 76
#endif

typedef struct _MV_FW_TABLE_INFO
{
    ULONG ProviderSignature;     
    ULONG Action;                
    ULONG TableID;               
    ULONG TableBufferLength;     
    UCHAR TableBuffer[1];        
} MV_FW_TABLE_INFO, *PMV_FW_TABLE_INFO;

NTSYSAPI NTSTATUS NTAPI
ZwQuerySystemInformation(ULONG SystemInformationClass,
                         PVOID SystemInformation,
                         ULONG SystemInformationLength,
                         PULONG ReturnLength);

#define SIG_ACPI    0x41435041u   
#define SIG_FACP    0x50434146u   
#define FIRMWARE_TABLE_GET  1u

#define FADT_OFF_LENGTH         4       
#define FADT_OFF_PM_TMR_BLK     76      
#define FADT_OFF_PM_TMR_LEN     91      
#define FADT_OFF_FLAGS          112     
#define FADT_OFF_X_PM_TMR_BLK   208     
#define FADT_FLAG_TMR_VAL_EXT   (1u << 8)

#define GAS_OFF_ADDR_SPACE      0       
#define GAS_OFF_ADDRESS         4       
#define GAS_ADDR_SPACE_IO       1

static PUCHAR
PmTimerQueryFadt(ULONG* outLen)
{
    MV_FW_TABLE_INFO probe;
    PMV_FW_TABLE_INFO info;
    ULONG need = 0, total;
    NTSTATUS st;

    
    RtlZeroMemory(&probe, sizeof(probe));
    probe.ProviderSignature = SIG_ACPI;
    probe.Action            = FIRMWARE_TABLE_GET;
    probe.TableID           = SIG_FACP;
    probe.TableBufferLength = 0;

    st = ZwQuerySystemInformation(SystemFirmwareTableInformation,
                                  &probe, sizeof(probe), &need);
    

    /* A real FADT is a few hundred bytes; reject 0 or an implausibly large
     * length so the `total` sum below cannot overflow ULONG and under-allocate. */
    if (probe.TableBufferLength == 0 || probe.TableBufferLength > 0x10000)
    {
        MV_LOG("PMTMR: firmware-table query returned no/invalid FADT len=%lu (st=%08x)",
               probe.TableBufferLength, st);
        return NULL;
    }

    total = FIELD_OFFSET(MV_FW_TABLE_INFO, TableBuffer)
          + probe.TableBufferLength;

    info = (PMV_FW_TABLE_INFO)
           ExAllocatePoolZero(NonPagedPoolNx, total, MV_TAG);
    if (info == NULL)
    {
        MV_ERR("PMTMR: FADT buffer allocation failed");
        return NULL;
    }

    info->ProviderSignature = SIG_ACPI;
    info->Action            = FIRMWARE_TABLE_GET;
    info->TableID           = SIG_FACP;
    info->TableBufferLength = probe.TableBufferLength;

    st = ZwQuerySystemInformation(SystemFirmwareTableInformation,
                                  info, total, &need);
    if (!NT_SUCCESS(st))
    {
        MV_LOG("PMTMR: FADT fetch failed st=%08x", st);
        ExFreePoolWithTag(info, MV_TAG);
        return NULL;
    }

    {
        ULONG len = info->TableBufferLength;
        PUCHAR fadt = (PUCHAR)ExAllocatePoolZero(NonPagedPoolNx, len, MV_TAG);
        if (fadt == NULL)
        {
            ExFreePoolWithTag(info, MV_TAG);
            return NULL;
        }
        RtlCopyMemory(fadt, info->TableBuffer, len);
        ExFreePoolWithTag(info, MV_TAG);
        *outLen = len;
        return fadt;
    }
}

BOOLEAN
PmTimerFind(PPMTIMER_STATE pmt)
{
    PUCHAR  fadt;
    ULONG   fadtLen = 0;
    UINT32  port = 0;
    UINT32  flags;
    UINT64  fTsc;
    LARGE_INTEGER tscFreqLi;

    RtlZeroMemory(pmt, sizeof(*pmt));

    fadt = PmTimerQueryFadt(&fadtLen);
    if (fadt == NULL || fadtLen < FADT_OFF_FLAGS + sizeof(UINT32))
    {
        if (fadt) ExFreePoolWithTag(fadt, MV_TAG);
        MV_LOG("PMTMR: FADT unavailable or too short — PM timer spoofing disabled");
        return FALSE;
    }

    flags = *(UINT32 UNALIGNED*)(fadt + FADT_OFF_FLAGS);

    

    if (fadtLen >= FADT_OFF_X_PM_TMR_BLK + 12)
    {
        PUCHAR gas = fadt + FADT_OFF_X_PM_TMR_BLK;
        UINT8  space = gas[GAS_OFF_ADDR_SPACE];
        UINT64 addr  = *(UINT64 UNALIGNED*)(gas + GAS_OFF_ADDRESS);

        if (space == GAS_ADDR_SPACE_IO && addr != 0 && addr <= 0xFFFF)
        {
            port = (UINT32)addr;
        }
    }

    if (port == 0)
    {
        port = *(UINT32 UNALIGNED*)(fadt + FADT_OFF_PM_TMR_BLK);
    }

    ExFreePoolWithTag(fadt, MV_TAG);

    if (port == 0 || port > 0xFFFF)
    {
        MV_LOG("PMTMR: FADT has no usable PM_TMR_BLK port (got %x)", port);
        return FALSE;
    }

    pmt->Port    = (UINT16)port;
    pmt->Is32Bit = (flags & FADT_FLAG_TMR_VAL_EXT) != 0;

    
    pmt->BaseTsc     = __rdtsc();
    pmt->BaseCounter = __indword((USHORT)pmt->Port)
                     & (pmt->Is32Bit ? PMTIMER_MASK_32 : PMTIMER_MASK_24);

    KeQueryPerformanceCounter(&tscFreqLi);     
    fTsc = (UINT64)tscFreqLi.QuadPart;
    if (fTsc == 0)
    {
        MV_ERR("PMTMR: TSC frequency 0 — cannot compute synthesis ratio");
        return FALSE;
    }

    pmt->RatioScaled = (PMTIMER_FREQUENCY << PMTIMER_RATIO_SHIFT) / fTsc;
    pmt->Valid = TRUE;

    MV_LOG("PMTMR: port=0x%04x width=%u-bit base=%08x ratio<<%u=%llu",
           pmt->Port, pmt->Is32Bit ? 32 : 24, pmt->BaseCounter,
           PMTIMER_RATIO_SHIFT, pmt->RatioScaled);
    return TRUE;
}

UINT32
PmTimerSynthesize(PPMTIMER_STATE pmt, PVCPU vcpu)
{
    UINT64 hwTsc    = __rdtsc();
    INT64  guestTsc = (INT64)hwTsc + vcpu->TscOffset;   
    INT64  deltaTsc = guestTsc - (INT64)pmt->BaseTsc;
    UINT64 ticks;
    UINT32 mask = pmt->Is32Bit ? PMTIMER_MASK_32 : PMTIMER_MASK_24;

    if (deltaTsc < 0)
    {
        deltaTsc = 0;       
    }

    ticks = ((UINT64)deltaTsc * pmt->RatioScaled) >> PMTIMER_RATIO_SHIFT;
    return (UINT32)((pmt->BaseCounter + ticks) & mask);
}

BOOLEAN
PmTimerHandleIo(PVCPU vcpu, PGUEST_REGISTERS regs,
                UINT32 port, UINT32 size, BOOLEAN isIn)
{
    UINT32 base, byteOffset, value;

    if (!g_Hv.PmTimer.Valid)
    {
        return FALSE;
    }

    base = g_Hv.PmTimer.Port;
    if (port < base || port > base + 3)
    {
        return FALSE;       
    }

    if (!isIn)
    {
        

        VmExitAdvanceRip();
        return TRUE;
    }

    

    value      = PmTimerSynthesize(&g_Hv.PmTimer, vcpu);
    byteOffset = port - base;
    value    >>= (byteOffset * 8);

    switch (size)
    {
    case 1:
        regs->Rax = (regs->Rax & ~(UINT64)0xFF)   | (UINT64)(value & 0xFF);
        break;
    case 2:
        regs->Rax = (regs->Rax & ~(UINT64)0xFFFF) | (UINT64)(value & 0xFFFF);
        break;
    default:
        regs->Rax = (UINT64)value;      
        break;
    }

    VmExitAdvanceRip();
    return TRUE;
}
