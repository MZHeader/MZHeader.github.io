

#pragma once

#include <ntddk.h>
#include <ntimage.h>      /* IMAGE_DOS_HEADER / IMAGE_NT_HEADERS64 / exports etc. */
#include "ia32.h"
#include "vmx_defs.h"

#define MV_TAG          'vsiM'      

#define HOST_STACK_SIZE (PAGE_SIZE * 8)

#define MV_CPUID_UNLOAD_MAGIC   0x4D56556E  

#define CPUID_TIMING_SAMPLES    4096u

typedef struct _GUEST_REGISTERS
{
    UINT64 Rax;     
    UINT64 Rcx;     
    UINT64 Rdx;     
    UINT64 Rbx;     
    UINT64 Rbp;     
    UINT64 Rsi;     
    UINT64 Rdi;     
    UINT64 R8;      
    UINT64 R9;      
    UINT64 R10;     
    UINT64 R11;     
    UINT64 R12;     
    UINT64 R13;     
    UINT64 R14;     
    UINT64 R15;     
} GUEST_REGISTERS, *PGUEST_REGISTERS;

C_ASSERT(sizeof(GUEST_REGISTERS) == 0x78);

typedef struct _VMEXIT_FRAME
{
    GUEST_REGISTERS Regs;       
    UINT64          OffRflags;  
    UINT64          OffRsp;     
    UINT64          OffRip;     
    struct _VCPU*   Vcpu;       
} VMEXIT_FRAME, *PVMEXIT_FRAME;

C_ASSERT(FIELD_OFFSET(VMEXIT_FRAME, OffRflags) == 0x78);
C_ASSERT(FIELD_OFFSET(VMEXIT_FRAME, Vcpu) == 0x90);

typedef struct _VCPU
{
    DECLSPEC_ALIGN(PAGE_SIZE) UINT8 VmxonRegion[PAGE_SIZE];
    DECLSPEC_ALIGN(PAGE_SIZE) UINT8 VmcsRegion[PAGE_SIZE];
    DECLSPEC_ALIGN(PAGE_SIZE) UINT8 MsrBitmap[PAGE_SIZE];
    DECLSPEC_ALIGN(PAGE_SIZE) UINT8 IoBitmapA[PAGE_SIZE]; 
    DECLSPEC_ALIGN(PAGE_SIZE) UINT8 IoBitmapB[PAGE_SIZE]; 
    DECLSPEC_ALIGN(PAGE_SIZE) UINT8 HostStack[HOST_STACK_SIZE];

    UINT64  VmxonPhysical;
    UINT64  VmcsPhysical;
    UINT64  MsrBitmapPhysical;
    UINT64  IoBitmapAPhysical;
    UINT64  IoBitmapBPhysical;

    UINT64  HostCr3;            

    
    INT64   TscOffset;          
    UINT64  ExitEntryTsc;       
    UINT64  LastExitTsc;        
    UINT64  TscNativeCost;      
    UINT64  TscFixedOverhead;   

    

    INT64   AperfOffset;
    BOOLEAN AperfMperfOk;       /* CPUID.06H:ECX[0]: APERF/MPERF present. If FALSE,
                                 * RDMSR APERF would #GP in root → never read it. */
    /* Cached APERF/MPERF frequency ratio (APERF cycles per MPERF cycle, scaled by
     * 2^MV_APERF_RATIO_SHIFT).  Lets the hot path derive the APERF cost of an exit
     * from the TSC cost × ratio instead of reading APERF on every exit (removes
     * 2 RDMSRs/exit).  Refreshed every MV_APERF_RATIO_INTERVAL exits; both counters
     * stop in idle, so their delta ratio is the clean C0 frequency ratio. */
    UINT64  AperfRatioScaled;
    UINT32  AperfRatioCountdown;
    UINT64  AperfRatioBaseA;
    UINT64  AperfRatioBaseM;

    

    UINT64  TscSamples[CPUID_TIMING_SAMPLES];

    

    UINT64  ShadowDebugCtl;

    

    UINT64          MtfExposedPage;

    
    BOOLEAN         HpetMtfPending;
    UINT64          HpetSynthetic;
    GUEST_REGISTERS HpetGprsBefore;

    
    BOOLEAN         ApicMtfPending;
    UINT64          ApicSynthetic;
    GUEST_REGISTERS ApicGprsBefore;

    

    BOOLEAN         MtfHookExposed;

    

    struct _SHADOW_HOOK* MtfShadowHook;

    /* Per-VCPU PIT read state (mutable across consecutive I/O exits). */
    UINT16  PitLatch;
    UINT16  PitReadValue;
    UINT8   PitReadPhase;
    BOOLEAN PitLatchActive;

    ULONG   ProcessorIndex;
    BOOLEAN Virtualized;
    BOOLEAN LaunchFailed;
    BOOLEAN EptInveptPending;

    struct _HV_GLOBAL* Global;
} VCPU, *PVCPU;

#define HPET_MAIN_COUNTER_OFFSET    0x0F0ULL    
#define HPET_GCAP_ID_OFFSET         0x000ULL    
#define HPET_PERIOD_SHIFT           32          
#define HPET_PERIOD_MIN_FS          10000000ULL  
#define HPET_PERIOD_MAX_FS          100000000ULL 
#define HPET_CANDIDATE_BASE         0xFED00000ULL

typedef struct _HPET_STATE
{
    UINT64   PhysBase;          
    UINT64   PeriodFs;          
    UINT64   BaseTsc;           
    UINT64   BaseCounter;       
    UINT64   RatioScaled20;     
    BOOLEAN  Valid;             
} HPET_STATE, *PHPET_STATE;

#define PMTIMER_FREQUENCY       3579545ULL   
#define PMTIMER_RATIO_SHIFT     24           
#define PMTIMER_MASK_24         0x00FFFFFFu
#define PMTIMER_MASK_32         0xFFFFFFFFu

typedef struct _PMTIMER_STATE
{
    UINT16   Port;
    BOOLEAN  Is32Bit;
    UINT64   BaseTsc;
    UINT32   BaseCounter;
    UINT64   RatioScaled;
    BOOLEAN  Valid;
} PMTIMER_STATE, *PPMTIMER_STATE;

/* ------------------------------------------------------------------ */
/* Intel 8254 PIT (i/o ports 0x40-0x43) — channel-0 read spoofing.     */
/* A fixed 1.193182 MHz counter the article lists as a timing source.  */
/* We synthesize a TSC-coherent free-running down-counter so a PIT-     */
/* bracketed CPUID loop sees no exit overhead.  Writes pass through to  */
/* the real PIT so OS programming/IRQ0 stay intact.                     */
/* ------------------------------------------------------------------ */
#define PIT_FREQ_HZ         1193182ULL
#define PIT_RATIO_SHIFT     20
#define PIT_CH0_DATA_PORT   0x40
#define PIT_CMD_PORT        0x43

typedef struct _PIT_STATE
{
    UINT64   BaseTsc;          /* TSC at load-time snapshot */
    UINT64   RatioScaled;      /* (PIT_FREQ_HZ << PIT_RATIO_SHIFT) / F_tsc */
    UINT8    AccessMode;       /* 1=lobyte, 2=hibyte, 3=lobyte/hibyte */
    BOOLEAN  Valid;
} PIT_STATE, *PPIT_STATE;

typedef struct _APIC_STATE
{
    UINT64   PhysBase;          
    UINT64   InitialCount;      
    UINT64   BaseTsc;           
    UINT64   RatioScaled20;     
    BOOLEAN  Valid;             
} APIC_STATE, *PAPIC_STATE;

#define EPT_MAX_SPLITS  64

#define EPT_MAX_HOOKS   64

typedef struct _EPT_SPLIT
{
    UINT64  Gpa2Mb;         
    UINT64  PtPhysical;
    UINT64* PtVirtual;
} EPT_SPLIT, *PEPT_SPLIT;

typedef struct _EPT_HOOK
{
    UINT64 Gpa4Kb;          
} EPT_HOOK, *PEPT_HOOK;

typedef struct _EPT_STATE
{
    PVOID   TablesVa;        
    UINT64  TablesPhysical;
    SIZE_T  TablesSize;
    ULONG   PdCount;         
    UINT64  Eptp;            

    PVOID   DecoyVa;         
    UINT64  DecoyPhysical;

    EPT_SPLIT Splits[EPT_MAX_SPLITS];
    ULONG     SplitCount;

    EPT_HOOK  Hooks[EPT_MAX_HOOKS];  
    ULONG     HookCount;
} EPT_STATE, *PEPT_STATE;

typedef struct _INVEPT_DESCRIPTOR
{
    UINT64 Eptp;
    UINT64 Reserved;
} INVEPT_DESCRIPTOR, *PINVEPT_DESCRIPTOR;

#define INVEPT_SINGLE_CONTEXT   1ULL    
#define INVEPT_ALL_CONTEXT      2ULL    

#define MV_SHADOW_HOOK_MAX  32
#define MV_HOOK_TAG_SIZE    32   

typedef struct _SHADOW_HOOK SHADOW_HOOK, *PSHADOW_HOOK;

typedef VOID (*PSHADOW_HOOK_CALLBACK)(PVCPU vcpu, PVMEXIT_FRAME frame,
                                      PSHADOW_HOOK hook);

struct _SHADOW_HOOK
{
    UINT64                TargetVa;              
    UINT64                Gpa4Kb;                
    UINT64                ExecPa;                
    UINT64                ShadowPa;              
    PVOID                 ExecVa;                
    PVOID                 ShadowVa;              
    UINT32                HookOffset;            
    UINT8                 OriginalByte;          
    CHAR                  Tag[MV_HOOK_TAG_SIZE]; 
    PSHADOW_HOOK_CALLBACK OnBp;                  
    BOOLEAN               Active;
    BOOLEAN               SharedPage; 
};

typedef struct _HV_GLOBAL
{
    PVCPU      Vcpus;
    ULONG      VcpuCount;
    BOOLEAN    VmxEnabled;
    UINT64     SystemCr3;        /* CR3 captured in DriverEntry (System process
                                  * context) — used as VMCS_HOST_CR3 so the host
                                  * address space never points at a process that
                                  * can be torn down. */
    EPT_STATE  Ept;              
    HPET_STATE Hpet;             
    APIC_STATE Apic;             
    PMTIMER_STATE PmTimer;
    PIT_STATE  Pit;              /* 8254 PIT channel-0 spoofing state */

    

    volatile INT64 MinTscOffset;     
    volatile INT64 MaxOffsetSpread;  

    

    UINT64     TargetBase;
    SIZE_T     TargetSize;

    

    SHADOW_HOOK ShadowHooks[MV_SHADOW_HOOK_MAX];
    ULONG       ShadowHookCount;
    KSPIN_LOCK  HookTableLock;

    PDEVICE_OBJECT ControlDevice;

    /* Set from VMX non-root before an IPI that triggers per-CPU INVEPT via
     * HandleVmExit.  Avoids writing to the EPT-hidden VCPU array. */
    volatile BOOLEAN EptFlushPending;
} HV_GLOBAL, *PHV_GLOBAL;

extern HV_GLOBAL g_Hv;

BOOLEAN EptIsSupported(VOID);
BOOLEAN EptBuild(PEPT_STATE ept);
BOOLEAN EptHideRange(PEPT_STATE ept, UINT64 physBase, SIZE_T size);
BOOLEAN EptTrapRange(PEPT_STATE ept, UINT64 physBase, SIZE_T size);
BOOLEAN EptSetExecuteOnly(PEPT_STATE ept, UINT64 physBase, SIZE_T size);
BOOLEAN EptIsHookedPage(PEPT_STATE ept, UINT64 gpa);
VOID    EptRestoreExecuteOnly(PEPT_STATE ept, UINT64 gpa);
VOID    EptSetGpaPresent(PEPT_STATE ept, UINT64 gpa, BOOLEAN present);
VOID    EptShadowSetExec(PEPT_STATE ept, UINT64 gpa4kb, UINT64 execPa);
VOID    EptShadowSetFull(PEPT_STATE ept, UINT64 gpa4kb, UINT64 shadowPa);
VOID    EptFree(PEPT_STATE ept);
VOID    EptInvalidateAll(PEPT_STATE ept);

BOOLEAN HpetFind(PHPET_STATE hpet);
BOOLEAN HpetHide(PHPET_STATE hpet, PEPT_STATE ept);
UINT64  HpetSynthesize(PHPET_STATE hpet, PVCPU vcpu);
VOID    HpetHandleViolation(PVCPU vcpu, PVMEXIT_FRAME frame);
VOID    HpetHandleMtf(PVCPU vcpu, PVMEXIT_FRAME frame);

BOOLEAN PmTimerFind(PPMTIMER_STATE pmt);
UINT32  PmTimerSynthesize(PPMTIMER_STATE pmt, PVCPU vcpu);

/* pit.c — 8254 PIT channel-0 spoofing. */
BOOLEAN PitInit(PPIT_STATE pit);                  /* snapshot base, compute ratio */
BOOLEAN PitHandleIo(PVCPU vcpu, PGUEST_REGISTERS regs,
                    UINT32 port, UINT32 size, BOOLEAN isIn);

BOOLEAN PmTimerHandleIo(PVCPU vcpu, PGUEST_REGISTERS regs,
                        UINT32 port, UINT32 size, BOOLEAN isIn);

BOOLEAN ApicFind(PAPIC_STATE apic);
BOOLEAN ApicHide(PAPIC_STATE apic, PEPT_STATE ept);
UINT64  ApicSynthesize(PAPIC_STATE apic, PVCPU vcpu);
VOID    ApicHandleViolation(PVCPU vcpu, PVMEXIT_FRAME frame);
VOID    ApicHandleMtf(PVCPU vcpu, PVMEXIT_FRAME frame);

VOID AsmInvept(ULONG_PTR type, PINVEPT_DESCRIPTOR descriptor);

PVOID  MemAllocContiguous(SIZE_T size);
VOID   MemFreeContiguous(PVOID va);
UINT64 MemVirtualToPhysical(PVOID va);

BOOLEAN VmxIsSupported(VOID);
BOOLEAN VmxEnableOnVcpu(PVCPU vcpu);     
VOID    VmxDisableOnVcpu(PVCPU vcpu);    
UINT32  VmxAdjustControls(UINT32 desired, UINT32 capabilityMsr);

BOOLEAN VmcsSetup(PVCPU vcpu, PCONTEXT guestContext);

BOOLEAN HandleVmExit(PVMEXIT_FRAME frame);

VOID    VmExitAdvanceRip(VOID);
VOID    VmExitInjectGp(UINT32 errorCode);
VOID    VmExitInjectUd(VOID);
VOID    VmExitInjectBp(VOID);

VOID HandleCpuid(PVCPU vcpu, PGUEST_REGISTERS regs);
VOID HandleCrAccess(PVCPU vcpu, PGUEST_REGISTERS regs);
VOID HandleMsrRead(PVCPU vcpu, PGUEST_REGISTERS regs);
VOID HandleMsrWrite(PVCPU vcpu, PGUEST_REGISTERS regs);
VOID HandleRdpmc(PVCPU vcpu, PGUEST_REGISTERS regs);
VOID HandleIoInstruction(PVCPU vcpu, PGUEST_REGISTERS regs);

VOID IoBitmapSet(PVCPU vcpu, UINT16 port);

BOOLEAN      ShadowHookInstall(UINT64 targetVa, PCSTR tag);
BOOLEAN      ShadowHookInstallEx(UINT64 targetVa, PCSTR tag, PSHADOW_HOOK_CALLBACK onBp);
BOOLEAN      ShadowHookInstallRuntime(UINT64 targetVa, PCSTR tag);
BOOLEAN      ShadowHookInstallExRuntime(UINT64 targetVa, PCSTR tag, PSHADOW_HOOK_CALLBACK onBp);
PSHADOW_HOOK ShadowHookFindByPage(UINT64 gpa4kb);
PSHADOW_HOOK ShadowHookFindByInt3(UINT64 int3Va);
VOID         ShadowHookHandleViolation(PVCPU vcpu, PVMEXIT_FRAME frame, UINT64 gpa, SIZE_T qual);
VOID         ShadowHookHandleBp(PVCPU vcpu, PVMEXIT_FRAME frame, PSHADOW_HOOK hook);
VOID         ShadowHookHandleMtf(PVCPU vcpu);

VOID    SyscallHookInit(VOID);
VOID    SyscallHookAddFilter(UINT32 syscallNum);
VOID    SyscallHookClearFilter(VOID);
VOID    SyscallHookAddName(UINT32 syscallNum, PCSTR name);
ULONG   SyscallHookNameCount(VOID);
BOOLEAN SyscallHookFilterAll(VOID); 

VOID   TscOnExitEntry(PVCPU vcpu);
VOID   TscOnExitExit(PVCPU vcpu);
VOID   TscBitmapInit(PVCPU vcpu);   

UINT64 TscMeasureCpuidCost(UINT64* scratch);   
VOID   TscSetNativeCost(PVCPU vcpu, UINT64 nativeCost);
VOID   TscCalibrate(PVCPU vcpu);

typedef enum _MSR_ACTION
{
    MSR_PASSTHROUGH,    
    MSR_INJECT_GP,      
    MSR_VALUE           
} MSR_ACTION;

VOID       StealthFilterCpuid(UINT32 leaf, UINT32 subleaf,
                              INT32 reg[4] );
BOOLEAN    StealthMsrShouldExit(UINT32 msr);       
MSR_ACTION StealthMsrReadAction(UINT32 msr, UINT64* spoofValue);
MSR_ACTION StealthMsrWriteAction(UINT32 msr, UINT64 value);
UINT64     StealthCr4ReadShadow(UINT64 realCr4);   
VOID       StealthSetupMsrBitmap(PVCPU vcpu);

VOID MsrBitmapSet(PVOID bitmap, UINT32 msr, BOOLEAN read, BOOLEAN write);

#define MV_LOG(fmt, ...) \
    DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL, "[minivisor] " fmt "\n", ##__VA_ARGS__)
#define MV_ERR(fmt, ...) \
    DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, "[minivisor][!] " fmt "\n", ##__VA_ARGS__)

VOID LogInit(VOID);

/* driver.c - devirtualize all CPUs and free VCPU/EPT memory. */
VOID HvDevirtualizeAndFree(VOID);

/* control.c - IOCTL control device (called from DriverEntry/Unload). */
NTSTATUS ControlInit(PDRIVER_OBJECT driverObject);
VOID     ControlTeardown(VOID);

VOID   AsmVmExitHandler(VOID);
UINT16 AsmReadCs(VOID);
UINT16 AsmReadSs(VOID);
UINT16 AsmReadDs(VOID);
UINT16 AsmReadEs(VOID);
UINT16 AsmReadFs(VOID);
UINT16 AsmReadGs(VOID);
UINT16 AsmReadTr(VOID);
UINT16 AsmReadLdtr(VOID);
VOID   AsmReadGdtr(PGDTR gdtr);
VOID   AsmReadIdtr(PGDTR idtr);
UINT32 AsmReadSegmentLimit(UINT16 selector);
UINT32 AsmReadSegmentAccessRights(UINT16 selector);
