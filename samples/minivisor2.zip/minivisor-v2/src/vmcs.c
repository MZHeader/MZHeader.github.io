

#include "minivisor.h"
#include <intrin.h>

#define VMW(field, value)   status |= __vmx_vmwrite((field), (UINT64)(value))

static UINT64
SegmentBase(UINT64 gdtBase, UINT16 selector)
{
    PSEGMENT_DESCRIPTOR d;
    UINT64 base;

    if ((selector & ~7U) == 0)      
    {
        return 0;
    }

    d = (PSEGMENT_DESCRIPTOR)(gdtBase + (selector & ~7U));
    base = (UINT64)d->BaseLow |
           ((UINT64)d->BaseMiddle << 16) |
           ((UINT64)d->BaseHigh << 24);

    

    if ((d->Attributes & 0x10) == 0)
    {
        base |= (UINT64)(*(UINT32*)((UINT8*)d + 8)) << 32;
    }
    return base;
}

static UINT32
SegmentAccessRights(UINT16 selector)
{
    UINT32 ar;

    if ((selector & ~7U) == 0)
    {
        return VMX_SEGMENT_AR_UNUSABLE;
    }

    ar = AsmReadSegmentAccessRights(selector);  
    if (ar == 0)
    {
        return VMX_SEGMENT_AR_UNUSABLE;
    }

    

    return (ar >> 8) & 0xF0FF;
}

static UINT64
VmcsWriteGuestSegments(UINT64 gdtBase)
{
    
    static const UINT32 field[8][4] = {
        { VMCS_GUEST_ES_SELECTOR,   VMCS_GUEST_ES_BASE,   VMCS_GUEST_ES_LIMIT,   VMCS_GUEST_ES_ACCESS_RIGHTS },
        { VMCS_GUEST_CS_SELECTOR,   VMCS_GUEST_CS_BASE,   VMCS_GUEST_CS_LIMIT,   VMCS_GUEST_CS_ACCESS_RIGHTS },
        { VMCS_GUEST_SS_SELECTOR,   VMCS_GUEST_SS_BASE,   VMCS_GUEST_SS_LIMIT,   VMCS_GUEST_SS_ACCESS_RIGHTS },
        { VMCS_GUEST_DS_SELECTOR,   VMCS_GUEST_DS_BASE,   VMCS_GUEST_DS_LIMIT,   VMCS_GUEST_DS_ACCESS_RIGHTS },
        { VMCS_GUEST_FS_SELECTOR,   VMCS_GUEST_FS_BASE,   VMCS_GUEST_FS_LIMIT,   VMCS_GUEST_FS_ACCESS_RIGHTS },
        { VMCS_GUEST_GS_SELECTOR,   VMCS_GUEST_GS_BASE,   VMCS_GUEST_GS_LIMIT,   VMCS_GUEST_GS_ACCESS_RIGHTS },
        { VMCS_GUEST_LDTR_SELECTOR, VMCS_GUEST_LDTR_BASE, VMCS_GUEST_LDTR_LIMIT, VMCS_GUEST_LDTR_ACCESS_RIGHTS },
        { VMCS_GUEST_TR_SELECTOR,   VMCS_GUEST_TR_BASE,   VMCS_GUEST_TR_LIMIT,   VMCS_GUEST_TR_ACCESS_RIGHTS },
    };
    UINT16 selector[8];
    UINT64 status = 0;
    ULONG i;

    selector[0] = AsmReadEs();
    selector[1] = AsmReadCs();
    selector[2] = AsmReadSs();
    selector[3] = AsmReadDs();
    selector[4] = AsmReadFs();
    selector[5] = AsmReadGs();
    selector[6] = AsmReadLdtr();
    selector[7] = AsmReadTr();

    for (i = 0; i < 8; i++)
    {
        UINT16 sel = selector[i];
        UINT64 base;

        VMW(field[i][0], sel);
        VMW(field[i][2], AsmReadSegmentLimit(sel));
        VMW(field[i][3], SegmentAccessRights(sel));

        
        if (field[i][1] == VMCS_GUEST_FS_BASE)
        {
            base = __readmsr(IA32_FS_BASE);
        }
        else if (field[i][1] == VMCS_GUEST_GS_BASE)
        {
            base = __readmsr(IA32_GS_BASE);
        }
        else
        {
            base = SegmentBase(gdtBase, sel);
        }
        VMW(field[i][1], base);
    }

    return status;
}

BOOLEAN
VmcsSetup(PVCPU vcpu, PCONTEXT ctx)
{
    UINT64 status = 0;
    GDTR gdtr, idtr;
    UINT64 cr0 = __readcr0();
    UINT64 cr4 = __readcr4();
    UINT64 stackBase;
    IA32_VMX_BASIC_MSR basic;
    UINT32 pinCtlsMsr, procCtlsMsr, exitCtlsMsr, entryCtlsMsr;

    basic.AsUInt64 = __readmsr(IA32_VMX_BASIC);

    AsmReadGdtr(&gdtr);
    AsmReadIdtr(&idtr);

    
    if (basic.TrueControls)
    {
        pinCtlsMsr   = IA32_VMX_TRUE_PINBASED_CTLS;
        procCtlsMsr  = IA32_VMX_TRUE_PROCBASED_CTLS;
        exitCtlsMsr  = IA32_VMX_TRUE_EXIT_CTLS;
        entryCtlsMsr = IA32_VMX_TRUE_ENTRY_CTLS;
    }
    else
    {
        pinCtlsMsr   = IA32_VMX_PINBASED_CTLS;
        procCtlsMsr  = IA32_VMX_PROCBASED_CTLS;
        exitCtlsMsr  = IA32_VMX_EXIT_CTLS;
        entryCtlsMsr = IA32_VMX_ENTRY_CTLS;
    }

    
    VMW(VMCS_GUEST_VMCS_LINK_POINTER, ~0ULL);

    
    VMW(VMCS_CTRL_PIN_BASED, VmxAdjustControls(0, pinCtlsMsr));

    VMW(VMCS_CTRL_PROC_BASED,
        VmxAdjustControls(PROC_CTL_USE_MSR_BITMAPS    |
                          PROC_CTL_USE_TSC_OFFSETTING  |
                          PROC_CTL_RDPMC_EXITING       |
                          PROC_CTL_USE_IO_BITMAPS      |
                          PROC_CTL_ACTIVATE_SECONDARY,
                          procCtlsMsr));

    
    VMW(VMCS_CTRL_PROC_BASED2,
        VmxAdjustControls(PROC_CTL2_ENABLE_EPT    |
                          PROC_CTL2_ENABLE_VPID    |
                          PROC_CTL2_ENABLE_RDTSCP  |
                          PROC_CTL2_ENABLE_INVPCID |
                          PROC_CTL2_ENABLE_XSAVES,
                          IA32_VMX_PROCBASED_CTLS2));

    VMW(VMCS_CTRL_EPT_POINTER, vcpu->Global->Ept.Eptp);
    VMW(VMCS_CTRL_VPID, 1);

    VMW(VMCS_CTRL_EXIT_CONTROLS,
        VmxAdjustControls(EXIT_CTL_HOST_ADDR_SPACE_SIZE |
                          EXIT_CTL_SAVE_IA32_PAT        |
                          EXIT_CTL_LOAD_IA32_PAT        |
                          EXIT_CTL_SAVE_IA32_EFER       |
                          EXIT_CTL_LOAD_IA32_EFER,
                          exitCtlsMsr));

    VMW(VMCS_CTRL_ENTRY_CONTROLS,
        VmxAdjustControls(ENTRY_CTL_IA32E_MODE_GUEST |
                          ENTRY_CTL_LOAD_IA32_PAT    |
                          ENTRY_CTL_LOAD_IA32_EFER,
                          entryCtlsMsr));

    VMW(VMCS_CTRL_EXCEPTION_BITMAP, 1U << EXCEPTION_VECTOR_BP); 
    VMW(VMCS_CTRL_CR3_TARGET_COUNT, 0);
    VMW(VMCS_CTRL_EXIT_MSR_STORE_COUNT, 0);
    VMW(VMCS_CTRL_EXIT_MSR_LOAD_COUNT, 0);
    VMW(VMCS_CTRL_ENTRY_MSR_LOAD_COUNT, 0);

    VMW(VMCS_CTRL_MSR_BITMAP,   vcpu->MsrBitmapPhysical);
    VMW(VMCS_CTRL_IO_BITMAP_A,  vcpu->IoBitmapAPhysical);
    VMW(VMCS_CTRL_IO_BITMAP_B,  vcpu->IoBitmapBPhysical);
    VMW(VMCS_CTRL_TSC_OFFSET, 0);           

    

    VMW(VMCS_CTRL_CR0_GUEST_HOST_MASK, 0);
    VMW(VMCS_CTRL_CR0_READ_SHADOW, cr0);
    VMW(VMCS_CTRL_CR4_GUEST_HOST_MASK, CR4_VMXE);
    VMW(VMCS_CTRL_CR4_READ_SHADOW, cr4 & ~CR4_VMXE);

    
    VMW(VMCS_GUEST_CR0, cr0);
    VMW(VMCS_GUEST_CR3, __readcr3());
    VMW(VMCS_GUEST_CR4, cr4);
    VMW(VMCS_GUEST_DR7, __readdr(7));

    VMW(VMCS_GUEST_RSP, ctx->Rsp);
    VMW(VMCS_GUEST_RIP, ctx->Rip);
    VMW(VMCS_GUEST_RFLAGS, ctx->EFlags | 0x2);

    status |= VmcsWriteGuestSegments(gdtr.Base);

    VMW(VMCS_GUEST_GDTR_BASE, gdtr.Base);
    VMW(VMCS_GUEST_GDTR_LIMIT, gdtr.Limit);
    VMW(VMCS_GUEST_IDTR_BASE, idtr.Base);
    VMW(VMCS_GUEST_IDTR_LIMIT, idtr.Limit);

    VMW(VMCS_GUEST_SYSENTER_CS, __readmsr(IA32_SYSENTER_CS));
    VMW(VMCS_GUEST_SYSENTER_ESP, __readmsr(IA32_SYSENTER_ESP));
    VMW(VMCS_GUEST_SYSENTER_EIP, __readmsr(IA32_SYSENTER_EIP));
    VMW(VMCS_GUEST_DEBUGCTL, __readmsr(IA32_DEBUGCTL));
    VMW(VMCS_GUEST_EFER, __readmsr(IA32_EFER));
    VMW(VMCS_GUEST_PAT, __readmsr(IA32_PAT));

    VMW(VMCS_GUEST_INTERRUPTIBILITY, 0);
    VMW(VMCS_GUEST_ACTIVITY_STATE, 0);      
    VMW(VMCS_GUEST_PENDING_DBG_EXCEPT, 0);  

    
    VMW(VMCS_HOST_CR0, cr0);
    VMW(VMCS_HOST_CR3, vcpu->HostCr3);
    VMW(VMCS_HOST_CR4, cr4);                

    VMW(VMCS_HOST_CS_SELECTOR, AsmReadCs() & ~7U);
    VMW(VMCS_HOST_SS_SELECTOR, AsmReadSs() & ~7U);
    VMW(VMCS_HOST_DS_SELECTOR, AsmReadDs() & ~7U);
    VMW(VMCS_HOST_ES_SELECTOR, AsmReadEs() & ~7U);
    VMW(VMCS_HOST_FS_SELECTOR, AsmReadFs() & ~7U);
    VMW(VMCS_HOST_GS_SELECTOR, AsmReadGs() & ~7U);
    VMW(VMCS_HOST_TR_SELECTOR, AsmReadTr() & ~7U);

    VMW(VMCS_HOST_FS_BASE, __readmsr(IA32_FS_BASE));
    VMW(VMCS_HOST_GS_BASE, __readmsr(IA32_GS_BASE));
    VMW(VMCS_HOST_TR_BASE, SegmentBase(gdtr.Base, AsmReadTr()));
    VMW(VMCS_HOST_GDTR_BASE, gdtr.Base);
    VMW(VMCS_HOST_IDTR_BASE, idtr.Base);

    VMW(VMCS_HOST_SYSENTER_CS, __readmsr(IA32_SYSENTER_CS));
    VMW(VMCS_HOST_SYSENTER_ESP, __readmsr(IA32_SYSENTER_ESP));
    VMW(VMCS_HOST_SYSENTER_EIP, __readmsr(IA32_SYSENTER_EIP));
    VMW(VMCS_HOST_PAT, __readmsr(IA32_PAT));
    VMW(VMCS_HOST_EFER, __readmsr(IA32_EFER));

    

    stackBase = (UINT64)&vcpu->HostStack[HOST_STACK_SIZE];
    *(PVCPU*)(stackBase - 0x08) = vcpu;
    VMW(VMCS_HOST_RSP, stackBase - 0x20);
    VMW(VMCS_HOST_RIP, (UINT64)AsmVmExitHandler);

    
    StealthSetupMsrBitmap(vcpu);

    

    if (g_Hv.PmTimer.Valid)
    {
        UINT16 p = g_Hv.PmTimer.Port;
        IoBitmapSet(vcpu, p);
        IoBitmapSet(vcpu, (UINT16)(p + 1));
        IoBitmapSet(vcpu, (UINT16)(p + 2));
        IoBitmapSet(vcpu, (UINT16)(p + 3));
    }

    /* Trap PIT channel-0 data (0x40) and the command port (0x43). */
    if (g_Hv.Pit.Valid)
    {
        IoBitmapSet(vcpu, PIT_CH0_DATA_PORT);
        IoBitmapSet(vcpu, PIT_CMD_PORT);
    }

    if (status != 0)
    {
        MV_ERR("VMWRITE error(s) during VMCS setup on CPU %lu", vcpu->ProcessorIndex);
        return FALSE;
    }
    return TRUE;
}
